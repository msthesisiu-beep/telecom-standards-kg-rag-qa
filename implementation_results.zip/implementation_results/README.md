# KG-RAG Implementation Results

This folder contains a compact, shareable snapshot of the exploratory KG-RAG implementation run.

## Important limitation

These are smoke-test results, not thesis-validated findings. The run sampled 20 questions and 150 passages. The
independent support verifier excluded all 20 questions, so retrieval-quality metrics could not be calculated. The
sample does not establish whether post-rerank KG augmentation improves telecom standards QA.

## Files

- `condition_comparison.csv` — accuracy, answer validity, latency, and cost for each sampled condition.
- `run_summary.json` — run size, KG graph counts, evaluation summary, limitations, and API budget.
- `evaluation_summary.csv` — available mean RAGAs-protocol scores; one evaluation record was partial.
- `example_trial.json` — a paired baseline (B) and KG-augmented (C) answer for one question, with source identifiers.
- `openai_budget.json` — latest local budget-ledger snapshot. Provider billing may differ.

No raw 3GPP passages or complete generation/evaluation logs are included.
