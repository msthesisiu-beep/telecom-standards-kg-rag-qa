"""Stage 10: independent triple-fidelity verification (Sec. 3.6) by the `verifier` role (not the extractor,
generator or evaluator). One call per source passage judges all of that passage's triples."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed

from ..core import Project, append_jsonl, iter_jsonl, utc_now
from ..llm import LLMClient

PROMPT_VERSION = "kg-verify-v1.0"
SYSTEM = "You check whether knowledge-graph triples are entailed by their source text from a 3GPP specification."
TEMPLATE = """SOURCE PASSAGE [{pid}] {spec} clause {clause}:
{text}

For each numbered triple decide whether the SOURCE PASSAGE alone entails it (subject, relation and object all correct;
direction correct; no information added). Verdict "entailed" or "not_entailed".

TRIPLES:
{triples}"""
SCHEMA = {"type": "object", "properties": {"judgements": {"type": "array", "items": {"type": "object", "properties": {
    "n": {"type": "integer"}, "verdict": {"type": "string", "enum": ["entailed", "not_entailed"]},
    "reason": {"type": "string"}}, "required": ["n", "verdict"]}}}, "required": ["judgements"]}

PRED_TEXT = {"SENDS": "sends", "RECEIVES": "receives", "USES_INTERFACE": "uses interface", "CONNECTS": "connects",
             "PART_OF": "is part of", "TRIGGERS": "triggers", "INITIATES": "initiates", "STARTS_TIMER": "starts timer",
             "STOPS_TIMER": "stops timer", "CONTAINS": "contains", "PROVIDES": "provides", "REQUIRES": "requires",
             "SELECTS": "selects", "STORES": "stores", "IS_A": "is a"}


def statement(s: str, p: str, o: str) -> str:
    return f"{s} {PRED_TEXT.get(p, p.lower())} {o}"


def verify_passage(llm: LLMClient, p: dict, instances: list[dict]) -> list[dict]:
    lines = "\n".join(f"{i + 1}. ({t['subject']}) --{t['predicate']}--> ({t['object']})" + (f" [modality: {t['modality']}]" if t.get("modality") else "")
                      for i, t in enumerate(instances))
    r = llm.generate_json("verifier", TEMPLATE.format(pid=p["passage_id"], spec=p["specification"], clause=p["clause_id"],
                                                      text=p["text"], triples=lines), SCHEMA, SYSTEM)
    verdicts = {}
    if r.ok:
        for j in r.data.get("judgements", []):
            verdicts[int(j.get("n", 0))] = (j.get("verdict"), j.get("reason"))
    out = []
    for i, t in enumerate(instances):
        v = verdicts.get(i + 1)
        out.append({"instance_id": t["instance_id"], "passage_id": p["passage_id"], "prompt_version": PROMPT_VERSION,
                    "model": r.model, "model_version": r.model_version,
                    "fidelity_verdict": v[0] if v else None, "reason": v[1] if v else None,
                    "status": "ok" if (r.ok and v) else "error", "error": r.error,
                    "batch_cost_usd": r.cost_usd if i == 0 else 0.0, "utc": utc_now()})
    return out


def run(project: Project, llm: LLMClient, instances: list[dict], passages: dict, workers: int | None = None) -> str:
    out = project.path("interim", "kg_fidelity.jsonl")
    done = {r["instance_id"] for r in iter_jsonl(out) if r.get("status") == "ok" and r.get("prompt_version") == PROMPT_VERSION}
    by_p: dict[str, list[dict]] = {}
    for t in instances:
        if t["instance_id"] not in done:
            by_p.setdefault(t["passage_id"], []).append(t)
    with ThreadPoolExecutor(workers or project.study["experiment"]["workers"]) as ex:
        for f in as_completed([ex.submit(verify_passage, llm, passages[pid], ts) for pid, ts in by_p.items()]):
            for row in f.result():
                append_jsonl(out, row)
    return str(out)
