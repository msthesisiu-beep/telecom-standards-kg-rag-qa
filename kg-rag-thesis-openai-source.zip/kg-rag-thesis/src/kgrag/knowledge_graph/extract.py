"""Stage 9: LLM-based triple extraction with a fixed prompt and predefined schema (Sec. 3.4 Comp. 1, 4.6.1).

Model = models.yaml role `kg_extractor`. One call per passage (provenance stays one-to-one). Every triple must carry a
verbatim supporting quotation; the script marks provenance invalid when the quote is not in the passage.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed

from ..core import Project, append_jsonl, iter_jsonl, utc_now
from ..llm import LLMClient
from ..validation.verifier import quote_in_passage

PROMPT_VERSION = "kg-extract-v1.0"

SYSTEM = ("You extract a knowledge graph from 3GPP Release 17 specification text. Use ONLY facts stated in the given "
          "passage. Never add background knowledge.")

TEMPLATE = """Extract subject-predicate-object triples from the PASSAGE.

Entity types: {etypes}
Predicates (use exactly one of these):
- SENDS (entity sends a Message), RECEIVES (entity receives a Message), USES_INTERFACE (entity/message uses an Interface or reference point),
- CONNECTS (Interface connects two entities; subject = Interface), PART_OF (step/message/procedure is part of a Procedure),
- TRIGGERS (message/event/procedure triggers a Procedure or Message), INITIATES (entity initiates a Procedure),
- STARTS_TIMER / STOPS_TIMER (entity/message/procedure starts/stops a Timer), CONTAINS (Message contains an InformationElement),
- PROVIDES (NetworkFunction provides a Service or function), REQUIRES (normative requirement: subject shall/should/may do or have object),
- SELECTS (entity selects another entity), STORES (entity stores data), IS_A (subtype relation).
Rules:
- Use the specification's own names; prefer the abbreviation when the passage gives one (e.g. "AMF").
- quote: copy VERBATIM from the passage (exact characters, at least 6 words) the sentence fragment that states the triple.
- For REQUIRES keep the normative word (shall / should / may / shall not) in `modality`.
- Return at most 12 of the most informative triples. Return an empty list if the passage states no such relation (e.g. a pure table of values or a change log).

PASSAGE [{pid}] {spec} clause {clause} - {heading}:
{text}"""

SCHEMA = {"type": "object", "properties": {"triples": {"type": "array", "items": {"type": "object", "properties": {
    "subject": {"type": "string"}, "subject_type": {"type": "string"},
    "predicate": {"type": "string"}, "object": {"type": "string"}, "object_type": {"type": "string"},
    "modality": {"type": "string"}, "quote": {"type": "string"}},
    "required": ["subject", "subject_type", "predicate", "object", "object_type", "quote"]}}}, "required": ["triples"]}


def extract_passage(llm: LLMClient, p: dict, kg_cfg: dict) -> dict:
    prompt = TEMPLATE.format(etypes=", ".join(kg_cfg["entity_types"]), pid=p["passage_id"], spec=p["specification"],
                             clause=p["clause_id"], heading=p["heading"][:100], text=p["text"])
    r = llm.generate_json("kg_extractor", prompt, SCHEMA, SYSTEM)
    rec = {"passage_id": p["passage_id"], "prompt_version": PROMPT_VERSION, "model": r.model,
           "model_version": r.model_version, "input_tokens": r.input_tokens, "output_tokens": r.output_tokens,
           "cost_usd": r.cost_usd, "latency_s": r.latency_s, "utc": utc_now(),
           "status": "ok" if r.ok else "error", "error": r.error, "triples": []}
    if not r.ok:
        return rec
    preds, etypes = set(kg_cfg["predicates"]), set(kg_cfg["entity_types"])
    for i, t in enumerate(r.data.get("triples", []) or []):
        pred = str(t.get("predicate", "")).strip().upper().replace(" ", "_")
        st, ot = t.get("subject_type", "Other"), t.get("object_type", "Other")
        rec["triples"].append({
            "local_id": i, "subject": str(t.get("subject", "")).strip(), "predicate": pred,
            "object": str(t.get("object", "")).strip(), "subject_type": st if st in etypes else "Other",
            "object_type": ot if ot in etypes else "Other", "modality": t.get("modality"), "quote": t.get("quote", ""),
            "schema_valid": pred in preds and bool(t.get("subject")) and bool(t.get("object")),
            "quote_found": quote_in_passage(t.get("quote", ""), p["text"])})
    return rec


def run(project: Project, llm: LLMClient, passages: list[dict], workers: int | None = None,
        limit: int | None = None) -> str:
    out = project.path("interim", "kg_extraction.jsonl")
    done = {r["passage_id"] for r in iter_jsonl(out) if r.get("status") == "ok" and r.get("prompt_version") == PROMPT_VERSION}
    todo = [p for p in passages if p["passage_id"] not in done][: limit or None]
    kg_cfg = project.study["knowledge_graph"]
    with ThreadPoolExecutor(workers or project.study["experiment"]["workers"]) as ex:
        for f in as_completed([ex.submit(extract_passage, llm, p, kg_cfg) for p in todo]):
            append_jsonl(out, f.result())
    return str(out)
