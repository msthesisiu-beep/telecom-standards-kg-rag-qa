"""Entity normalisation, abbreviation mapping from the corpus itself, de-duplication with provenance (Sec. 4.6.2).

The alias table is built ONLY from the Abbreviations clauses of the frozen corpus (no external dictionaries).
"""
from __future__ import annotations

import collections
import re

from ..core import stable_hash

ABBR_LINE = re.compile(r"^\s*\|?\s*([A-Z][A-Za-z0-9\-/]{1,15})\s*\|?\s{1,}\|?\s*([A-Z][A-Za-z0-9 ,\-/()']{3,120}?)\s*\|?\s*$")
_ESC = re.compile(r"\\([\\`*_{}\[\]()#+\-.!|<>~])")


def build_alias_table(passages: list[dict]) -> dict[str, str]:
    """{long form lower -> ABBREVIATION} from clauses headed 'Abbreviations' in the corpus."""
    table: dict[str, str] = {}
    for p in passages:
        if "abbreviation" not in p["heading"].lower():
            continue
        for line in p["text"].splitlines():
            line = _ESC.sub(r"\1", line).replace("*", "")
            m = ABBR_LINE.match(line)
            if m and is_abbreviation(m.group(1)):
                abbr, long = m.group(1).strip(), m.group(2).strip()
                if len(long.split()) >= 2:
                    table.setdefault(long.lower(), abbr)
    return table


def is_abbreviation(s: str) -> bool:
    return bool(re.fullmatch(r"[A-Z0-9][A-Za-z0-9\-/]*", s)) and sum(c.isupper() for c in s) >= 2


def canonical(name: str, aliases: dict[str, str]) -> tuple[str, str]:
    """Return (key, display). Abbreviations are case-sensitive keys; other names are case-folded."""
    s = _ESC.sub(r"\1", name or "").replace("*", "").replace("`", "")
    s = re.sub(r"\s+", " ", s).strip(" .,:;\"'")
    s = re.sub(r"^(the|a|an)\s+", "", s, flags=re.I)
    m = re.fullmatch(r"(.+?)\s*\(([A-Z][A-Za-z0-9\-/]{1,15})\)", s)  # "Access and Mobility ... (AMF)"
    if m and is_abbreviation(m.group(2)):
        s = m.group(2)
    m = re.fullmatch(r"([A-Z][A-Za-z0-9\-/]{1,15})\s*\((.+)\)", s)    # "AMF (Access and Mobility ...)"
    if m and is_abbreviation(m.group(1)):
        s = m.group(1)
    if s.lower() in aliases:
        s = aliases[s.lower()]
    key = s if is_abbreviation(s) else s.casefold()
    return key, s


def deduplicate(instances: list[dict], aliases: dict[str, str]) -> list[dict]:
    """Merge extraction instances with the same (subject, predicate, object) keys; keep ALL provenance entries."""
    groups: dict[tuple, list[dict]] = collections.defaultdict(list)
    for t in instances:
        sk, sd = canonical(t["subject"], aliases)
        ok, od = canonical(t["object"], aliases)
        if not sk or not ok or sk == ok:
            continue
        groups[(sk, t["predicate"], ok)].append({**t, "_sd": sd, "_od": od})
    out = []
    for (sk, pred, ok), inst in groups.items():
        sd = collections.Counter(i["_sd"] for i in inst).most_common(1)[0][0]
        od = collections.Counter(i["_od"] for i in inst).most_common(1)[0][0]
        st = collections.Counter(i["subject_type"] for i in inst).most_common(1)[0][0]
        ot = collections.Counter(i["object_type"] for i in inst).most_common(1)[0][0]
        prov = sorted(({"passage_id": i["passage_id"], "quote": i["quote"], "specification": i["specification"],
                        "clause_id": i["clause_id"], "version": i["version"], "release": i["release"],
                        "instance_id": i["instance_id"], "fidelity_verdict": i.get("fidelity_verdict")}
                       for i in inst), key=lambda d: d["instance_id"])
        out.append({"triple_id": "T" + stable_hash([sk, pred, ok], 12), "subject": sd, "subject_key": sk,
                    "subject_type": st, "predicate": pred, "object": od, "object_key": ok, "object_type": ot,
                    "provenance": prov, "n_sources": len(prov)})
    return sorted(out, key=lambda t: t["triple_id"])
