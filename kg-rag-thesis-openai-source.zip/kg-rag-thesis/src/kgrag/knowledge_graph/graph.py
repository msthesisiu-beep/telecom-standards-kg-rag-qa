"""Validated KG assembly (NetworkX), statistics, and query-time triple selection for C, D and the two controls.

Only triples with >=1 provenance instance that is schema-valid, quote-verified (provenance) AND verifier-entailed
(fidelity) enter the validated graph (Sec. 3.3: unsupported relationships excluded).
"""
from __future__ import annotations

import collections
import pickle
import random
import re
import time
import tracemalloc

import networkx as nx
import numpy as np

from ..core import Project, iter_jsonl, read_jsonl, sha256_text, write_json, write_jsonl
from .fidelity import statement
from .normalize import build_alias_table, canonical, deduplicate, is_abbreviation


def assemble(project: Project, passages: dict, release: str = "17") -> tuple[list[dict], list[dict], dict]:
    """Returns (all_triples_with_verdicts, validated_triples, stats)."""
    fid = {}
    for r in iter_jsonl(project.path("interim", "kg_fidelity.jsonl")):
        if r.get("status") == "ok":
            fid[r["instance_id"]] = r["fidelity_verdict"]
    instances, n_ext, n_err = [], 0, 0
    for rec in iter_jsonl(project.path("interim", "kg_extraction.jsonl")):
        if rec.get("status") != "ok":
            n_err += 1
            continue
        p = passages.get(rec["passage_id"])
        if p is None:
            continue
        for t in rec["triples"]:
            n_ext += 1
            iid = f"{rec['passage_id']}#{t['local_id']}"
            instances.append({**t, "instance_id": iid, "passage_id": p["passage_id"], "specification": p["specification"],
                              "clause_id": p["clause_id"], "version": p["version"], "release": p["release"],
                              "provenance_valid": bool(t["quote_found"] and p["release"] == release),
                              "fidelity_verdict": fid.get(iid)})
    aliases = build_alias_table(list(passages.values()))
    all_tr = deduplicate([i for i in instances if i["schema_valid"]], aliases)
    by_inst = {i["instance_id"]: i for i in instances}
    validated = []
    for t in all_tr:
        good = [pv for pv in t["provenance"] if by_inst[pv["instance_id"]]["provenance_valid"]
                and pv["fidelity_verdict"] == "entailed"]
        t["fidelity_verdict"] = "entailed" if good else ("not_entailed" if all(pv["fidelity_verdict"] for pv in t["provenance"]) else "unverified")
        t["provenance_valid"] = any(by_inst[pv["instance_id"]]["provenance_valid"] for pv in t["provenance"])
        if good:
            validated.append({**t, "provenance": good, "n_sources": len(good),
                              "source_passage_id": good[0]["passage_id"], "quote": good[0]["quote"]})
    for t in all_tr:  # flattened fields for the audit sampler
        t["source_passage_id"], t["quote"] = t["provenance"][0]["passage_id"], t["provenance"][0]["quote"]
    stats = {"extraction_records_error": n_err, "instances_extracted": n_ext,
             "instances_schema_valid": sum(i["schema_valid"] for i in instances),
             "instances_quote_verified": sum(i["provenance_valid"] for i in instances),
             "instances_verifier_entailed": sum(i["fidelity_verdict"] == "entailed" for i in instances),
             "instances_unverified": sum(i["fidelity_verdict"] is None for i in instances),
             "unique_triples_before_validation": len(all_tr), "validated_triples": len(validated),
             "alias_table_size": len(aliases)}
    write_jsonl(project.path("interim", "kg_triples_all.jsonl"), all_tr)
    write_jsonl(project.path("processed", "kg_triples_validated.jsonl"), validated)
    write_json(project.path("processed", "kg_alias_table.json"), aliases)
    G = to_networkx(validated)
    with open(project.path("processed", "kg_validated.gpickle"), "wb") as f:
        pickle.dump(G, f)
    stats.update(graph_statistics(G, validated))
    write_json(project.path("reports", "kg_statistics.json"), stats)
    return all_tr, validated, stats


def to_networkx(triples: list[dict]) -> nx.MultiDiGraph:
    G = nx.MultiDiGraph()
    for t in triples:
        G.add_node(t["subject_key"], name=t["subject"], type=t["subject_type"])
        G.add_node(t["object_key"], name=t["object"], type=t["object_type"])
        G.add_edge(t["subject_key"], t["object_key"], key=t["triple_id"], predicate=t["predicate"],
                   sources=[p["passage_id"] for p in t["provenance"]])
    return G


def graph_statistics(G: nx.MultiDiGraph, triples: list[dict]) -> dict:
    deg = [d for _, d in G.degree()]
    return {"nodes": G.number_of_nodes(), "edges": G.number_of_edges(),
            "relation_type_frequencies": dict(collections.Counter(t["predicate"] for t in triples).most_common()),
            "entity_type_frequencies": dict(collections.Counter(d.get("type") for _, d in G.nodes(data=True)).most_common()),
            "weakly_connected_components": nx.number_weakly_connected_components(G) if G.number_of_nodes() else 0,
            "mean_degree": float(np.mean(deg)) if deg else 0.0, "max_degree": int(max(deg)) if deg else 0,
            "source_linked_triples": sum(1 for t in triples if t.get("provenance"))}


# ============================================================================ query-time
GRAPH_HEADER = "Knowledge-graph statements (each derived from the cited source clause):"
STOP_NAMES = {"data", "information", "procedure", "message", "network", "request", "response", "function",
              "service", "user", "value", "parameter", "timer", "entity", "node", "list", "set", "case"}


def render_statement(t: dict, label: str) -> str:
    p = t["provenance"][0]
    return f"[{label}] {statement(t['subject'], t['predicate'], t['object'])}. (Source: {p['specification']} clause {p['clause_id']}, {p['passage_id']})"


class KGIndex:
    """In-memory validated KG with entity matcher and statement embeddings (BGE passage encoder)."""

    def __init__(self, triples: list[dict], encoder=None, emb: np.ndarray | None = None):
        tracemalloc.start()
        t0 = time.perf_counter()
        self.triples = triples
        self.by_id = {t["triple_id"]: t for t in triples}
        self.ids = [t["triple_id"] for t in triples]
        self.pos = {tid: i for i, tid in enumerate(self.ids)}
        self.incident: dict[str, list[str]] = collections.defaultdict(list)
        names: dict[str, set] = collections.defaultdict(set)
        for t in triples:
            self.incident[t["subject_key"]].append(t["triple_id"])
            self.incident[t["object_key"]].append(t["triple_id"])
            names[t["subject_key"]].add(t["subject"])
            names[t["object_key"]].add(t["object"])
        self.matcher: dict[str, str] = {}
        for key, surf in names.items():
            for s in surf | {key}:
                k = s if is_abbreviation(s) else s.casefold()
                if len(k) >= 2 and k.casefold() not in STOP_NAMES:
                    self.matcher.setdefault(k, key)
        self.max_ngram = max((len(k.split()) for k in self.matcher), default=1)
        self.encoder = encoder
        if emb is None and encoder is not None and triples:
            emb = encoder.encode_passages([statement(t["subject"], t["predicate"], t["object"]) for t in triples],
                                          show_progress=False)
        self.emb = emb
        self.build_seconds = time.perf_counter() - t0
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        self.peak_memory_mb = peak / 2**20

    def seeds(self, text: str) -> set[str]:
        words = re.findall(r"[A-Za-z0-9][A-Za-z0-9\-/]*", text)
        found = set()
        for n in range(1, self.max_ngram + 1):
            for i in range(len(words) - n + 1):
                span = " ".join(words[i:i + n])
                k = span if is_abbreviation(span) else span.casefold()
                if k in self.matcher:
                    found.add(self.matcher[k])
        return found

    def expand(self, seeds: set[str], hops: int) -> dict[str, int]:
        """triple_id -> hop distance (1 or 2), deterministic."""
        dist: dict[str, int] = {}
        frontier = set(seeds)
        visited = set(seeds)
        for h in range(1, hops + 1):
            nxt = set()
            for node in sorted(frontier):
                for tid in self.incident.get(node, []):
                    if tid not in dist:
                        dist[tid] = h
                    t = self.by_id[tid]
                    for other in (t["subject_key"], t["object_key"]):
                        if other not in visited:
                            nxt.add(other)
            visited |= nxt
            frontier = nxt
        return dist

    def relevance(self, qvec: np.ndarray, tids: list[str]) -> np.ndarray:
        if self.emb is None or not tids:
            return np.zeros(len(tids))
        return self.emb[[self.pos[t] for t in tids]] @ np.ravel(qvec)

    def select(self, *, qvec, seed_text: str, hops: int, triple_budget: int | None, token_cap: int | None,
               count, mode: str = "selective", rng_seed: int = 0, n_random: int | None = None,
               label_start: int = 1) -> dict:
        """mode: selective (Configuration C/D), unfiltered (control), random (control).
        Stops at the first statement that would exceed `token_cap` (the binding limit is logged)."""
        t0 = time.perf_counter()
        seeds = self.seeds(seed_text)
        dist = self.expand(seeds, hops)
        cands = sorted(dist)
        if mode == "selective":
            sc = self.relevance(qvec, cands)
            order = [c for _, c in sorted(zip(-sc, cands), key=lambda x: (x[0], dist[x[1]], x[1]))]
            limit = triple_budget
        elif mode == "unfiltered":
            order = sorted(cands, key=lambda c: (dist[c], c))
            limit = None  # until the token allocation is reached (Sec. 3.5)
        elif mode == "random":
            rng = random.Random(rng_seed)
            order = rng.sample(self.ids, min(len(self.ids), max(0, n_random or 0) * 3 + 50))
            limit = n_random
        else:
            raise ValueError(mode)
        if hasattr(count, "prefetch"):  # API-count mode: count the likely statements in parallel first
            k = (limit or 40) + 5
            count.prefetch([render_statement(self.by_id[t], f"G{label_start + i}") for i, t in enumerate(order[:k])])
        chosen, toks, stop_reason = [], 0, "exhausted_candidates"
        for tid in order:
            if limit is not None and len(chosen) >= limit:
                stop_reason = "triple_budget"
                break
            text = render_statement(self.by_id[tid], f"G{label_start + len(chosen)}")
            n = count(text)
            if token_cap is not None and toks + n > token_cap:
                stop_reason = "token_cap"
                break
            chosen.append({"triple_id": tid, "text": text, "tokens": n, "hop": dist.get(tid),
                           "source_passage_ids": [p["passage_id"] for p in self.by_id[tid]["provenance"]]})
            toks += n
        return {"items": chosen, "graph_tokens": toks, "n_seeds": len(seeds), "n_candidates": len(cands),
                "stop_reason": stop_reason, "lookup_latency_s": time.perf_counter() - t0}


def load(project: Project, encoder=None) -> KGIndex:
    tr = read_jsonl(project.path("processed", "kg_triples_validated.jsonl"))
    cache = project.path("interim", "kg_statement_emb.npy")
    key = project.path("interim", "kg_statement_emb.key")
    sig = sha256_text("|".join(t["triple_id"] for t in tr))
    emb = np.load(cache) if (cache.exists() and key.exists() and key.read_text() == sig) else None
    kg = KGIndex(tr, encoder, emb)
    if emb is None and kg.emb is not None:
        np.save(cache, kg.emb)
        key.write_text(sig)
    return kg
