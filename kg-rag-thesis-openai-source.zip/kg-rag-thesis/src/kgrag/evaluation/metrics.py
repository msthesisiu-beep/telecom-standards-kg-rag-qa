"""Stage 16 (script-computed constructs, Table 3.6). Each construct is computed independently."""
from __future__ import annotations


def retrieval_metrics(ranking_ids: list[str], context_ids: list[str], gold: set[str], ks=(1, 3, 5)) -> dict:
    """Recall@k / MRR on the configuration's passage RANKING (B and C share it by design) and full-coverage recall on
    the passages actually supplied. Gold = independently validated passages (never the experimental retriever)."""
    out = {}
    for k in ks:
        out[f"recall_at_{k}"] = int(any(p in gold for p in ranking_ids[:k])) if ranking_ids else 0
    rr = 0.0
    for i, p in enumerate(ranking_ids, 1):
        if p in gold:
            rr = 1.0 / i
            break
    out["mrr"] = rr if ranking_ids else 0.0
    out["context_recall_any"] = int(bool(gold & set(context_ids)))
    out["full_coverage"] = int(bool(gold) and gold <= set(context_ids))
    return out


def citation_metrics(citations: list[str], labels: dict, gold: set[str]) -> dict:
    """Validity: cited label exists in the supplied context. Support: cited item's source passage is gold.
    Graph statements count as citations of their source clause and are flagged graph-sourced. None if no citations."""
    cits = [c for c in dict.fromkeys(citations) if c]
    if not cits:
        return {"n_citations": 0, "citation_validity": None, "citation_support": None,
                "n_graph_citations": 0, "graph_citation_support": None, "passage_citation_support": None}
    valid = [c for c in cits if c in labels]
    sup = lambda c: int(bool(set(labels[c]["source_passage_ids"]) & gold))
    g = [c for c in valid if labels[c]["kind"] == "G"]
    p = [c for c in valid if labels[c]["kind"] == "P"]
    return {"n_citations": len(cits), "citation_validity": len(valid) / len(cits),
            "citation_support": sum(sup(c) for c in valid) / len(cits),
            "n_graph_citations": len(g), "graph_citation_support": (sum(sup(c) for c in g) / len(g)) if g else None,
            "passage_citation_support": (sum(sup(c) for c in p) / len(p)) if p else None}


def triple_metrics(labels: dict, gold: set[str], valid_passage_ids: set[str], judged: dict[str, int] | None = None,
                   release_of: dict | None = None, release: str = "17") -> dict:
    g = [v for v in labels.values() if v["kind"] == "G"]
    if not g:
        return {"n_triples": 0, "provenance_validity": None, "gold_linked_precision": None, "judged_relevant_precision": None}
    prov = [int(all(s in valid_passage_ids and (release_of or {}).get(s, release) == release for s in v["source_passage_ids"])
                and bool(v["source_passage_ids"])) for v in g]
    linked = [int(bool(set(v["source_passage_ids"]) & gold)) for v in g]
    jr = None
    if judged is not None:
        vals = [judged.get(v["ref"]) for v in g]
        vals = [x for x in vals if x is not None]
        jr = sum(vals) / len(vals) if vals else None
    return {"n_triples": len(g), "provenance_validity": sum(prov) / len(g), "gold_linked_precision": sum(linked) / len(g),
            "judged_relevant_precision": jr}
