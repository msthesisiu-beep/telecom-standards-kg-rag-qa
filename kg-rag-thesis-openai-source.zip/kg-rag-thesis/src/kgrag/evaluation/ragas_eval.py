"""RAGAs-protocol evaluator (Sec. 3.6): faithfulness (full context and passages-only), answer relevance, context
precision and context recall, computed with a FIXED evaluator model (role `evaluator`, distinct from generator and
verifier).

Implementation note (documented deviation, compliance matrix C-24): the metric definitions and two-step procedures of
RAGAs (Es et al., 2024) are re-implemented here with fixed prompts so that the evaluator can be a Gemini model through
the same audited client. The `ragas` package API changes frequently and is not pinned for Gemini 3.x; scores are
therefore labelled "RAGAs-protocol". Missing scores are recorded as None and NEVER imputed (Sec. 3.7).
"""
from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import numpy as np

from ..core import Project, append_jsonl, iter_jsonl, utc_now
from ..llm import LLMClient

PROMPT_VERSION = "ragas-protocol-v1.0"

ST_SCHEMA = {"type": "object", "properties": {"statements": {"type": "array", "items": {"type": "string"}}},
             "required": ["statements"]}
NLI_SCHEMA = {"type": "object", "properties": {"verdicts": {"type": "array", "items": {"type": "object", "properties": {
    "n": {"type": "integer"}, "verdict": {"type": "integer", "enum": [0, 1]}, "reason": {"type": "string"}},
    "required": ["n", "verdict"]}}}, "required": ["verdicts"]}
AR_SCHEMA = {"type": "object", "properties": {"questions": {"type": "array", "items": {"type": "string"}},
                                              "noncommittal": {"type": "integer", "enum": [0, 1]}},
             "required": ["questions", "noncommittal"]}
CP_SCHEMA = {"type": "object", "properties": {"verdicts": {"type": "array", "items": {"type": "object", "properties": {
    "n": {"type": "integer"}, "useful": {"type": "integer", "enum": [0, 1]}}, "required": ["n", "useful"]}}},
    "required": ["verdicts"]}

P_STATEMENTS = """Break the ANSWER into simple, self-contained factual statements (resolve pronouns). Return JSON {{"statements": [...]}}.
QUESTION: {question}
ANSWER: {answer}"""
P_NLI = """For each STATEMENT decide whether it can be directly inferred from the CONTEXT (1) or not (0).
CONTEXT:
{context}

STATEMENTS:
{statements}"""
P_AR = """Generate {n} questions that the ANSWER below would answer. Also set noncommittal = 1 if the answer is evasive,
vague or says it does not know, else 0.
ANSWER: {answer}"""
P_CP = """REFERENCE ANSWER to the QUESTION: {reference}
QUESTION: {question}
For each numbered CONTEXT item decide whether it was useful in arriving at the reference answer (1) or not (0).
{items}"""
P_CR = """For each STATEMENT of the REFERENCE ANSWER decide whether it can be attributed to the CONTEXT (1) or not (0).
CONTEXT:
{context}

STATEMENTS:
{statements}"""


def _verdicts(r, n: int, key: str = "verdict") -> list[int] | None:
    if not r.ok:
        return None
    d = {int(v.get("n", 0)): int(v.get(key, 0)) for v in r.data.get("verdicts", [])}
    return [d.get(i + 1, 0) for i in range(n)] if n else []


def answer_text(rec: dict, q: dict) -> str:
    opt = rec.get("parsed_option")
    chosen = f"Selected option {opt}: {q['options'].get(opt, '')}. " if opt else ""
    return (chosen + (rec.get("justification") or "")).strip()


def evaluate_record(llm: LLMClient, emb, rec: dict, q: dict, n_q: int = 3) -> dict:
    t0 = time.perf_counter()
    out = {"key": rec["key"], "prompt_version": PROMPT_VERSION, "evaluator_model": llm.model_of("evaluator"),
           "costs": [], "errors": []}
    ans = answer_text(rec, q)
    log = lambda r: (out["costs"].append(r.cost_usd or 0.0), r.error and out["errors"].append(r.error))
    # --- faithfulness (two context versions)
    stm = None
    if rec.get("context_text") and ans:
        r = llm.generate_json("evaluator", P_STATEMENTS.format(question=q["question"], answer=ans), ST_SCHEMA)
        log(r)
        stm = [s for s in (r.data or {}).get("statements", []) if s.strip()] if r.ok else None
    for name, ctx in (("faithfulness_full", rec.get("context_text")), ("faithfulness_passages", rec.get("context_text_passages_only"))):
        if not ctx or stm is None or len(stm) == 0:
            out[name] = None
            continue
        r = llm.generate_json("evaluator", P_NLI.format(context=ctx, statements="\n".join(f"{i + 1}. {s}" for i, s in enumerate(stm))), NLI_SCHEMA)
        log(r)
        v = _verdicts(r, len(stm))
        out[name] = (sum(v) / len(v)) if v else None
    out["n_statements"] = len(stm) if stm else 0
    # --- answer relevance (mean cosine of generated questions to the original; 0 if noncommittal)
    if ans:
        r = llm.generate_json("evaluator", P_AR.format(n=n_q, answer=ans), AR_SCHEMA)
        log(r)
        if r.ok and r.data.get("questions"):
            gq = [x for x in r.data["questions"] if x.strip()][:n_q]
            E = emb.encode_queries([q["question"]] + gq)
            cos = float(np.mean(E[1:] @ E[0]))
            out["answer_relevance"] = 0.0 if int(r.data.get("noncommittal", 0)) else cos
        else:
            out["answer_relevance"] = None
    else:
        out["answer_relevance"] = None
    # --- context precision / recall against the TeleQnA reference
    reference = f"{q['options'].get(q['answer_option_id'], '')}. {q.get('explanation', '')}".strip()
    items = rec.get("context_items") or []
    if items:
        r = llm.generate_json("evaluator", P_CP.format(reference=reference, question=q["question"],
                              items="\n\n".join(f"{i + 1}. {t}" for i, t in enumerate(items))), CP_SCHEMA)
        log(r)
        v = _verdicts(r, len(items), "useful")
        if v is not None:
            num, hits = 0.0, 0
            for k, u in enumerate(v, 1):
                if u:
                    hits += 1
                    num += hits / k
            out["context_precision"] = (num / hits) if hits else 0.0
        else:
            out["context_precision"] = None
        r = llm.generate_json("evaluator", P_STATEMENTS.format(question=q["question"], answer=reference), ST_SCHEMA)
        log(r)
        rs = [s for s in (r.data or {}).get("statements", []) if s.strip()] if r.ok else []
        if rs:
            r2 = llm.generate_json("evaluator", P_CR.format(context=rec["context_text"], statements="\n".join(
                f"{i + 1}. {s}" for i, s in enumerate(rs))), NLI_SCHEMA)
            log(r2)
            v = _verdicts(r2, len(rs))
            out["context_recall"] = (sum(v) / len(v)) if v else None
        else:
            out["context_recall"] = None
    else:
        out["context_precision"] = out["context_recall"] = None
    out["evaluation_latency_s"] = time.perf_counter() - t0
    out["evaluation_cost_usd"] = sum(out.pop("costs"))
    out["status"] = "ok" if not out["errors"] else "partial_error"
    out["utc"] = utc_now()
    return out


def run(project: Project, llm: LLMClient, emb, gen_log: str, questions: dict, conditions: set[str] | None,
        out_name: str, workers: int | None = None) -> str:
    out = project.path("test" if "heldout" in out_name else "dev", out_name)
    done = {r["key"] for r in iter_jsonl(out) if r.get("status") == "ok"}
    recs = [r for r in iter_jsonl(gen_log) if r.get("status") == "ok" and r["key"] not in done
            and (conditions is None or r["condition"] in conditions)]
    with ThreadPoolExecutor(workers or project.study["experiment"]["workers"]) as ex:
        futs = [ex.submit(evaluate_record, llm, emb, r, questions[r["question_id"]]) for r in recs]
        for f in as_completed(futs):
            append_jsonl(out, f.result())
    return str(out)
