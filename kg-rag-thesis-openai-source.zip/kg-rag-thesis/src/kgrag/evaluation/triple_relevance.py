"""Judged triple relevance (Sec. 3.6): an independent verifier (role `verifier`), given the question, keyed option and
the triple's source passage, judges whether each appended triple helps establish the keyed answer. One judgement per
(question, triple) — identical across conditions, so it cannot favour any configuration."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed

from ..core import Project, append_jsonl, iter_jsonl, utc_now
from ..knowledge_graph.fidelity import statement
from ..llm import LLMClient

PROMPT_VERSION = "triple-relevance-v1.0"
SCHEMA = {"type": "object", "properties": {"judgements": {"type": "array", "items": {"type": "object", "properties": {
    "n": {"type": "integer"}, "helpful": {"type": "integer", "enum": [0, 1]}}, "required": ["n", "helpful"]}}},
    "required": ["judgements"]}
TEMPLATE = """QUESTION: {question}
KEYED (correct) OPTION: {key}

For each numbered knowledge-graph statement (with its source passage), decide whether it helps establish that the keyed
option is correct (1) or not (0).

{items}"""


def judge_question(llm: LLMClient, q: dict, triples: list[dict], passages: dict) -> list[dict]:
    items = "\n\n".join(f"{i + 1}. STATEMENT: {statement(t['subject'], t['predicate'], t['object'])}\n   SOURCE "
                        f"[{t['provenance'][0]['passage_id']}]: {passages[t['provenance'][0]['passage_id']]['text'][:1500]}"
                        for i, t in enumerate(triples))
    r = llm.generate_json("verifier", TEMPLATE.format(question=q["question"],
                                                      key=q["options"].get(q["answer_option_id"], ""), items=items), SCHEMA)
    d = {int(j.get("n", 0)): int(j.get("helpful", 0)) for j in (r.data or {}).get("judgements", [])} if r.ok else {}
    return [{"question_id": q["question_id"], "triple_id": t["triple_id"], "helpful": d.get(i + 1),
             "status": "ok" if (i + 1) in d else "error", "model": r.model, "prompt_version": PROMPT_VERSION,
             "cost_usd": r.cost_usd if i == 0 else 0.0, "utc": utc_now()} for i, t in enumerate(triples)]


def run(project: Project, llm: LLMClient, gen_logs: list[str], questions: dict, kg_by_id: dict, passages: dict,
        workers: int | None = None, batch: int = 15) -> str:
    out = project.path("test", "triple_relevance.jsonl")
    done = {(r["question_id"], r["triple_id"]) for r in iter_jsonl(out) if r.get("status") == "ok"}
    need: dict[str, set] = {}
    for lg in gen_logs:
        for r in iter_jsonl(lg):
            if r.get("status") == "ok":
                for tid in r.get("kg_triple_ids", []):
                    if (r["question_id"], tid) not in done:
                        need.setdefault(r["question_id"], set()).add(tid)
    jobs = [(questions[qid], [kg_by_id[t] for t in sorted(ts)[i:i + batch]])
            for qid, ts in need.items() for i in range(0, len(ts), batch)]
    with ThreadPoolExecutor(workers or project.study["experiment"]["workers"]) as ex:
        for f in as_completed([ex.submit(judge_question, llm, q, ts, passages) for q, ts in jobs]):
            for row in f.result():
                append_jsonl(out, row)
    return str(out)


def load(project: Project) -> dict[tuple[str, str], int]:
    return {(r["question_id"], r["triple_id"]): r["helpful"] for r in iter_jsonl(project.path("test", "triple_relevance.jsonl"))
            if r.get("status") == "ok"}
