"""Consolidated per-question log and every pre-specified test family (Sec. 3.7, Table 3.8, Appendix 6).

Raw logs (append-only JSONL) are never modified; this module derives analysis tables from them.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core import Project, iter_jsonl, read_json, write_json, utc_now
from ..evaluation.metrics import citation_metrics, retrieval_metrics, triple_metrics
from .tests import B_RESAMPLES, SEED, bootstrap_mean_ci, holm, mcnemar_exact, paired_bootstrap_ci, wilcoxon_paired

CONT = ["faithfulness_full", "faithfulness_passages", "answer_relevance", "context_precision", "context_recall",
        "mrr", "citation_validity", "citation_support", "gold_linked_precision", "judged_relevant_precision",
        "latency_total_s", "retrieval_latency_s", "rerank_latency_s", "kg_lookup_latency_s", "generation_latency_s",
        "input_tokens", "output_tokens", "graph_tokens", "evidence_tokens", "cost_usd", "provenance_validity",
        "evaluation_latency_s", "evaluation_cost_usd"]
BIN = ["correct", "answer_valid", "recall_at_1", "recall_at_3", "recall_at_5", "full_coverage", "context_recall_any"]


def per_run_table(gen_logs: list[str], eval_logs: list[str], gold: dict, valid_pids: set, judged: dict) -> pd.DataFrame:
    ev = {}
    for lg in eval_logs:
        for r in iter_jsonl(lg):
            if r.get("status") in ("ok", "partial_error"):
                ev[r["key"]] = r
    rows = []
    for lg in gen_logs:
        for r in iter_jsonl(lg):
            if r.get("status") != "ok":
                continue
            g = set(gold[r["question_id"]]["reference_passage_ids"])
            labels = r.get("context_labels", {})
            row = {k: r.get(k) for k in ("key", "experiment_id", "run_id", "question_id", "split", "configuration",
                                         "condition", "budget_mode", "triple_budget", "hop_depth", "graph_alloc",
                                         "hop_type", "question_type", "retriever_group", "correct", "answer_valid",
                                         "retrieval_latency_s", "rerank_latency_s", "kg_lookup_latency_s",
                                         "generation_latency_s", "input_tokens", "output_tokens", "graph_tokens",
                                         "evidence_tokens", "T_q", "cost_usd", "ranking_invariance_ok")}
            row["latency_total_s"] = r.get("total_latency_s")
            bc = r.get("budget_checks") or {}
            row.update({f"chk_{k}": v for k, v in bc.items() if isinstance(v, (bool, int, float)) or v is None})
            km = r.get("kg_meta") or {}
            row.update(realised_triples=km.get("realised_triples"), requested_triples=km.get("requested_triples"),
                       kg_stop_reason=km.get("stop_reason"))
            if r["configuration"] != "0":
                row.update(retrieval_metrics(r.get("ranking_list_ids", []), r.get("final_passage_ids", []), g))
            row.update(citation_metrics(r.get("citations", []), labels, g))
            row.update(triple_metrics(labels, g, valid_pids, {t: judged.get((r["question_id"], t)) for t in r.get("kg_triple_ids", [])}))
            e = ev.get(r["key"], {})
            for k in ("faithfulness_full", "faithfulness_passages", "answer_relevance", "context_precision",
                      "context_recall", "evaluation_latency_s", "evaluation_cost_usd"):
                row[k] = e.get(k)
            rows.append(row)
    return pd.DataFrame(rows)


def per_question_table(runs: pd.DataFrame) -> pd.DataFrame:
    """Repeated runs: majority correctness for binary accuracy, mean for continuous measures (Sec. 3.7)."""
    keys = ["experiment_id", "condition", "question_id"]
    first = runs.groupby(keys, as_index=False).first()[keys + ["split", "configuration", "budget_mode", "triple_budget",
                                                              "hop_depth", "graph_alloc", "hop_type", "question_type",
                                                              "retriever_group"]]
    num = runs.copy()
    for c in CONT + BIN:
        if c in num:
            num[c] = pd.to_numeric(num[c], errors="coerce")
    agg = num.groupby(keys).agg({**{c: "mean" for c in CONT if c in num}, **{c: "mean" for c in BIN if c in num},
                                 "run_id": "nunique"}).reset_index().rename(columns={"run_id": "n_runs"})
    agg["correct"] = (agg["correct"] >= 0.5).astype(int)  # majority of 3 (or the single run)
    return first.merge(agg, on=keys)


def _pivot(pq: pd.DataFrame, metric: str, a: str, b: str, sub: pd.Series | None = None):
    d = pq if sub is None else pq[sub]
    w = d.pivot_table(index="question_id", columns="condition", values=metric, aggfunc="first")
    if a not in w or b not in w:
        return None, None
    return w[a].to_numpy(float), w[b].to_numpy(float)


def compare(pq, family, label, ref, alt, metric, test, sub=None, scale_ci=1.0) -> dict:
    x, y = _pivot(pq, metric, ref, alt, sub)
    base = {"family": family, "comparison": label, "reference": ref, "compared": alt, "metric": metric}
    if x is None:
        return {**base, "note": "condition missing", "p_raw": np.nan}
    res = mcnemar_exact(x, y) if test == "mcnemar_exact" else wilcoxon_paired(x, y)
    scale = 100.0 if test == "mcnemar_exact" else scale_ci
    lo, hi = paired_bootstrap_ci(x, y, n_boot=B_RESAMPLES, seed=SEED, scale=scale)
    return {**base, **res, "ci95_low": lo, "ci95_high": hi, "ci_units": "percentage points" if scale == 100 else "metric units"}


def run_families(project: Project, pq: pd.DataFrame) -> pd.DataFrame:
    fz = read_json(project.path("reports", "frozen_parameters.json"))
    d = project.study["experiment"]["default_variant"]
    tag = lambda t, h, a: f"t{t}_h{h}_g{int(round(a * 100))}"
    dflt = tag(d["triples"], d["hops"], d["alloc"])
    C, D = f"C_{dflt}_matched", f"D_{dflt}_matched"
    R, U, CO = f"RANDOM_{dflt}_matched", f"UNFILTERED_{dflt}_matched", f"C_{dflt}_overhead"
    variants = list(dict.fromkeys(f"C_{tag(v['triples'], v['hops'], v['alloc'])}_matched" for v in fz["selected_variants"]))
    rows = [compare(pq, "1_confirmatory", "B vs C(default), matched", "B", C, "correct", "mcnemar_exact")]
    fam = lambda name, items: [{**compare(pq, name, *it), } for it in items]
    rows += fam("2_variants", [(f"B vs {v}", "B", v, "correct", "mcnemar_exact") for v in variants])
    rows += fam("3_controls", [("C(default) vs random-triple", C, R, "correct", "mcnemar_exact"),
                               ("C(default) vs unfiltered-expansion", C, U, "correct", "mcnemar_exact")])
    rows += fam("4_placement", [("C(default) vs D(default)", C, D, "correct", "mcnemar_exact")])
    subs = {"single-hop": pq.hop_type == "single-hop", "multi-hop": pq.hop_type == "multi-hop",
            "retriever-found": pq.retriever_group == "retriever-found",
            "independent-only": pq.retriever_group == "independent-only"}
    rows += [compare(pq, "5_subgroups", f"B vs C(default) [{k}]", "B", C, "correct", "mcnemar_exact", s) for k, s in subs.items()]
    rows += fam("6_secondary", [(f"B vs C(default): {m}", "B", C, m, "wilcoxon") for m in
                                ["faithfulness_full", "faithfulness_passages", "answer_relevance", "context_precision",
                                 "context_recall", "citation_validity", "citation_support"]])
    rows += fam("7_cost", [("B vs C(default): end-to-end latency", "B", C, "latency_total_s", "wilcoxon")])
    # exploratory, outside Table 3.8 (reported with Holm within family, clearly labelled)
    rows += fam("8_exploratory_retrieval", [("A vs B: Recall@5", "A_matched", "B", "recall_at_5", "mcnemar_exact"),
                                            ("A vs B: full coverage", "A_matched", "B", "full_coverage", "mcnemar_exact"),
                                            ("B vs D: full coverage", "B", D, "full_coverage", "mcnemar_exact"),
                                            ("C vs D: full coverage", C, D, "full_coverage", "mcnemar_exact")])
    rows += fam("9_exploratory_overhead_mode", [(f"B vs {v.replace('_matched', '_overhead')}", "B",
                                                 v.replace("_matched", "_overhead"), "correct", "mcnemar_exact") for v in variants])
    rows += fam("10_exploratory_references", [("0 (closed-book) vs B", "0", "B", "correct", "mcnemar_exact"),
                                              ("A vs B", "A_matched", "B", "correct", "mcnemar_exact")])
    df = pd.DataFrame(rows)
    df["p_adjusted"] = np.nan
    for f, g in df.groupby("family"):
        if f == "1_confirmatory":
            df.loc[g.index, "p_adjusted"] = g.p_raw  # single prespecified test: not adjusted
        else:
            df.loc[g.index, "p_adjusted"] = holm(g.p_raw.tolist())
    df["adjustment"] = np.where(df.family == "1_confirmatory", "none", "holm within family")
    sig = (df.p_adjusted < 0.05) & ((df.ci95_low > 0) | (df.ci95_high < 0))
    df["interpretation"] = np.where(sig, np.where(df.ci95_low > 0, "improvement (compared > reference)",
                                                  "decrease (compared < reference)"),
                                    "no supported difference (not evidence of equivalence)")
    return df


def descriptive(pq: pd.DataFrame) -> pd.DataFrame:
    out = []
    for cond, g in pq.groupby("condition"):
        r = {"condition": cond, "configuration": g.configuration.iloc[0], "budget_mode": g.budget_mode.iloc[0], "n": len(g)}
        for m in ["correct", "recall_at_1", "recall_at_3", "recall_at_5", "full_coverage", "mrr", "faithfulness_full",
                  "faithfulness_passages", "answer_relevance", "context_precision", "context_recall",
                  "citation_validity", "citation_support", "gold_linked_precision", "judged_relevant_precision",
                  "provenance_validity"]:
            if m in g:
                v = pd.to_numeric(g[m], errors="coerce")
                r[m], r[f"{m}_n"] = v.mean(), int(v.notna().sum())
        lo, hi = bootstrap_mean_ci(g.correct, scale=100)
        r.update(accuracy_pct=100 * g.correct.mean(), accuracy_ci95_low=lo, accuracy_ci95_high=hi)
        for m in ["latency_total_s", "retrieval_latency_s", "rerank_latency_s", "kg_lookup_latency_s", "generation_latency_s",
                  "input_tokens", "output_tokens", "graph_tokens", "evidence_tokens", "cost_usd"]:
            if m in g:
                v = pd.to_numeric(g[m], errors="coerce").dropna()
                if len(v):
                    r.update({f"{m}_median": v.median(), f"{m}_iqr": v.quantile(.75) - v.quantile(.25),
                              f"{m}_p95": v.quantile(.95), f"{m}_mean": v.mean()})
        if "cost_usd" in g:
            c = pd.to_numeric(g.cost_usd, errors="coerce")
            r["generation_cost_usd_per_1000_questions"] = 1000 * c.mean() if c.notna().any() else None
        if "evaluation_cost_usd" in g:
            c = pd.to_numeric(g.evaluation_cost_usd, errors="coerce")
            r["evaluation_cost_usd_per_1000_questions"] = 1000 * c.mean() if c.notna().any() else None
        out.append(r)
    return pd.DataFrame(out)


def quality_cost(desc: pd.DataFrame, reference: str = "B") -> pd.DataFrame:
    """Accuracy gain per +1k tokens and per +100 ms vs B; Pareto efficiency; 'limited value' flags (Sec. 3.6)."""
    ref = desc.set_index("condition").loc[reference]
    rows = []
    for _, r in desc.iterrows():
        if r.condition == reference:
            continue
        dacc = r.accuracy_pct - ref.accuracy_pct
        dtok = r.get("input_tokens_median", np.nan) - ref.get("input_tokens_median", np.nan)
        dlat = 1000 * (r.get("latency_total_s_median", np.nan) - ref.get("latency_total_s_median", np.nan))
        rows.append({"condition": r.condition, "budget_mode": r.budget_mode, "delta_accuracy_pp": dacc,
                     "delta_input_tokens_median": dtok, "delta_latency_ms_median": dlat,
                     "acc_pp_per_1k_extra_tokens": dacc / (dtok / 1000) if dtok and dtok > 0 else None,
                     "acc_pp_per_100ms_extra": dacc / (dlat / 100) if dlat and dlat > 0 else None,
                     "ratio_note": "undefined: no additional cost" if not (dtok and dtok > 0) else "",
                     "limited_value_flag": bool(dacc > 0 and any(
                         pd.notna(r.get(m)) and pd.notna(ref.get(m)) and r.get(m) < ref.get(m)
                         for m in ("faithfulness_full", "citation_support"))),
                     "accuracy_pct": r.accuracy_pct, "input_tokens_median": r.get("input_tokens_median"),
                     "latency_total_s_median": r.get("latency_total_s_median")})
    qc = pd.DataFrame(rows)
    allc = pd.concat([qc, pd.DataFrame([{"condition": reference, "accuracy_pct": ref.accuracy_pct,
                                          "input_tokens_median": ref.get("input_tokens_median"),
                                          "latency_total_s_median": ref.get("latency_total_s_median")}])])
    eff = []
    for _, r in allc.iterrows():
        dom = ((allc.accuracy_pct > r.accuracy_pct) & (allc.input_tokens_median <= r.input_tokens_median)).any() or \
              ((allc.accuracy_pct >= r.accuracy_pct) & (allc.input_tokens_median < r.input_tokens_median)).any()
        eff.append({"condition": r.condition, "pareto_efficient_tokens": not dom})
    return allc.merge(pd.DataFrame(eff), on="condition")


def budget_compliance(pq_runs: pd.DataFrame) -> pd.DataFrame:
    m = pq_runs[pq_runs.budget_mode == "matched"]
    cols = [c for c in ["chk_within_tolerance", "chk_not_over_budget", "chk_graph_cap_ok", "chk_passage_prefix_of_B",
                        "chk_underfill_due_to_unused_graph_allocation", "ranking_invariance_ok"] if c in m]
    return m.groupby("condition")[cols].agg(lambda s: pd.to_numeric(s, errors="coerce").mean()).reset_index()
