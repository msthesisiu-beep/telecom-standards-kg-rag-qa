"""Appendix 6 statistical functions, hardened for edge cases without changing the design (Sec. 3.7, Tables 3.7-3.8)."""
from __future__ import annotations

import numpy as np
from scipy.stats import rankdata, wilcoxon
from statsmodels.stats.contingency_tables import mcnemar
from statsmodels.stats.multitest import multipletests

SEED, B_RESAMPLES = 42, 10_000


def _pairs(ref, alt) -> tuple[np.ndarray, np.ndarray, int]:
    ref, alt = np.asarray(ref, float), np.asarray(alt, float)
    ok = ~(np.isnan(ref) | np.isnan(alt))  # pairwise exclusion; never impute (Sec. 3.7)
    return ref[ok], alt[ok], int((~ok).sum())


def mcnemar_exact(ref, alt) -> dict:
    """ref, alt: 0/1 over the same questions. b = correct only in reference, c = correct only in compared."""
    ref, alt, n_excl = _pairs(ref, alt)
    ref, alt = ref.astype(int), alt.astype(int)
    n11 = int(((ref == 1) & (alt == 1)).sum())
    b = int(((ref == 1) & (alt == 0)).sum())
    c = int(((ref == 0) & (alt == 1)).sum())
    n00 = int(((ref == 0) & (alt == 0)).sum())
    p = 1.0 if b + c == 0 else float(mcnemar([[n11, b], [c, n00]], exact=True).pvalue)
    n = len(ref)
    return {"test": "mcnemar_exact", "n": n, "n_excluded_pairs": n_excl, "b": b, "c": c,
            "ref_rate": ref.mean() if n else np.nan, "alt_rate": alt.mean() if n else np.nan,
            "diff_pp": 100 * (alt.mean() - ref.mean()) if n else np.nan, "p_raw": p,
            "note": "no discordant pairs" if b + c == 0 else ""}


def rank_biserial(d: np.ndarray) -> float:
    d = d[d != 0]
    if not len(d):
        return 0.0
    r = rankdata(np.abs(d))
    wp, wm = r[d > 0].sum(), r[d < 0].sum()
    return float((wp - wm) / (wp + wm))


def wilcoxon_paired(ref, alt) -> dict:
    ref, alt, n_excl = _pairs(ref, alt)
    d = alt - ref
    nz = int((d != 0).sum())
    res = {"test": "wilcoxon_signed_rank", "n": len(d), "n_excluded_pairs": n_excl, "n_nonzero": nz,
           "mean_diff": float(d.mean()) if len(d) else np.nan, "median_diff": float(np.median(d)) if len(d) else np.nan,
           "rank_biserial_r": rank_biserial(d) if len(d) else np.nan}
    if len(d) == 0:
        res.update(p_raw=np.nan, note="no valid pairs")
    elif nz == 0:
        res.update(p_raw=1.0, note="all differences zero")
    else:
        res.update(p_raw=float(wilcoxon(alt, ref, zero_method="wilcox", alternative="two-sided", method="auto").pvalue),
                   note="" if nz >= 6 else "fewer than 6 non-zero differences: low power")
    return res


def paired_bootstrap_ci(ref, alt, stat=np.mean, n_boot: int = B_RESAMPLES, seed: int = SEED, scale: float = 1.0):
    ref, alt, _ = _pairs(ref, alt)
    d = (alt - ref) * scale
    if len(d) == 0:
        return (np.nan, np.nan)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(d), size=(n_boot, len(d)))  # question-level resampling, same for both configurations
    boots = stat(d[idx], axis=1)
    return tuple(float(x) for x in np.percentile(boots, [2.5, 97.5]))


def bootstrap_mean_ci(x, n_boot: int = B_RESAMPLES, seed: int = SEED, scale: float = 1.0):
    x = np.asarray(x, float)
    x = x[~np.isnan(x)] * scale
    if not len(x):
        return (np.nan, np.nan)
    rng = np.random.default_rng(seed)
    b = x[rng.integers(0, len(x), size=(n_boot, len(x)))].mean(axis=1)
    return tuple(float(v) for v in np.percentile(b, [2.5, 97.5]))


def holm(p_values) -> list[float]:
    p = np.asarray(p_values, float)
    out = np.full(len(p), np.nan)
    ok = ~np.isnan(p)
    if ok.any():
        out[ok] = multipletests(p[ok], alpha=0.05, method="holm")[1]
    return out.tolist()
