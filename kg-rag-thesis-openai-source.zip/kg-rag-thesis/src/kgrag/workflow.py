"""Stage-by-stage orchestration used by notebooks/KG_RAG_Raju_KSR_v2.ipynb. Every function reloads its inputs from
disk (Colab runtimes restart), is resumable, and updates the gate tracker only from actual outputs."""
from __future__ import annotations

import json
import os
import subprocess
import sys

import pandas as pd

from .core import Project, Tracker, read_json, read_jsonl, write_json, utc_now
from . import env as envmod


# ------------------------------------------------------------------ helpers
def project(root: str) -> Project:
    return Project.load(root)


def llm(p: Project):
    from .llm import GeminiClient, OpenAIClient
    provider = p.models.get("provider", "google-gemini-api")
    if provider == "openai":
        return OpenAIClient(p.models, budget_path=p.path("reports", "openai_budget.json"))
    if provider == "google-gemini-api":
        return GeminiClient(p.models)
    raise ValueError(f"Unsupported LLM provider in configs/models.yaml: {provider!r}")


def passages_dict(p: Project, retrieval_only: bool = False) -> dict:
    from .data.corpus import load_passages
    return {x["passage_id"]: x for x in load_passages(p, retrieval_only)}


def candidates_dict(p: Project) -> dict:
    return {q["question_id"]: q for q in read_jsonl(p.path("interim", "teleqna_candidates.jsonl"))}


def cost_of(path, key="cost_usd") -> float:
    tot = 0.0
    for r in read_jsonl(path):
        if "calls" in r:
            tot += sum((c.get("cost_usd") or 0) for c in r["calls"])
        else:
            tot += r.get(key) or r.get("batch_cost_usd") or 0
    return tot


# ------------------------------------------------------------------ Gate 1
def gate1(p: Project) -> dict:
    t = Tracker(p)
    e = envmod.capture(p)
    tests = subprocess.run([sys.executable, "-m", "pytest", "-q", str(p.root / "tests")], capture_output=True, text=True)
    (p.path("reports", "unit_tests.txt")).write_text(tests.stdout[-5000:] + tests.stderr[-2000:])
    client = llm(p)
    avail = set(client.list_models())
    roles = {r: (c["model"], c["model"] in avail) for r, c in p.models["roles"].items()}
    probe = {}
    for r, (m, ok) in roles.items():
        if ok:
            res = client.generate_json(r, 'Return JSON {"ok": true}', {"type": "object", "properties": {"ok": {"type": "boolean"}}, "required": ["ok"]})
            probe[r] = {"model": m, "ok": res.ok, "model_version": res.model_version, "error": res.error}
        else:
            probe[r] = {"model": m, "ok": False, "error": "model id not listed for this key"}
    out = {"tests_passed": tests.returncode == 0, "tests_tail": tests.stdout.strip().splitlines()[-1:],
           "role_probes": probe, "gpu": e["gpu"]}
    write_json(p.path("reports", "gate1_check.json"), out)
    ok = out["tests_passed"] and all(v["ok"] for v in probe.values())
    t.set(1, "VALIDATED" if ok else "BLOCKED", ["reports/environment.json", "reports/gate1_check.json"],
          "" if ok else "see gate1_check.json")
    return out


# ------------------------------------------------------------------ Gates 2-3
def stage3_4(p: Project, hf_token: str | None, check_archive: bool = True) -> dict:
    from .data import teleqna, tspec, corpus
    t = Tracker(p)
    teleqna.download(p)
    cand = teleqna.load_candidates(p)
    dl = tspec.download(p, token=hf_token)
    man = tspec.build_manifest(p, check_archive=check_archive)
    docs = man["documents"]
    verified = sum(d["status"] == "VERIFIED" for d in docs)
    t.set(2, "VALIDATED" if verified == len(p.study["corpus"]["specs"]) and not man["mixed_releases"] else "TESTED",
          "data/manifests/corpus_manifest.json", f"{verified}/{len(docs)} specs verified against 3GPP archive")
    stats = corpus.build(p)
    ok = (stats.duplicate_ids.sum() == 0 and stats.empty_passages.sum() == 0 and (stats.normative_lost <= 0).all()
          and stats.version_consistent.all())
    t.set(3, "VALIDATED" if ok else "TESTED", ["reports/corpus_quality_report.md", "results/corpus_statistics.csv"])
    return {"candidates": len(cand), "download": dl, "verified_specs": verified,
            "passages": int(stats.n_passages.sum()), "corpus_checks_ok": bool(ok)}


# ------------------------------------------------------------------ Gate 4
def pools(p: Project) -> int:
    from .retrieval.encoders import e5
    from .validation.pooling import build_pools
    from .data.corpus import load_passages
    out = build_pools(p, list(candidates_dict(p).values()), load_passages(p), e5())
    return len(out)


def verify(p: Project, limit: int | None = None) -> dict:
    from .validation import verifier
    pl = {r["question_id"]: r["pool"] for r in read_jsonl(p.path("interim", "candidate_pools.jsonl"))}
    path = verifier.run(p, llm(p), list(candidates_dict(p).values()), pl, passages_dict(p), limit=limit)
    recs = verifier.latest_records(p)
    n_ok = sum(r.get("status") == "ok" for r in recs.values())
    spent = cost_of(path)
    res = {"verified_ok": n_ok, "errors": sum(r.get("status") != "ok" for r in recs.values()), "cost_usd_so_far": spent,
           "projected_total_cost_usd": spent / max(1, n_ok) * len(candidates_dict(p)),
           "decisions": pd.Series([r.get("decision") for r in recs.values() if r.get("status") == "ok"]).value_counts().to_dict(),
           "reason_codes": pd.Series([r.get("reason_code") for r in recs.values() if r.get("status") == "ok"]).value_counts().to_dict()}
    if limit is None and res["errors"] == 0 and n_ok == len(candidates_dict(p)):
        Tracker(p).set(4, "VALIDATED", "data/interim/verifier_results.jsonl")
    return res


def register_and_audit(p: Project, round_no: int = 1) -> dict:
    from .validation import register, audit, verifier
    recs = verifier.latest_records(p)
    cand = candidates_dict(p)
    reg = register.build(p, list(cand.values()), recs)
    register.save(p, reg, register.flow_table(reg, recs))
    pl = {r["question_id"]: r["pool"] for r in read_jsonl(p.path("interim", "candidate_pools.jsonl"))}
    sheet, key = audit.make_question_audit(p, reg, cand, passages_dict(p), recs, pl, round_no)
    Tracker(p).set(5, "BLOCKED", sheet, "waiting for blind manual audit")
    return {"sheet": sheet, "included": int((reg.decision == "include").sum()), "excluded": int((reg.decision == "exclude").sum())}


# ------------------------------------------------------------------ Gate 5
def score_and_freeze(p: Project, round_no: int = 1) -> dict:
    from .validation import register, audit, verifier
    from .benchmark import freeze
    sc = audit.score_question_audit(p, round_no)
    if sc["status"] != "PASS":
        Tracker(p).set(5, "BLOCKED", f"reports/audit/question_audit_round{round_no}_score.json",
                       f"audit {sc['status']}: revise verifier prompt and audit a fresh sample (Sec. 3.3c)")
        return sc
    corr = pd.read_json(p.path("audit", f"question_audit_round{round_no}_corrections.json"))
    recs = verifier.latest_records(p)
    cand = candidates_dict(p)
    reg = register.build(p, list(cand.values()), recs, corr)
    register.save(p, reg, register.flow_table(reg, recs))
    n = int((reg.decision == "include").sum())
    if n < p.study["benchmark"]["min_questions"]:
        Tracker(p).set(5, "BLOCKED", "reports/inclusion_exclusion_log.csv",
                       f"only {n} questions qualify (< {p.study['benchmark']['min_questions']}): apply corpus expansion (TS 23.401, TS 33.501) and repeat Stages 3-6")
        return {**sc, "n_included": n, "status": "BELOW_MINIMUM"}
    man = freeze.freeze(p, reg, cand, passages_dict(p))
    Tracker(p).set(5, "VALIDATED", ["data/processed/FROZEN.json", f"reports/audit/question_audit_round{round_no}_score.json"])
    return {**sc, **man}


# ------------------------------------------------------------------ Gate 6
def retrieval_and_threshold(p: Project) -> dict:
    from .benchmark import freeze
    from .retrieval.dense import Retriever, run_and_label, question_text
    from .retrieval.encoders import bge
    from .reranking.reranker import CrossEncoderReranker, choose_threshold
    from .data.corpus import load_passages
    gq, ge, dev, test = freeze.load(p)
    ps = load_passages(p)
    pd_ = {x["passage_id"]: x for x in ps}
    enc = bge(p.study["retrieval"]["query_instruction"])
    ret = Retriever.build(p, enc, ps)
    groups = run_and_label(p, ret, gq, ge)
    rr = CrossEncoderReranker(p.study["reranking"]["model"], p.study["reranking"]["max_length"])
    top = {r["question_id"]: r["candidates"] for r in read_jsonl(p.path("interim", "bge_top30.jsonl"))}
    qd = {q["question_id"]: q for q in gq}
    dev_scored = {}
    for qid in dev:
        sc, _ = rr.score(question_text(qd[qid]), [pd_[c["passage_id"]]["text"] for c in top[qid]])
        dev_scored[qid] = [{**c, "rerank_score": s} for c, s in zip(top[qid], sc)]
    thr = choose_threshold(dev_scored, {q: set(ge[q]["reference_passage_ids"]) for q in dev},
                           p.study["reranking"]["max_passages"], p.study["reranking"]["min_passages"])
    thr.update(model=rr.name, chosen_utc=utc_now())
    write_json(p.path("reports", "rerank_threshold.json"), thr)
    share = pd.Series(groups).value_counts(normalize=True).to_dict()
    write_json(p.path("reports", "retrieval_diagnostics.json"), {"retriever_group_share": share, "n": len(groups)})
    Tracker(p).set(6, "VALIDATED", ["data/manifests/retrieval_index.json", "reports/rerank_threshold.json",
                                    "data/processed/retriever_groups.json"])
    return {"threshold": thr, "retriever_group_share": share}


# ------------------------------------------------------------------ Gate 7
def kg_extract(p: Project, limit: int | None = None) -> dict:
    from .knowledge_graph import extract
    from .data.corpus import load_passages
    path = extract.run(p, llm(p), load_passages(p), limit=limit)
    recs = read_jsonl(path)
    ok = {r["passage_id"] for r in recs if r.get("status") == "ok"}
    spent = cost_of(path)
    n = len(load_passages(p))
    return {"passages_done": len(ok), "of": n, "cost_usd_so_far": spent,
            "projected_total_cost_usd": spent / max(1, len(ok)) * n,
            "triples_so_far": sum(len(r["triples"]) for r in recs if r.get("status") == "ok")}


def kg_verify_and_build(p: Project) -> dict:
    from .knowledge_graph import fidelity, graph
    from .validation import audit
    ps = passages_dict(p)
    inst = []
    for rec in read_jsonl(p.path("interim", "kg_extraction.jsonl")):
        if rec.get("status") == "ok":
            for t in rec["triples"]:
                if t["schema_valid"] and t["quote_found"]:
                    inst.append({**t, "instance_id": f"{rec['passage_id']}#{t['local_id']}", "passage_id": rec["passage_id"]})
    fidelity.run(p, llm(p), inst, ps)
    all_tr, validated, stats = graph.assemble(p, ps)
    verified = [t for t in all_tr if t["fidelity_verdict"] in ("entailed", "not_entailed")]  # went through the verifier
    sheet, _ = audit.make_triple_audit(p, pd.DataFrame(verified), ps)
    Tracker(p).set(7, "BLOCKED", ["reports/kg_statistics.json", sheet], "waiting for blind 200-triple audit")
    return {**stats, "audit_sheet": sheet}


def kg_audit_score(p: Project) -> dict:
    from .validation import audit
    sc = audit.score_triple_audit(p)
    if sc["status"] == "SCORED":
        Tracker(p).set(7, "VALIDATED", "reports/audit/triple_audit_score.json",
                       f"fidelity precision {sc['fidelity_precision']:.3f}")
    return sc


# ------------------------------------------------------------------ pipeline (Gates 8-10)
def pipeline(p: Project):
    from .benchmark import freeze
    from .data.corpus import load_passages
    from .knowledge_graph import graph
    from .llm import TokenCounter, local_gemini_tokenizer, calibrate_local_tokenizer
    from .reranking.reranker import CrossEncoderReranker
    from .retrieval.dense import Retriever
    from .retrieval.encoders import bge
    from .experiments.runner import Pipeline
    import numpy as np
    gq, ge, dev, test = freeze.load(p)
    ps = load_passages(p)
    enc = bge(p.study["retrieval"]["query_instruction"])
    V = np.load(p.path("interim", "bge_passage_embeddings.npy"))
    ret = Retriever(enc, ps, V, p.study["retrieval"]["top_k"])
    rr = CrossEncoderReranker(p.study["reranking"]["model"], p.study["reranking"]["max_length"])
    thr = read_json(p.path("reports", "rerank_threshold.json"))["threshold"]
    kg = graph.load(p, enc)
    client = llm(p)
    calp = p.path("reports", "tokenizer_calibration.json")
    fn, name = local_gemini_tokenizer(client.model_of("generator"))
    if fn is not None:
        if not calp.exists():
            import random
            sample = random.Random(p.seed).sample([x["text"] for x in ps], 200)
            write_json(calp, {**calibrate_local_tokenizer(client, fn, sample), "local_tokenizer": name,
                              "generator": client.model_of("generator")})
        if not read_json(calp)["use_local"]:
            fn = None
    else:
        write_json(calp, {"use_local": False, "reason": name})
    count = TokenCounter(client, p.path("cache", "token_counts.jsonl"), local_fn=fn, method="local" if fn else "api")
    groups = read_json(p.path("processed", "retriever_groups.json"))
    env_id = read_json(p.path("reports", "environment.json"))["config_hash"]
    pipe = Pipeline(p, {x["passage_id"]: x for x in ps}, ret, rr, thr, kg, count, client, ge, groups, env_id)
    write_json(p.path("reports", "kg_query_index.json"), {"triples": len(kg.triples), "build_seconds": kg.build_seconds,
                                                           "peak_graph_memory_mb": kg.peak_memory_mb})
    qd = {q["question_id"]: q for q in gq}
    return pipe, [qd[i] for i in dev], [qd[i] for i in test]


def gate8_smoke(p: Project, pipe, dev_q: list, n: int = 15) -> dict:
    """Development-only smoke test of every configuration; NOT a thesis finding."""
    from .experiments.runner import Condition, default_condition, run, determinism_pilot
    d = default_condition(p)
    conds = [Condition("0"), Condition("A"), Condition("B"), d, Condition("C", "overhead", d.triples, d.hops, d.alloc),
             Condition("D", "matched", d.triples, d.hops, d.alloc), Condition("RANDOM", "matched", d.triples, d.hops, d.alloc),
             Condition("UNFILTERED", "matched", d.triples, d.hops, d.alloc)]
    out = run(pipe, dev_q[:n], conds, "smoke_dev", "development", [1], "dev")
    recs = [r for r in read_jsonl(out)]
    ok = [r for r in recs if r.get("status") == "ok"]
    c = [r for r in ok if r["configuration"] == "C" and r["budget_mode"] == "matched"]
    chk = {"records": len(recs), "ok": len(ok), "errors": [r.get("error") for r in recs if r.get("status") != "ok"][:5],
           "invalid_answers": sum(not r["answer_valid"] for r in ok),
           "C_prefix_ok": all(r["budget_checks"].get("passage_prefix_of_B") for r in c),
           "ranking_invariance_ok": all(r["ranking_invariance_ok"] for r in ok if r["ranking_invariance_ok"] is not None),
           "graph_cap_ok": all(r["budget_checks"].get("graph_cap_ok", True) for r in ok),
           "within_tolerance_share_C": sum(r["budget_checks"]["within_tolerance"] for r in c) / max(1, len(c)),
           "underfill_share_C": sum(r["budget_checks"].get("underfill_due_to_unused_graph_allocation", False) for r in c) / max(1, len(c)),
           "mean_cost_per_generation_usd": sum((r.get("cost_usd") or 0) for r in ok) / max(1, len(ok))}
    chk["determinism"] = determinism_pilot(pipe, dev_q)
    write_json(p.path("reports", "gate8_smoke.json"), chk)
    passed = chk["ok"] == chk["records"] and chk["C_prefix_ok"] and chk["ranking_invariance_ok"] and chk["graph_cap_ok"]
    Tracker(p).set(8, "VALIDATED" if passed else "BLOCKED", "reports/gate8_smoke.json")
    return chk


def dev_ablation(p: Project, pipe, dev_q: list) -> dict:
    from .experiments.runner import Condition, ablation_grid, run
    from .experiments.selection import select_variants
    out = run(pipe, dev_q, [Condition("B")] + ablation_grid(p), "dev_ablation", "development", out_dir="dev")
    fz = select_variants(p, out)
    Tracker(p).set(9, "VALIDATED", ["reports/frozen_parameters.json", "results/development/ablation_development_summary.csv"])
    return fz


def heldout(p: Project, pipe, test_q: list) -> str:
    from .experiments.selection import heldout_conditions
    from .experiments.runner import run
    Tracker(p).require(5)
    Tracker(p).require(7)
    Tracker(p).require(8)
    Tracker(p).require(9)
    out = run(pipe, test_q, heldout_conditions(p), "heldout_main", "test", out_dir="test")
    recs = read_jsonl(out)
    bad = sum(r.get("status") != "ok" for r in recs)
    Tracker(p).set(10, "VALIDATED" if bad == 0 else "IN PROGRESS", "results/heldout/heldout_main.jsonl",
                   f"{len(recs) - bad} ok, {bad} failed (re-run this cell to retry)")
    return out


def evaluate(p: Project, pipe) -> dict:
    from .evaluation import ragas_eval, triple_relevance
    from .retrieval.encoders import e5
    cand = candidates_dict(p)
    gen = str(p.path("test", "heldout_main.jsonl"))
    rv = ragas_eval.run(p, llm(p), e5(), gen, cand, None, "ragas_heldout.jsonl")
    tv = triple_relevance.run(p, llm(p), [gen], cand, pipe.kg.by_id, pipe.passages)
    return {"ragas_cost_usd": cost_of(rv, "evaluation_cost_usd"), "triple_relevance_cost_usd": cost_of(tv)}


def analyse(p: Project) -> dict:
    from .benchmark import freeze
    from .evaluation.triple_relevance import load as load_tr
    from .reporting.figures import make_all
    from .statistics import analysis as A
    gq, ge, dev, test = freeze.load(p)
    gen = [str(p.path("test", "heldout_main.jsonl"))]
    ev = [str(p.path("test", "ragas_heldout.jsonl"))]
    runs = A.per_run_table(gen, ev, ge, set(passages_dict(p, True)), load_tr(p))
    runs.to_csv(p.path("test", "per_run_log.csv"), index=False)
    pq = A.per_question_table(runs)
    pq.to_csv(p.path("test", "per_question_log.csv"), index=False)  # the consolidated log of Sec. 3.7
    tests = A.run_families(p, pq)
    desc = A.descriptive(pq)
    qc = A.quality_cost(desc)
    comp = A.budget_compliance(runs)
    devsum = pd.read_csv(p.path("dev", "ablation_development_summary.csv"))
    kgs = read_json(p.path("reports", "kg_statistics.json"))
    extra = {"budget_compliance.csv": comp,
             "kg_relation_types.csv": pd.DataFrame(list(kgs["relation_type_frequencies"].items()), columns=["predicate", "triples"]),
             "question_flow.csv": pd.read_csv(p.path("reports", "question_flow_table.csv")),
             "corpus_statistics.csv": pd.read_csv(p.root / "results" / "corpus_statistics.csv")}
    make_all(p, desc, tests, qc, pq, devsum, extra, gen + ev)
    conf = tests[tests.family == "1_confirmatory"].iloc[0].to_dict()
    Tracker(p).set(11, "VALIDATED", ["artifacts/tables/statistical_tests.csv", "results/results_manifest.json"])
    return {"confirmatory": conf, "n_test_questions": int(pq.question_id.nunique())}


def package(p: Project) -> str:
    import shutil
    envmod.capture(p)
    base = p.root.parent / "kg_rag_thesis_evidence"
    keep = ["reports", "artifacts", "configs", "results", "literature_review", "src", "tests", "notebooks",
            "README.md", "requirements.txt", "requirements.lock.txt", "pyproject.toml"]
    tmp = p.root.parent / "_pkg"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir()
    for k in keep:
        s = p.root / k
        if s.is_dir():
            shutil.copytree(s, tmp / k)
        elif s.exists():
            shutil.copy2(s, tmp / k)
    zp = shutil.make_archive(str(base), "zip", tmp)  # no raw TeleQnA / TSpec text (licence: IDs + results only)
    shutil.rmtree(tmp)
    Tracker(p).set(12, "VALIDATED", zp)
    return zp
