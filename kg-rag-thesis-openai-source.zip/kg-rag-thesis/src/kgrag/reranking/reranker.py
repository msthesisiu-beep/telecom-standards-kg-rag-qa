"""Stage 8: cross-encoder reranking with BAAI/bge-reranker-base; <=5 passages above a development-fixed threshold."""
from __future__ import annotations

import math
import time

import numpy as np


class CrossEncoderReranker:
    def __init__(self, name: str = "BAAI/bge-reranker-base", max_length: int = 512, device: str | None = None,
                 batch_size: int = 32):
        import torch
        from sentence_transformers import CrossEncoder
        self.name = name
        self.model = CrossEncoder(name, max_length=max_length,
                                  device=device or ("cuda" if torch.cuda.is_available() else "cpu"))
        self.bs = batch_size

    def score(self, query: str, texts: list[str]) -> tuple[list[float], float]:
        t0 = time.perf_counter()
        # sentence-transformers applies Sigmoid by default for single-label cross-encoders -> scores in (0, 1)
        probs = self.model.predict([(query, t) for t in texts], batch_size=self.bs, show_progress_bar=False) if texts else []
        lat = time.perf_counter() - t0
        vals = [float(x) for x in np.ravel(probs)]
        if vals and (min(vals) < 0 or max(vals) > 1):  # older/newer API returned logits
            vals = [1.0 / (1.0 + math.exp(-v)) for v in vals]
        return vals, lat


def select(scored: list[dict], threshold: float, max_k: int = 5, min_k: int = 1) -> list[dict]:
    """Order by reranker score (ties: original retrieval rank); keep items >= threshold, at most max_k, at least min_k."""
    order = sorted(scored, key=lambda r: (-r["rerank_score"], r["rank"]))
    keep = [r for r in order if r["rerank_score"] >= threshold][:max_k]
    if len(keep) < min_k:
        keep = order[:min_k]
    return [{**r, "final_rank": i + 1} for i, r in enumerate(keep)]


def rerank(reranker, query: str, candidates: list[dict], passages: dict, threshold: float,
           max_k: int = 5, min_k: int = 1) -> tuple[list[dict], list[dict], float]:
    scores, lat = reranker.score(query, [passages[c["passage_id"]]["text"] for c in candidates])
    scored = [{**c, "rerank_score": s} for c, s in zip(candidates, scores)]
    return select(scored, threshold, max_k, min_k), scored, lat


def choose_threshold(dev_scored: dict[str, list[dict]], gold: dict[str, set], max_k: int = 5, min_k: int = 1) -> dict:
    """Development-only threshold: maximise mean per-question F1 of selected passages vs gold passages.
    Candidate thresholds = every distinct score observed (plus 0); ties -> lowest threshold (keeps more evidence)."""
    cands = sorted({0.0} | {round(r["rerank_score"], 6) for v in dev_scored.values() for r in v})
    best = None
    for t in cands:
        f1s = []
        for qid, scored in dev_scored.items():
            sel = {r["passage_id"] for r in select(scored, t, max_k, min_k)}
            g = gold[qid]
            tp = len(sel & g)
            p = tp / len(sel) if sel else 0
            rc = tp / len(g) if g else 0
            f1s.append(0 if tp == 0 else 2 * p * rc / (p + rc))
        m = float(np.mean(f1s)) if f1s else 0.0
        if best is None or m > best["mean_f1"] + 1e-12:
            best = {"threshold": t, "mean_f1": m}
    best.update(n_dev_questions=len(dev_scored), n_candidate_thresholds=len(cands),
                rule="max mean per-question F1 (selected vs gold) on development split; ties -> lowest threshold")
    return best
