"""Stage 5b/5c: independent answerability verification (Sec. 3.3b, Tables 3.2-3.3).

Verifier = models.yaml role `verifier` (different from generator, RAGAs evaluator and KG extractor).
Acceptance requires ALL of:
  1. verifier verdict "supports" with cited passage(s) taken from the question's independent pool;
  2. every quotation found verbatim (whitespace/markdown-escape normalised) in its cited passage (script check);
  3. a SEPARATE entailment call confirming the verified quotations entail the keyed option (exact string presence
     does not establish entailment — Master prompt Stage 5);
  4. no ambiguity / general-knowledge flag.
"""
from __future__ import annotations

import re
from concurrent.futures import ThreadPoolExecutor, as_completed

from ..core import Project, append_jsonl, iter_jsonl, sha256_text, utc_now
from ..llm import LLMClient

PROMPT_VERSION = "answerability-v2.0-gemini"
QTYPES = ["factual_lookup", "cross_section_dependency", "procedure_association", "multi_hop_reasoning"]

VERIFY_SCHEMA = {
    "type": "object",
    "properties": {
        "verdict": {"type": "string", "enum": ["supports", "partial", "no_support"]},
        "evidence": {"type": "array", "items": {"type": "object", "properties": {
            "passage_id": {"type": "string"}, "clause_id": {"type": "string"}, "quote": {"type": "string"}},
            "required": ["passage_id", "quote"]}},
        "ambiguous": {"type": "boolean"},
        "general_knowledge": {"type": "boolean"},
        "out_of_corpus": {"type": "boolean"},
        "question_type": {"type": "string", "enum": QTYPES},
        "reason": {"type": "string"},
    },
    "required": ["verdict", "evidence", "ambiguous", "general_knowledge", "out_of_corpus", "question_type", "reason"],
}

ENTAIL_SCHEMA = {"type": "object", "properties": {
    "entailment": {"type": "string", "enum": ["entails", "partial", "not_entailed"]},
    "reason": {"type": "string"}}, "required": ["entailment", "reason"]}

SYSTEM = ("You are an independent verification assistant for a telecommunications-standards benchmark. "
          "You judge ONLY from the 3GPP Release 17 passages supplied. Never use outside knowledge to declare support.")

VERIFY_TEMPLATE = """Decide whether the PASSAGES below (3GPP Release 17 text) contain explicit evidence that the KEYED OPTION is the correct answer to the QUESTION.

QUESTION ({qid}): {question}
OPTIONS:
{options}
KEYED OPTION: option {aid}: {akey}

Rules:
- verdict "supports": the passages explicitly establish the keyed option (and rule out choosing another). List EVERY passage needed (several passages if the answer combines clauses).
- verdict "partial": the passages support only part of the keyed answer, or the key cannot be derived explicitly.
- verdict "no_support": nothing in the passages establishes the keyed option.
- For every evidence item copy a quotation VERBATIM (exact characters, at least 6 words) from that passage, and give its passage_id exactly as shown.
- ambiguous = true if, given the evidence, more than one option is defensible.
- general_knowledge = true ONLY if the question is answerable from widely known general knowledge without any 3GPP text.
- out_of_corpus = true if the question clearly depends on a specification, organisation or release that these 3GPP Release 17 passages do not cover.
- question_type: factual_lookup (single fact/definition), procedure_association (which procedure/step/entity in a procedure), cross_section_dependency (needs two or more clauses of one specification), multi_hop_reasoning (chains facts across clauses or specifications).
- reason: one or two sentences.

PASSAGES:
{passages}"""

ENTAIL_TEMPLATE = """QUESTION: {question}
OPTIONS:
{options}
KEYED OPTION: option {aid}: {akey}

VERIFIED QUOTATIONS (copied verbatim from 3GPP Release 17):
{quotes}

Do these quotations, taken together and without outside knowledge, entail that the keyed option is the correct answer?
"entails" = fully establish it; "partial" = support only part; "not_entailed" = do not establish it."""

_ESC = re.compile(r"\\([\\`*_{}\[\]()#+\-.!|<>~])")


def normalise(s: str) -> str:
    s = _ESC.sub(r"\1", s or "")
    s = s.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    s = s.replace("–", "-").replace("—", "-").replace(" ", " ")
    s = re.sub(r"[*|+]+", " ", s)  # table borders / emphasis are layout, not content
    return re.sub(r"\s+", " ", s).strip()


def quote_in_passage(quote: str, passage_text: str, min_words: int = 6) -> bool:
    q = normalise(quote)
    return len(q.split()) >= min_words and q in normalise(passage_text)


def render_options(opts: dict) -> str:
    return "\n".join(f"option {k}: {v}" for k, v in sorted(opts.items(), key=lambda kv: int(kv[0])))


def render_passages(pids: list[str], passages: dict) -> str:
    out = []
    for pid in pids:
        p = passages[pid]
        out.append(f"<passage id=\"{pid}\" spec=\"{p['specification']}\" clause=\"{p['clause_id']}\" heading=\"{p['heading'][:80]}\">\n{p['text']}\n</passage>")
    return "\n\n".join(out)


def classify(evidence_pids: list[str], passages: dict, verifier_type: str | None) -> tuple[str, str]:
    """Documented hop/type rule (Sec. 3.3): >1 clause or specification -> multi-hop."""
    clauses = {(passages[p]["spec_id"], passages[p]["clause_id"]) for p in evidence_pids}
    specs = {s for s, _ in clauses}
    if len(clauses) > 1:
        qtype = "multi_hop_reasoning" if (len(specs) > 1 or verifier_type == "multi_hop_reasoning") else "cross_section_dependency"
        return "multi-hop", qtype
    qtype = verifier_type if verifier_type in ("factual_lookup", "procedure_association") else "factual_lookup"
    return "single-hop", qtype


def verify_question(llm: LLMClient, q: dict, pool: list[dict], passages: dict, cfg: dict) -> dict:
    """Run windows over the RRF-ordered pool; returns a complete, auditable record (never raises)."""
    rec = {"question_id": q["question_id"], "prompt_version": PROMPT_VERSION, "verifier_model": llm.model_of("verifier"),
           "started_utc": utc_now(), "calls": [], "status": "ok"}
    tag_re = re.compile(cfg["non_3gpp_tag_pattern"], re.I)
    if tag_re.search(q["question"]):
        rec.update(decision="exclude", reason_code="X2", rule="non-3GPP source tag in question text (no LLM call)",
                   verifier_verdict="not_run", quote_check="n/a")
        return rec
    if not pool:
        rec.update(decision="exclude", reason_code="X1", rule="empty independent pool", verifier_verdict="not_run", quote_check="n/a")
        return rec
    pool_ids = [r["passage_id"] for r in pool]
    in_pool = set(pool_ids)
    W, maxw = cfg["window_size"], cfg["max_windows"]
    opts, aid = render_options(q["options"]), q["answer_option_id"]
    akey = q["options"].get(aid, "")
    carry: list[str] = []
    best = None
    for w in range(min(maxw, (len(pool_ids) + W - 1) // W)):
        window = list(dict.fromkeys(carry + pool_ids[w * W:(w + 1) * W]))
        prompt = VERIFY_TEMPLATE.format(qid=q["question_id"], question=q["question"], options=opts, aid=aid,
                                        akey=akey, passages=render_passages(window, passages))
        r = llm.generate_json("verifier", prompt, VERIFY_SCHEMA, SYSTEM)
        rec["calls"].append({"stage": "verify", "window": w, "n_passages": len(window), "ok": r.ok, "error": r.error,
                             "input_tokens": r.input_tokens, "output_tokens": r.output_tokens, "cost_usd": r.cost_usd,
                             "model_version": r.model_version, "latency_s": r.latency_s,
                             "prompt_sha": sha256_text(prompt)[:16], "response": r.data})
        if not r.ok:
            rec.update(status="error", error=r.error)
            return rec
        d = r.data
        checks = []
        for e in d.get("evidence", []) or []:
            pid = e.get("passage_id", "")
            ok = pid in in_pool and pid in passages and quote_in_passage(e.get("quote", ""), passages[pid]["text"])
            checks.append({**e, "in_pool": pid in in_pool, "quote_found": ok})
        d["_checks"] = checks
        if d["verdict"] == "supports":
            best = (w, d)
            break
        if d["verdict"] == "partial":
            best = best or (w, d)
            carry = [c["passage_id"] for c in checks if c["quote_found"]][:5]
    if best is None:
        last = rec["calls"][-1]["response"]
        rec.update(verifier_verdict="no_support", quote_check="n/a", decision="exclude",
                   reason_code="X2" if last.get("out_of_corpus") else "X1",
                   verifier_reason=last.get("reason"))
        return rec
    _, d = best
    good = [c for c in d["_checks"] if c["quote_found"]]
    rec.update(verifier_verdict=d["verdict"], verifier_reason=d.get("reason"),
               quote_check="pass" if good and len(good) == len(d["_checks"]) else "fail",
               evidence=d["_checks"], verifier_question_type=d.get("question_type"),
               flags={k: d.get(k) for k in ("ambiguous", "general_knowledge", "out_of_corpus")})
    if d["verdict"] == "partial":
        rec.update(decision="exclude", reason_code="X3")
        return rec
    if rec["quote_check"] != "pass":
        rec.update(decision="exclude", reason_code="X7", rule="quotation not found verbatim in cited passage")
        return rec
    if d.get("out_of_corpus"):
        rec.update(decision="exclude", reason_code="X2")
        return rec
    if d.get("ambiguous"):
        rec.update(decision="exclude", reason_code="X4")
        return rec
    if d.get("general_knowledge"):
        rec.update(decision="exclude", reason_code="X5")
        return rec
    quotes = "\n".join(f"[{c['passage_id']} | {passages[c['passage_id']]['specification']} clause "
                       f"{passages[c['passage_id']]['clause_id']}] \"{c['quote']}\"" for c in good)
    eprompt = ENTAIL_TEMPLATE.format(question=q["question"], options=opts, aid=aid, akey=akey, quotes=quotes)
    er = llm.generate_json("verifier", eprompt, ENTAIL_SCHEMA, SYSTEM)
    rec["calls"].append({"stage": "entailment", "ok": er.ok, "error": er.error, "input_tokens": er.input_tokens,
                         "output_tokens": er.output_tokens, "cost_usd": er.cost_usd, "model_version": er.model_version,
                         "latency_s": er.latency_s, "response": er.data})
    if not er.ok:
        rec.update(status="error", error=er.error)
        return rec
    rec["entailment"] = er.data["entailment"]
    if er.data["entailment"] != "entails":
        rec.update(decision="exclude", reason_code="X3" if er.data["entailment"] == "partial" else "X7",
                   rule="separate entailment check failed")
        return rec
    gold = list(dict.fromkeys(c["passage_id"] for c in good))
    hop, qtype = classify(gold, passages, d.get("question_type"))
    rec.update(decision="include", reason_code=None, reference_passage_ids=gold,
               reference_clauses=[f"{passages[p]['specification']} {passages[p]['clause_id']}" for p in gold],
               hop_type=hop, question_type=qtype,
               candidate_sources=sorted({s for r in pool if r["passage_id"] in gold for s in r["sources"]}))
    return rec


def run(project: Project, llm: LLMClient, questions: list[dict], pools: dict[str, list[dict]], passages: dict,
        out_name: str = "verifier_results.jsonl", workers: int | None = None, limit: int | None = None) -> str:
    """Resumable: questions with an 'ok' record for this PROMPT_VERSION are skipped; error records are retried."""
    out = project.path("interim", out_name)
    done = {r["question_id"] for r in iter_jsonl(out) if r.get("status") == "ok" and r.get("prompt_version") == PROMPT_VERSION}
    todo = [q for q in questions if q["question_id"] not in done][: limit or None]
    cfg = project.study["benchmark"]["verification"]
    with ThreadPoolExecutor(workers or project.study["experiment"]["workers"]) as ex:
        futs = [ex.submit(verify_question, llm, q, pools.get(q["question_id"], []), passages, cfg) for q in todo]
        for f in as_completed(futs):
            append_jsonl(out, f.result())
    return str(out)


def latest_records(project: Project, name: str = "verifier_results.jsonl") -> dict[str, dict]:
    recs: dict[str, dict] = {}
    for r in iter_jsonl(project.path("interim", name)):
        if r.get("prompt_version") == PROMPT_VERSION and (r.get("status") == "ok" or r["question_id"] not in recs):
            recs[r["question_id"]] = r
    return recs
