"""Stage 5a: retriever-independent candidate pooling (Sec. 3.3a). BM25 + intfloat/e5-base-v2, top-50 each.

BGE models and the experimental reranker are NEVER used here. The pool is the union of both top-50 lists; reciprocal
rank fusion only orders verification windows, it never decides support.
"""
from __future__ import annotations

import re

import numpy as np

from ..core import Project, write_jsonl


def lexical_tokens(s: str) -> list[str]:
    return re.findall(r"[A-Za-z0-9]+(?:[._-][A-Za-z0-9]+)*", s.lower())


def top_k(scores: np.ndarray, k: int) -> np.ndarray:
    k = min(k, len(scores))
    idx = np.argpartition(-scores, k - 1)[:k]
    return idx[np.argsort(-scores[idx], kind="stable")]


def rrf(a: int | None, b: int | None, k: int = 60) -> float:
    return sum(1.0 / (k + r) for r in (a, b) if r is not None)


def assert_not_forbidden(name: str, forbidden=("bge",)) -> None:
    if any(f in name.lower() for f in forbidden):
        raise ValueError(f"{name} is forbidden for independent answerability validation (Sec. 3.3a)")


def pool_for_question(bm25_scores: np.ndarray, dense_scores: np.ndarray, pids: list[str], depth: int = 50) -> list[dict]:
    bm = {int(i): r for r, i in enumerate(top_k(bm25_scores, depth), 1)}
    de = {int(i): r for r, i in enumerate(top_k(dense_scores, depth), 1)}
    rows = [{"passage_id": pids[i], "bm25_rank": bm.get(i), "e5_rank": de.get(i),
             "bm25_score": float(bm25_scores[i]), "e5_score": float(dense_scores[i]),
             "sources": [n for n, d in (("bm25", bm), ("e5", de)) if i in d], "rrf": rrf(bm.get(i), de.get(i))}
            for i in set(bm) | set(de)]
    rows.sort(key=lambda r: (-r["rrf"], r["passage_id"]))
    return rows


def build_pools(project: Project, questions: list[dict], passages: list[dict], dense_encoder) -> list[dict]:
    from rank_bm25 import BM25Okapi
    from ..retrieval.encoders import cached_passage_embeddings
    cfg = project.study["benchmark"]["pooling"]
    assert_not_forbidden(dense_encoder.name, tuple(cfg["forbidden_model_substrings"]))
    pids = [p["passage_id"] for p in passages]
    bm25 = BM25Okapi([lexical_tokens(p["text"]) for p in passages])
    P = cached_passage_embeddings(dense_encoder, passages, project.path("interim", "e5_passage_embeddings.npy"),
                                  project.path("interim", "e5_passage_ids.json"))
    qtexts = [q["question"] + " " + " ".join(q["options"].values()) for q in questions]  # options give the keyed terms
    Q = dense_encoder.encode_queries(qtexts)
    out = []
    for q, qt, qv in zip(questions, qtexts, Q):
        pool = pool_for_question(bm25.get_scores(lexical_tokens(qt)), P @ qv, pids, cfg["depth_per_method"])
        out.append({"question_id": q["question_id"], "pool": pool, "n_pool": len(pool),
                    "dense_model": dense_encoder.name, "lexical_model": "rank_bm25.BM25Okapi"})
    write_jsonl(project.path("interim", "candidate_pools.jsonl"), out)
    return out
