"""Inclusion/exclusion register (Table 3.2), X6 near-duplicates, question-flow table (Table 3.4)."""
from __future__ import annotations

import re

import numpy as np
import pandas as pd

from ..core import Project, write_json

REASONS = {"X1": "No supporting evidence in corpus", "X2": "Out-of-corpus specification or release",
           "X3": "Partial support only", "X4": "Ambiguous question", "X5": "General-knowledge answer",
           "X6": "Duplicate or near-duplicate", "X7": "Failed verification"}


def _qnum(qid: str) -> int:
    m = re.search(r"(\d+)$", qid)
    return int(m.group(1)) if m else 10**9


def char_tfidf(texts: list[str]) -> np.ndarray:
    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        X = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), lowercase=True).fit_transform(texts)
        return X
    except ImportError:  # minimal fallback
        vocab: dict[str, int] = {}
        rows = []
        for t in texts:
            t = f" {t.lower()} "
            grams = [t[i:i + n] for n in (3, 4, 5) for i in range(len(t) - n + 1)]
            rows.append(grams)
            for g in grams:
                vocab.setdefault(g, len(vocab))
        M = np.zeros((len(texts), len(vocab)), dtype="float32")
        for i, gs in enumerate(rows):
            for g in gs:
                M[i, vocab[g]] += 1
        M /= np.linalg.norm(M, axis=1, keepdims=True) + 1e-9
        return M


def near_duplicates(df_inc: pd.DataFrame, threshold: float) -> dict[str, str]:
    """Return {qid: earlier_qid} for included questions duplicating an EARLIER included question (X6 rule):
    char 3-5-gram TF-IDF cosine >= threshold on question text, OR identical gold-passage set and keyed answer text."""
    d = df_inc.assign(_n=df_inc.question_id.map(_qnum)).sort_values("_n").reset_index(drop=True)
    X = char_tfidf(d.question.tolist())
    S = (X @ X.T)
    S = S.toarray() if hasattr(S, "toarray") else np.asarray(S)
    dup: dict[str, str] = {}
    seen_keys: dict[tuple, str] = {}
    for i, r in d.iterrows():
        key = (tuple(sorted(r.reference_passage_ids)), re.sub(r"\s+", " ", str(r.answer_key_text)).strip().lower())
        earlier = [j for j in range(i) if d.question_id[j] not in dup and S[i, j] >= threshold]
        if earlier:
            dup[r.question_id] = d.question_id[earlier[0]]
        elif key in seen_keys:
            dup[r.question_id] = seen_keys[key]
        else:
            seen_keys[key] = r.question_id
    return dup


def build(project: Project, candidates: list[dict], records: dict[str, dict],
          manual: pd.DataFrame | None = None) -> pd.DataFrame:
    rows = []
    for q in candidates:
        r = records.get(q["question_id"])
        if r is None:
            rows.append({"question_id": q["question_id"], "category": q["category"], "decision": "pending",
                         "reason_code": None})
            continue
        rows.append({
            "question_id": q["question_id"], "category": q["category"], "source_tag": q.get("source_tag"),
            "question": q["question"], "answer_option_id": q["answer_option_id"],
            "answer_key_text": q["options"].get(q["answer_option_id"], ""),
            "candidate_sources": ";".join(r.get("candidate_sources", []) or []),
            "verifier_verdict": r.get("verifier_verdict"), "quote_check": r.get("quote_check"),
            "entailment": r.get("entailment"),
            "reference_passage_ids": r.get("reference_passage_ids", []) or [],
            "reference_clauses": r.get("reference_clauses", []) or [],
            "manual_review": "no", "manual_verdict": None,
            "decision": r.get("decision", "pending") if r.get("status") == "ok" else "pending",
            "reason_code": r.get("reason_code"),
            "hop_type": r.get("hop_type"), "question_type": r.get("question_type"),
            "retriever_found": None, "split": None,
            "verifier_model": r.get("verifier_model"), "prompt_version": r.get("prompt_version"),
            "verifier_cost_usd": sum((c.get("cost_usd") or 0) for c in r.get("calls", [])),
        })
    df = pd.DataFrame(rows)
    if manual is not None and len(manual):  # manual-validation corrections (Sec. 3.3c)
        for _, m in manual.iterrows():
            i = df.index[df.question_id == m.question_id]
            if not len(i):
                continue
            i = i[0]
            df.at[i, "manual_review"] = "yes"
            df.at[i, "manual_verdict"] = m.manual_answerable
            if df.at[i, "decision"] == "include" and m.manual_answerable == "N":
                df.at[i, "decision"], df.at[i, "reason_code"] = "exclude", "X7"
            elif df.at[i, "decision"] == "exclude" and m.manual_answerable == "Y" and m.get("manual_passage_ids"):
                df.at[i, "decision"], df.at[i, "reason_code"] = "include", None
                df.at[i, "reference_passage_ids"] = m.manual_passage_ids
                df.at[i, "hop_type"], df.at[i, "question_type"] = m.manual_hop_type, m.manual_question_type
    inc = df[df.decision == "include"]
    if len(inc):
        for qid, first in near_duplicates(inc, project.study["benchmark"]["near_duplicate_cosine"]).items():
            j = df.index[df.question_id == qid][0]
            df.at[j, "decision"], df.at[j, "reason_code"] = "exclude", "X6"
            df.at[j, "duplicate_of"] = first
    return df


def flow_table(df: pd.DataFrame, records: dict[str, dict]) -> pd.DataFrame:
    """Table 3.4 rows computed from the register."""
    pooled = sum(1 for r in records.values() if r.get("verifier_verdict") not in ("not_run", None) or r.get("calls"))
    sup = sum(1 for r in records.values() if r.get("verifier_verdict") == "supports" and r.get("quote_check") == "pass")
    rows = [("TeleQnA Standards specifications and overview", len(df)),
            ("After candidate pooling and non-3GPP-tag screening (verifier run)", pooled),
            ("Verifier verdict 'supports' and quote check passed", sup),
            ("Included after separate entailment check and flags", int(((df.decision == "include") | (df.reason_code == "X6")).sum())),
            ("Final retained set (after X6 and manual corrections)", int((df.decision == "include").sum())),
            ("Pending (not yet verified / API error)", int((df.decision == "pending").sum()))]
    rows += [(f"Excluded {c} — {t}", int((df.reason_code == c).sum())) for c, t in REASONS.items()]
    return pd.DataFrame(rows, columns=["stage", "questions"])


def save(project: Project, df: pd.DataFrame, flow: pd.DataFrame) -> None:
    out = df.drop(columns=["question", "answer_key_text"], errors="ignore")  # IDs + codes only (Sec. 3.8 licensing)
    for c in ("reference_passage_ids", "reference_clauses"):
        if c in out:
            out[c] = out[c].apply(lambda v: ";".join(v) if isinstance(v, list) else v)
    out.to_csv(project.path("reports", "inclusion_exclusion_log.csv"), index=False)
    flow.to_csv(project.path("reports", "question_flow_table.csv"), index=False)
    write_json(project.path("reports", "question_flow_table.json"), flow.to_dict("records"))
