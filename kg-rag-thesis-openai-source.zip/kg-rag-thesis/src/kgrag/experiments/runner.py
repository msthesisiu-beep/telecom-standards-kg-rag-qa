"""Stages 11-15: configurations 0/A/B/C/D + controls, budget modes, invariance checks, resumable logging.

Invariants enforced at run time (and unit-tested):
* C never re-ranks: its passage list is an in-order prefix of B's cached final list (`passage_prefix_of_B`).
* Retrieval/reranking recomputed for C must reproduce B's cached ranking (`ranking_invariance_ok`).
* KG seeds for C come ONLY from B's selected passages; D seeds come from all 30 candidates.
* Matched mode: total evidence tokens checked against T_q +-5%; graph tokens <= g*T_q.
"""
from __future__ import annotations

import math
import random
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass

from ..core import Project, append_jsonl, iter_jsonl, read_json, stable_hash, utc_now, write_json
from ..generation import generator
from ..knowledge_graph.graph import GRAPH_HEADER, render_statement
from ..reranking.reranker import rerank as do_rerank
from ..retrieval.dense import question_text
from .context import Context, Item, check_matched, graph_items, passage_items, render_passage, trim_to


@dataclass(frozen=True)
class Condition:
    config: str                    # 0 | A | B | C | D | RANDOM | UNFILTERED
    mode: str = "matched"          # matched | overhead (C/controls only)
    triples: int | None = None
    hops: int | None = None
    alloc: float | None = None

    @property
    def name(self) -> str:
        if self.config in ("0", "B"):
            return self.config
        if self.config == "A":
            return "A_matched"
        return f"{self.config}_t{self.triples}_h{self.hops}_g{int(round(self.alloc * 100))}_{self.mode}"

    @property
    def uses_graph(self) -> bool:
        return self.config in ("C", "D", "RANDOM", "UNFILTERED")


def default_condition(project: Project, config: str = "C", mode: str = "matched") -> Condition:
    d = project.study["experiment"]["default_variant"]
    return Condition(config, mode, d["triples"], d["hops"], d["alloc"])


def ablation_grid(project: Project) -> list[Condition]:
    e = project.study["experiment"]
    return [Condition("C", "matched", t, h, a) for t in e["triple_budgets"] for h in e["hop_depths"]
            for a in e["graph_allocations"]]


class Pipeline:
    def __init__(self, project: Project, passages: dict, retriever, reranker, threshold: float, kg, count, llm,
                 gold: dict | None = None, groups: dict | None = None, env_id: str = ""):
        self.p, self.passages, self.retriever, self.reranker = project, passages, retriever, reranker
        self.threshold, self.kg, self.count, self.llm = threshold, kg, count, llm
        self.gold, self.groups, self.env_id = gold or {}, groups or {}, env_id
        rr = project.study["reranking"]
        self.max_k, self.min_k = rr["max_passages"], rr["min_passages"]
        self.tol = project.study["experiment"]["budget_tolerance"]
        self.refill = project.study["experiment"]["refill_unused_graph_allocation"]
        self.header_tokens = count(GRAPH_HEADER) if count else 0
        self.b_cache_path = project.path("interim", "b_rankings.jsonl")
        self._b_cache = {r["question_id"]: r for r in iter_jsonl(self.b_cache_path)}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ shared retrieval state (recomputed each call)
    def b_state(self, q: dict) -> dict:
        qt = question_text(q)
        cands, rl = self.retriever.retrieve(qt)
        sel, scored, kl = do_rerank(self.reranker, qt, cands, self.passages, self.threshold, self.max_k, self.min_k)
        st = {"candidates": cands, "scored": scored, "selected": sel, "retrieval_latency_s": rl, "rerank_latency_s": kl,
              "qvec": None}
        ids = [s["passage_id"] for s in sel]
        with self._lock:
            cached = self._b_cache.get(q["question_id"])
            if cached is None:
                cached = {"question_id": q["question_id"], "final_passage_ids": ids,
                          "rerank_scores": [s["rerank_score"] for s in sel],
                          "retrieved_passage_ids": [c["passage_id"] for c in cands], "threshold": self.threshold,
                          "utc": utc_now()}
                self._b_cache[q["question_id"]] = cached
                append_jsonl(self.b_cache_path, cached)
        st["b_cached_ids"] = cached["final_passage_ids"]
        st["ranking_invariance_ok"] = ids == cached["final_passage_ids"]
        return st

    def prefetch_counts(self, questions: list[dict]) -> None:
        """API-count mode only: count rendered A/B passages in parallel once (labels depend on rank)."""
        if not hasattr(self.count, "prefetch") or getattr(self.count, "local_fn", None) is not None:
            return
        texts = []
        for q in questions:
            st = self.b_state(q)
            texts += [render_passage(self.passages[c["passage_id"]], f"P{k + 1}") for k, c in enumerate(st["candidates"])]
            texts += [render_passage(self.passages[i], f"P{k + 1}") for k, i in enumerate(st["b_cached_ids"])]
        self.count.prefetch(texts)

    def qvec(self, q: dict):
        return self.retriever.encoder.encode_queries([question_text(q)])[0]

    # ------------------------------------------------------------------ context builders
    def _b_items(self, st: dict) -> list[Item]:
        ids = st["b_cached_ids"]  # B ranking reused verbatim (cached identifiers)
        sc = {s["passage_id"]: s["rerank_score"] for s in st["scored"]}
        return passage_items(ids, self.passages, self.count, None, [sc.get(i) for i in ids])

    def build(self, q: dict, cond: Condition, st: dict | None) -> tuple[Context, dict]:
        lat = {"kg_lookup_s": 0.0, "extra_rerank_s": 0.0}
        if cond.config == "0":
            return Context([], meta={"closed_book": True}), lat
        b_items = self._b_items(st)
        T = sum(i.tokens for i in b_items)
        b_ids = [i.ref for i in b_items]
        if cond.config == "B":
            ctx = Context(b_items, T_q=T)
            ctx.checks = {"T_q": T, "evidence_tokens": T, "within_tolerance": True}
            return ctx, lat
        if cond.config == "A":
            ids = [c["passage_id"] for c in st["candidates"]]
            ctx = Context(passage_items(ids, self.passages, self.count, T, [c["score"] for c in st["candidates"]]), T_q=T)
            ctx.checks = check_matched(ctx, self.tol)
            return ctx, lat
        cap = int(math.floor(cond.alloc * T))
        qv = self.qvec(q)
        if cond.config == "D":
            return self._build_d(q, cond, st, T, cap, qv, lat)
        seed_text = "\n".join(self.passages[i]["text"] for i in b_ids)  # seeds ONLY from B's final passages
        gcap = max(0, cap - self.header_tokens)
        kw = dict(qvec=qv, seed_text=seed_text, hops=cond.hops, count=self.count)
        c_sel = self.kg.select(**kw, triple_budget=cond.triples, token_cap=gcap, mode="selective")
        if cond.config == "C":
            sel = c_sel
        elif cond.config == "UNFILTERED":
            sel = self.kg.select(**kw, triple_budget=None, token_cap=gcap, mode="unfiltered")
        else:  # RANDOM: same count as C's realised triples, same allocation, random over the whole validated KG
            sel = self.kg.select(**kw, triple_budget=None, token_cap=gcap, mode="random",
                                 rng_seed=int(stable_hash([q["question_id"], cond.name], 8), 16),
                                 n_random=len(c_sel["items"]))
        lat["kg_lookup_s"] = sel["lookup_latency_s"] + (c_sel["lookup_latency_s"] if sel is not c_sel else 0)
        g_items = graph_items(sel, self.header_tokens, GRAPH_HEADER)
        g_tok = sum(i.tokens for i in g_items)
        if cond.mode == "overhead":
            ctx = Context(b_items + g_items, T_q=T, graph_cap=cap)
            ctx.checks = {"T_q": T, "evidence_tokens": ctx.evidence_tokens, "graph_tokens": g_tok,
                          "graph_cap_ok": g_tok <= cap, "added_tokens": g_tok, "passage_prefix_of_B": True}
        else:
            p_budget = T - (g_tok if self.refill else cap)
            p_items = passage_items(b_ids, self.passages, self.count, p_budget)
            ctx = Context(p_items + g_items, T_q=T, graph_cap=cap)
            ctx.checks = check_matched(ctx, self.tol, b_ids)
            ctx.checks["underfill_due_to_unused_graph_allocation"] = (not ctx.checks["within_tolerance"]
                                                                      and g_tok < cap and not self.refill)
        ctx.meta = {"requested_triples": cond.triples, "realised_triples": len(sel["items"]), "n_seeds": sel["n_seeds"],
                    "n_candidate_triples": sel["n_candidates"], "stop_reason": sel["stop_reason"],
                    "triple_hops": [g["hop"] for g in sel["items"]], "c_reference_triples": len(c_sel["items"])}
        return ctx, lat

    def _build_d(self, q, cond, st, T, cap, qv, lat):
        seed_text = "\n".join(self.passages[c["passage_id"]]["text"] for c in st["candidates"])  # all 30 candidates
        sel = self.kg.select(qvec=qv, seed_text=seed_text, hops=cond.hops, count=self.count,
                             triple_budget=cond.triples, token_cap=None, mode="selective")
        lat["kg_lookup_s"] = sel["lookup_latency_s"]
        trip = {g["triple_id"]: self.kg.by_id[g["triple_id"]] for g in sel["items"]}
        g_texts = [render_statement(t, "G") for t in trip.values()]
        g_scores, kl = self.reranker.score(question_text(q), g_texts) if g_texts else ([], 0.0)
        lat["extra_rerank_s"] = kl  # passages already scored in st["scored"]; graph statements scored jointly here
        pool = [("P", s["passage_id"], s["rerank_score"], s["rank"]) for s in st["scored"]] + \
               [("G", tid, sc, 10**6 + k) for k, (tid, sc) in enumerate(zip(trip, g_scores))]
        pool.sort(key=lambda x: (-x[2], x[3]))
        items, used, gused, np_, ng = [], 0, 0, 0, 0
        for kind, ref, sc, _ in pool:
            if used >= T:
                break
            if kind == "G":
                txt = render_statement(trip[ref], f"G{ng + 1}")
                n = self.count(txt)
                if gused + n <= cap and used + n <= T:
                    ng += 1
                    items.append(Item(f"G{ng}", "G", ref, txt, n, source_passage_ids=[p["passage_id"] for p in trip[ref]["provenance"]], score=sc))
                    used += n
                    gused += n
                continue
            lab = f"P{np_ + 1}"
            txt = render_passage(self.passages[ref], lab)
            n = self.count(txt)
            if used + n <= T:
                np_ += 1
                items.append(Item(lab, "P", ref, txt, n, source_passage_ids=[ref], score=sc))
                used += n
            else:
                it = trim_to(self.passages[ref], lab, T - used, self.count)
                if it is not None:
                    np_ += 1
                    it.score = sc
                    items.append(it)
                    used += it.tokens
                break
        ctx = Context(items, T_q=T, graph_cap=cap)
        ctx.checks = check_matched(ctx, self.tol)
        b_ids = st["b_cached_ids"]
        ctx.checks["passages_differ_from_B"] = [i.ref for i in ctx.passage_items] != b_ids
        ctx.meta = {"requested_triples": cond.triples, "realised_triples": ng, "n_seeds": sel["n_seeds"],
                    "n_candidate_triples": sel["n_candidates"], "graph_pool_size": len(trip), "stop_reason": "joint_budget_fill",
                    "triple_hops": [sel_i["hop"] for sel_i in sel["items"] if sel_i["triple_id"] in {i.ref for i in items}]}
        return ctx, lat

    # ------------------------------------------------------------------ one record
    def prepare(self, q: dict, cond: Condition) -> tuple:
        """Local stages (retrieval, reranking, KG lookup, context) — run sequentially on the main thread so that
        stage latencies are not distorted by concurrent GPU work."""
        t_start = time.perf_counter()
        st = None if cond.config == "0" else self.b_state(q)
        ctx, lat = self.build(q, cond, st)
        return st, ctx, lat, time.perf_counter() - t_start

    def run_one(self, q: dict, cond: Condition, run_id: int, seed: int, exp_id: str, split: str,
                prepared: tuple | None = None) -> dict:
        st, ctx, lat, local_s = prepared or self.prepare(q, cond)
        gen = generator.generate(self.llm, q, ctx.text(), seed)
        ref = q["answer_option_id"]
        labels = {l: {"kind": i.kind, "ref": i.ref, "source_passage_ids": i.source_passage_ids} for l, i in ctx.labels().items()}
        rl = st["retrieval_latency_s"] if st else 0.0
        kl = (st["rerank_latency_s"] if st else 0.0) + lat["extra_rerank_s"]
        if cond.config == "A":
            kl = 0.0  # A does not rerank; its latency excludes the (shared) reranking computation
        total = rl + kl + lat["kg_lookup_s"] + (gen["generation_latency_s"] or 0)
        rec = {
            "key": f"{exp_id}|{cond.name}|{q['question_id']}|{run_id}", "experiment_id": exp_id, "run_id": run_id,
            "seed": seed, "question_id": q["question_id"], "split": split, "configuration": cond.config,
            "condition": cond.name, "budget_mode": cond.mode if cond.uses_graph or cond.config == "A" else "n/a",
            "triple_budget": cond.triples, "hop_depth": cond.hops, "graph_alloc": cond.alloc,
            "hop_type": q.get("hop_type"), "question_type": q.get("question_type"),
            "retriever_group": self.groups.get(q["question_id"]),
            "retrieved_passage_ids": [c["passage_id"] for c in st["candidates"]] if st else [],
            "b_passage_ids": st["b_cached_ids"] if st else [],
            "ranking_list_ids": ([c["passage_id"] for c in st["candidates"]] if cond.config == "A" else
                                 (st["b_cached_ids"] if st else [])),
            "final_passage_ids": [i.ref for i in ctx.passage_items], "final_passage_trimmed": [i.trimmed for i in ctx.passage_items],
            "kg_triple_ids": [i.ref for i in ctx.graph_items], "context_labels": labels,
            "graph_tokens": ctx.graph_tokens, "evidence_tokens": ctx.evidence_tokens, "T_q": ctx.T_q,
            "graph_cap": ctx.graph_cap, "budget_checks": ctx.checks, "kg_meta": ctx.meta,
            "ranking_invariance_ok": st["ranking_invariance_ok"] if st else None,
            "context_text": ctx.text(), "context_text_passages_only": ctx.text(passages_only=True),
            "context_items": [i.text for i in ctx.items if i.kind in ("P", "G")],
            "parsed_option": gen["parsed_option"], "reference_option": ref,
            "correct": int(gen["parsed_option"] == ref), "answer_valid": gen["answer_valid"],
            "justification": gen["justification"], "citations": gen["citations"],
            "retrieval_latency_s": rl, "rerank_latency_s": kl, "kg_lookup_latency_s": lat["kg_lookup_s"],
            "generation_latency_s": gen["generation_latency_s"], "total_latency_s": total,
            "local_pipeline_wall_s": local_s,
            "input_tokens": gen["input_tokens"], "output_tokens": gen["output_tokens"], "thought_tokens": gen["thought_tokens"],
            "cost_usd": gen["generation_cost_usd"], "generator_model": gen["generator_model"],
            "generator_model_version": gen["generator_model_version"], "prompt_sha": gen["prompt_sha"],
            "template_hash": gen["template_hash"], "embedding_model": getattr(self.retriever.encoder, "name", None) if st else None,
            "reranker_model": getattr(self.reranker, "name", None) if st else None, "rerank_threshold": self.threshold,
            "config_hash": self.p.config_hash(), "env_id": self.env_id,
            "cache_policy": self.p.study["experiment"]["latency_cache_policy"],
            "status": "ok" if gen["generation_error"] is None else "generation_error",
            "error": gen["generation_error"], "utc": utc_now()}
        return rec


def run(pipe: Pipeline, questions: list[dict], conditions: list[Condition], exp_id: str, split: str,
        run_ids: list[int] | None = None, out_dir: str = "dev", workers: int | None = None) -> str:
    """Resumable: a (experiment, condition, question, run) key with status ok is never recomputed."""
    project = pipe.p
    out = project.path(out_dir, f"{exp_id}.jsonl")
    done = {r["key"] for r in iter_jsonl(out) if r.get("status") == "ok"}
    e = project.study["experiment"]
    run_ids = run_ids or list(range(1, int(_run_policy(project)["n_runs"]) + 1))
    order = sorted(questions, key=lambda q: q["question_id"])
    random.Random(e["question_order_seed"]).shuffle(order)  # one fixed permutation for all conditions
    sem = threading.Semaphore((workers or e["workers"]) * 2)

    def fail(q, c, rid, ex):  # recorded, never replaced by an invented answer
        append_jsonl(out, {"key": f"{exp_id}|{c.name}|{q['question_id']}|{rid}", "experiment_id": exp_id,
                           "condition": c.name, "question_id": q["question_id"], "run_id": rid, "status": "exception",
                           "error": f"{type(ex).__name__}: {ex}", "utc": utc_now()})

    def job(q, c, rid, seed, prepared):
        try:
            append_jsonl(out, pipe.run_one(q, c, rid, seed, exp_id, split, prepared))
        except Exception as ex:
            fail(q, c, rid, ex)
        finally:
            sem.release()

    with ThreadPoolExecutor(workers or e["workers"]) as ex:
        for rid in run_ids:
            seed = e["run_seeds"][rid - 1]
            for c in conditions:
                for q in order:
                    if f"{exp_id}|{c.name}|{q['question_id']}|{rid}" in done:
                        continue
                    try:
                        prepared = pipe.prepare(q, c)  # local stages: main thread, sequential
                    except Exception as err:
                        fail(q, c, rid, err)
                        continue
                    sem.acquire()
                    ex.submit(job, q, c, rid, seed, prepared)  # hosted generation: parallel
    return str(out)


def _run_policy(project: Project) -> dict:
    p = project.path("reports", "run_policy.json")
    return read_json(p) if p.exists() else {"n_runs": project.study["experiment"]["n_runs"], "source": "study.yaml default"}


def determinism_pilot(pipe: Pipeline, dev_questions: list[dict], n: int = 30) -> dict:
    """Sec. 3.7: run B twice on the same development questions with the same seed; any disagreement -> 3 runs."""
    qs = sorted(dev_questions, key=lambda q: q["question_id"])[:n]
    for r in (1, 2):
        run(pipe, qs, [Condition("B")], f"pilot_determinism_r{r}", "development", [1], "dev")
    from ..core import read_jsonl
    a = {x["question_id"]: x.get("parsed_option") for x in read_jsonl(pipe.p.path("dev", "pilot_determinism_r1.jsonl")) if x.get("status") == "ok"}
    b = {x["question_id"]: x.get("parsed_option") for x in read_jsonl(pipe.p.path("dev", "pilot_determinism_r2.jsonl")) if x.get("status") == "ok"}
    common = sorted(set(a) & set(b))
    diff = [k for k in common if a[k] != b[k]]
    res = {"n_compared": len(common), "n_different": len(diff), "different_ids": diff,
           "n_runs": 3 if diff else 1, "decided_utc": utc_now(), "source": "determinism pilot (development only)"}
    write_json(pipe.p.path("reports", "run_policy.json"), res)
    return res
