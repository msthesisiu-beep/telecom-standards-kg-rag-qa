"""Stage 13: development-only variant selection and parameter freezing (Sec. 3.5, Table 4.5)."""
from __future__ import annotations

import pandas as pd

from ..core import Project, read_jsonl, utc_now, write_json, read_json
from .runner import Condition, default_condition


def select_variants(project: Project, dev_log: str) -> dict:
    lock = project.path("reports", "frozen_parameters.json")
    if lock.exists():
        raise RuntimeError("Parameters already frozen; development selection must not be repeated after test evaluation.")
    df = pd.DataFrame([r for r in read_jsonl(dev_log) if r.get("status") == "ok" and r["configuration"] == "C"])
    if df.empty:
        raise RuntimeError("No successful development ablation records")
    per_q = df.groupby(["condition", "question_id"]).agg(correct=("correct", "mean"), graph_tokens=("graph_tokens", "mean"),
                                                          t=("triple_budget", "first"), h=("hop_depth", "first"),
                                                          a=("graph_alloc", "first")).reset_index()
    per_q["correct"] = (per_q.correct >= 0.5).astype(int)  # majority over runs if 3 runs
    agg = per_q.groupby("condition").agg(accuracy=("correct", "mean"), n=("question_id", "nunique"),
                                         mean_graph_tokens=("graph_tokens", "mean"), triples=("t", "first"),
                                         hops=("h", "first"), alloc=("a", "first")).reset_index()
    if agg.n.nunique() != 1:
        raise RuntimeError(f"Unequal question coverage across variants: {agg.n.unique().tolist()} — finish the ablation first")
    if len(agg) != 18:
        raise RuntimeError(f"Expected 18 variants, found {len(agg)}")
    agg = agg.sort_values(["accuracy", "mean_graph_tokens", "alloc", "triples", "hops"],
                          ascending=[False, True, True, True, True]).reset_index(drop=True)
    agg["selection_rank"] = range(1, len(agg) + 1)
    n_top = project.study["experiment"]["n_top_variants"]
    top = agg.head(n_top)
    d = default_condition(project)
    chosen = [{"triples": int(r.triples), "hops": int(r.hops), "alloc": float(r.alloc), "reason": f"top-{r.selection_rank}"}
              for r in top.itertuples()]
    if d.name not in set(top.condition):
        chosen.append({"triples": d.triples, "hops": d.hops, "alloc": d.alloc, "reason": "predefined default"})
    else:
        for c in chosen:
            if (c["triples"], c["hops"], c["alloc"]) == (d.triples, d.hops, d.alloc):
                c["reason"] += " + predefined default"
    agg.to_csv(project.path("dev", "ablation_development_summary.csv"), index=False)
    thr = read_json(project.path("reports", "rerank_threshold.json"))
    pol = read_json(project.path("reports", "run_policy.json")) if project.path("reports", "run_policy.json").exists() else {}
    frozen = {"frozen_utc": utc_now(), "rule": project.study["experiment"]["variant_selection_rule"],
              "selected_variants": chosen, "rerank_threshold": thr["threshold"], "n_runs": pol.get("n_runs", 1),
              "config_hash": project.config_hash(), "development_log": str(dev_log)}
    write_json(lock, frozen)
    return frozen


def heldout_conditions(project: Project) -> list[Condition]:
    fz = read_json(project.path("reports", "frozen_parameters.json"))
    v = [Condition("C", "matched", c["triples"], c["hops"], c["alloc"]) for c in fz["selected_variants"]]
    d = default_condition(project)
    conds = [Condition("0"), Condition("A"), Condition("B")] + v
    conds += [Condition("C", "overhead", c.triples, c.hops, c.alloc) for c in v]
    conds += [Condition("D", "matched", d.triples, d.hops, d.alloc),
              Condition("RANDOM", "matched", d.triples, d.hops, d.alloc),
              Condition("UNFILTERED", "matched", d.triples, d.hops, d.alloc)]
    return list(dict.fromkeys(conds))
