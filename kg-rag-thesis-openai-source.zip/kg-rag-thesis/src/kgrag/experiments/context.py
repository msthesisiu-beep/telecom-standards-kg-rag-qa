"""Evidence-context construction for configurations 0/A/B/C/D and controls, under the two budget modes (Sec. 3.5).

Evidence tokens = sum of generator-tokenizer counts of the rendered evidence items (passages [P#], graph statements
[G#] and the graph header). Instructions, question and options are excluded (identical across configurations).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

SENT = re.compile(r"(?<=[.!?;:])\s+(?=[A-Z0-9(\[])|\n+")


def render_passage(p: dict, label: str, text: str | None = None) -> str:
    return f"[{label}] {p['specification']} clause {p['clause_id']} - {p['heading'][:90]}\n{text if text is not None else p['text']}"


@dataclass
class Item:
    label: str
    kind: str                 # "P" passage | "G" graph statement | "H" graph header
    ref: str                  # passage_id / triple_id / ""
    text: str
    tokens: int
    trimmed: bool = False
    source_passage_ids: list = field(default_factory=list)
    score: float | None = None


@dataclass
class Context:
    items: list[Item]
    T_q: int | None = None
    graph_cap: int | None = None
    checks: dict = field(default_factory=dict)
    meta: dict = field(default_factory=dict)

    @property
    def passage_items(self):
        return [i for i in self.items if i.kind == "P"]

    @property
    def graph_items(self):
        return [i for i in self.items if i.kind == "G"]

    @property
    def evidence_tokens(self) -> int:
        return sum(i.tokens for i in self.items)

    @property
    def graph_tokens(self) -> int:
        return sum(i.tokens for i in self.items if i.kind in ("G", "H"))

    def text(self, passages_only: bool = False) -> str:
        its = [i for i in self.items if (i.kind == "P" or not passages_only)]
        return "\n\n".join(i.text for i in its)

    def labels(self) -> dict[str, Item]:
        return {i.label: i for i in self.items if i.kind in ("P", "G")}


def trim_to(p: dict, label: str, budget: int, count) -> Item | None:
    """Longest sentence-boundary prefix whose rendered item fits `budget` tokens (None if not even one sentence)."""
    sents = [s for s in SENT.split(p["text"]) if s.strip()]
    lo, hi, best = 1, len(sents), None
    while lo <= hi:  # binary search over prefix length (token count is monotone in prefix length)
        mid = (lo + hi) // 2
        txt = render_passage(p, label, " ".join(sents[:mid]))
        n = count(txt)
        if n <= budget:
            best, lo = Item(label, "P", p["passage_id"], txt, n, trimmed=mid < len(sents),
                            source_passage_ids=[p["passage_id"]]), mid + 1
        else:
            hi = mid - 1
    return best


def passage_items(pids: list[str], passages: dict, count, budget: int | None = None,
                  scores: list[float] | None = None) -> list[Item]:
    """Passages in the given order; if `budget` is set, whole passages while they fit, then the next one trimmed at a
    sentence boundary, then stop (lower-ranked passages omitted). Never reorders."""
    out, used = [], 0
    for k, pid in enumerate(pids):
        lab = f"P{k + 1}"
        txt = render_passage(passages[pid], lab)
        n = count(txt)
        sc = scores[k] if scores else None
        if budget is None or used + n <= budget:
            out.append(Item(lab, "P", pid, txt, n, source_passage_ids=[pid], score=sc))
            used += n
            continue
        it = trim_to(passages[pid], lab, budget - used, count)
        if it is not None:
            it.score = sc
            out.append(it)
        break
    return out


def graph_items(sel: dict, header_tokens: int, header_text: str) -> list[Item]:
    if not sel["items"]:
        return []
    its = [Item("", "H", "", header_text, header_tokens)]
    for k, g in enumerate(sel["items"]):
        its.append(Item(f"G{k + 1}", "G", g["triple_id"], g["text"], g["tokens"], source_passage_ids=g["source_passage_ids"]))
    return its


def check_matched(ctx: Context, tol: float, b_ids: list[str] | None = None) -> dict:
    T = ctx.T_q or 0
    tot = ctx.evidence_tokens
    chk = {"T_q": T, "evidence_tokens": tot, "ratio_to_T_q": (tot / T) if T else None,
           "within_tolerance": (abs(tot - T) <= tol * T) if T else tot == 0,
           "not_over_budget": tot <= (1 + tol) * T}
    if ctx.graph_cap is not None:
        chk["graph_tokens"] = ctx.graph_tokens
        chk["graph_cap_ok"] = ctx.graph_tokens <= ctx.graph_cap
    if b_ids is not None:
        c_ids = [i.ref for i in ctx.passage_items]
        chk["passage_prefix_of_B"] = c_ids == b_ids[: len(c_ids)]
    return chk
