"""Environment capture (Sec. 4.3, Tables 4.1-4.2). Values are DETECTED; unavailable ones are marked."""
from __future__ import annotations

import importlib
import os
import platform
import subprocess
import sys

from .core import Project, utc_now, write_json

PACKAGES = ["numpy", "pandas", "scipy", "statsmodels", "networkx", "faiss", "torch", "transformers",
            "sentence_transformers", "rank_bm25", "tiktoken", "google.genai", "openai", "huggingface_hub",
            "matplotlib", "yaml"]


def _version(mod: str) -> str:
    try:
        m = importlib.import_module(mod)
        return str(getattr(m, "__version__", "installed (no __version__)"))
    except Exception:
        return "NOT INSTALLED"


def _cpu_model() -> str:
    try:
        for line in open("/proc/cpuinfo", encoding="utf-8"):
            if line.startswith("model name"):
                return line.split(":", 1)[1].strip()
    except OSError:
        pass
    return platform.processor() or "UNAVAILABLE"


def _ram_gb() -> str:
    try:
        for line in open("/proc/meminfo", encoding="utf-8"):
            if line.startswith("MemTotal"):
                return f"{int(line.split()[1]) / 1024 / 1024:.1f} GB"
    except OSError:
        pass
    return "UNAVAILABLE"


def _gpu() -> tuple[str, str]:
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader"],
                             capture_output=True, text=True, timeout=20).stdout.strip()
        if out:
            name, mem = [x.strip() for x in out.splitlines()[0].split(",")]
            return name, mem
    except Exception:
        pass
    return "NONE DETECTED", "n/a"


def capture(project: Project) -> dict:
    gpu, vram = _gpu()
    env = {
        "captured_utc": utc_now(),
        "execution_platform": "Google Colab" if "COLAB_RELEASE_TAG" in os.environ or os.path.exists("/content") else platform.node(),
        "processor": _cpu_model(), "cpu_count": os.cpu_count(), "system_ram": _ram_gb(),
        "gpu": gpu, "gpu_memory": vram, "operating_system": platform.platform(),
        "python_version": sys.version.split()[0],
        "model_execution": "Hosted (configured provider API) for LLM roles; local GPU/CPU for BGE, reranker, E5",
        "packages": {p: _version(p) for p in PACKAGES},
        "config_hash": project.config_hash(),
    }
    write_json(project.path("reports", "environment.json"), env)
    try:
        frz = subprocess.run([sys.executable, "-m", "pip", "freeze"], capture_output=True, text=True, timeout=120).stdout
        (project.root / "requirements.lock.txt").write_text(frz, encoding="utf-8")
    except Exception:
        pass
    return env


def hardware_table_md(env: dict) -> str:
    rows = [("Execution platform", env["execution_platform"]), ("Processor", env["processor"]),
            ("System RAM", env["system_ram"]), ("GPU", env["gpu"]), ("GPU memory", env["gpu_memory"]),
            ("Operating system", env["operating_system"]), ("Python version", env["python_version"]),
            ("Model execution method", env["model_execution"])]
    return "| Hardware parameter | Specification |\n|---|---|\n" + "\n".join(f"| {a} | {b} |" for a, b in rows)
