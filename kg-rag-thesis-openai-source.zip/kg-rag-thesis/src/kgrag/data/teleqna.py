"""TeleQnA acquisition and parsing (Sec. 3.3, Table 3.1). Ported from notebook cells 03-04."""
from __future__ import annotations

import io
import json
import re
import zipfile
from pathlib import Path

from ..core import Project, sha256_file, utc_now, write_json, write_jsonl

TAG = re.compile(r"\[([^\]]+)\]\s*$")


def download(project: Project) -> Path:
    import requests
    import pyzipper
    cfg = project.study["benchmark"]
    raw = project.path("raw_q")
    zpath, jpath = raw / "TeleQnA.zip", raw / "TeleQnA.json"
    if not jpath.exists():
        with requests.get(cfg["teleqna_url"], stream=True, timeout=(25, 180),
                          headers={"User-Agent": "Academic-Research"}) as r:
            r.raise_for_status()
            with zpath.open("wb") as f:
                for part in r.iter_content(1 << 20):
                    f.write(part)
        pwd = cfg["teleqna_password"].encode()
        with pyzipper.AESZipFile(zpath) as a:
            names = [n for n in a.namelist() if n.lower().endswith((".json", ".txt")) and not n.startswith("__MACOSX")]
            pref = next((x for x in names if "teleqna" in x.lower()), names[0])
            try:
                payload = a.read(pref, pwd=pwd)
            except Exception:
                payload = zipfile.ZipFile(zpath).read(pref, pwd=pwd)
        jpath.write_text(json.dumps(json.loads(payload.decode("utf-8-sig")), ensure_ascii=False), encoding="utf-8")
    write_json(project.path("manifests", "teleqna_manifest.json"), {
        "source_url": cfg["teleqna_url"], "repository": "https://github.com/netop-team/TeleQnA",
        "licence": "MIT", "access": "password-protected archive (password in README)",
        "downloaded_utc": utc_now(), "zip_sha256": sha256_file(zpath) if zpath.exists() else None,
        "json_sha256": sha256_file(jpath)})
    return jpath


def parse(records: dict | list) -> list[dict]:
    it = records.items() if isinstance(records, dict) else [(f"index_{i}", v) for i, v in enumerate(records)]
    rows = []
    for key, item in it:
        if not isinstance(item, dict):
            continue
        d = {str(k).strip().lower(): v for k, v in item.items()}
        options = {m.group(1): str(v) for k, v in d.items() if (m := re.fullmatch(r"option\s*(\d+)", k))}
        ans = str(d.get("answer", ""))
        m = re.match(r"^\s*option\s*(\d+)\s*(?::|$)", ans, re.I)
        aid = m.group(1) if m else None
        q = str(d.get("question", ""))
        tag = TAG.search(q)
        rows.append({"question_id": str(key), "question": q, "options": options, "answer_text": ans,
                     "answer_option_id": aid, "explanation": str(d.get("explanation", "")),
                     "category": str(d.get("category", "")).strip(), "source_tag": tag.group(1) if tag else None,
                     "answer_parsed": bool(aid and aid in options)})
    return rows


def load_candidates(project: Project, jpath: Path | None = None) -> list[dict]:
    jpath = jpath or project.path("raw_q", "TeleQnA.json")
    rows = parse(json.loads(Path(jpath).read_text(encoding="utf-8-sig")))
    cats = {c.casefold() for c in project.study["benchmark"]["categories"]}
    cand = [r for r in rows if r["category"].casefold() in cats]
    write_jsonl(project.path("interim", "teleqna_candidates.jsonl"), cand)
    write_json(project.path("manifests", "teleqna_counts.json"), {
        "total_questions": len(rows),
        "by_category": {c: sum(r["category"] == c for r in rows) for c in sorted({r["category"] for r in rows})},
        "candidates": len(cand), "unparsed_answers_in_candidates": sum(not r["answer_parsed"] for r in cand)})
    return cand
