"""Clause-aware chunking of TSpec-LLM Markdown (Sec. 3.3, 4.4.2-4.4.3). Port of notebook CELL 12 (chunker v2.4).

Rules derived from the REAL file structure observed in the Colab diagnostics:
* Real headings are Markdown lines '### 4.2.1 General' (3-6 '#'), numeric clause id required.
* Levels 1-2 may be plain text; accepted only if strictly increasing vs. the previous heading (monotonic),
  capitalised, short, with no trailing page number.
* Contents-page lines end in a page number ('1 Scope 24') and are never headings.
* Cross-references ('38.214 \\[19\\]') are body text; hashed ids that look like a spec number are rejected.
* ASN.1 names ('#### -- *BWP*') are kept in the text but do not start a new clause id.
* Everything before the first '1 Scope' heading (cover, foreword, contents) is dropped and counted.
* Tables and code blocks are split only at row/line boundaries (header repeated); flagged when oversize.
* Sections with a tiny body are merged forward into the next section of the same top-level clause.
Token counting is injected (tiktoken in Colab, whitespace in tests).
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from typing import Callable

Counter_ = Callable[[str], int]

HASH_HEAD = re.compile(r"^#{3,6}\s+((?:[A-Z]|\d{1,2})(?:\.\d{1,3}[a-z]?){0,6})\s+(\S.*?)\s*$")
ANNEX_HEAD = re.compile(r"^(?:#{1,8}\s+(Annex\s+[A-Z])\b(.*)|(Annex\s+[A-Z])\s*(\((?:normative|informative)\).*))$")
ASN1_HEAD = re.compile(r"^#{1,8}\s+--")
PLAIN_HEAD = re.compile(r"^ ?(\d{1,2}(?:\.\d{1,3}[a-z]?){0,2})\s+([A-Z][^|+\\]{1,100}?)\s*$")
TRAILING_PAGE = re.compile(r"\s\d{1,4}\s*$")
VERSION = re.compile(r"V(\d+\.\d+\.\d+)(?:\s*\((\d{4}-\d{2})\))?")
TABLE_LINE = re.compile(r"^\s*[|+]")
NORMATIVE = re.compile(r"\b(shall not|shall|should|may)\b", re.I)
SCOPE_HEAD = re.compile(r"^[#\s]*1\s+Scope\s*$")


def _tuple(cid: str) -> tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", cid))


def is_spec_ref(cid: str) -> bool:
    parts = cid.split(".")
    return (len(parts) == 2 and parts[0].isdigit() and parts[1][:3].isdigit() and len(parts[1]) == 3
            and int(parts[0]) >= 21)


def parse_version(lines: list[str]) -> tuple[str, str]:
    for line in lines[:600]:
        m = VERSION.search(line) if "3GPP TS" in line else None
        if m:
            return m.group(1), (m.group(2) or "not stated on cover")
    return "unknown", "unknown"


@dataclass
class Section:
    clause_id: str
    heading: str
    lines: list[str] = field(default_factory=list)
    start_line: int = 0
    clause_ids: list[str] = field(default_factory=list)


def split_sections(lines: list[str]) -> tuple[list[Section], dict]:
    sections: list[Section] = []
    stats = {"dropped_front_matter_lines": 0, "plain_headings_accepted": 0, "plain_headings_rejected_nonmonotonic": 0,
             "spec_ref_headings_rejected": 0, "asn1_subsections": 0, "toc_like_lines_skipped": 0,
             "normative_terms_in_dropped_front": 0, "scope_anchor_found": False}
    last: tuple[int, ...] = ()
    cur: Section | None = None
    parent = ""
    body_start = next((i for i, l in enumerate(lines) if SCOPE_HEAD.match(l)), None)
    stats["scope_anchor_found"] = body_start is not None
    for n, raw in enumerate(lines):
        line = raw.rstrip("\n")
        if body_start is not None and n < body_start:
            stats["dropped_front_matter_lines"] += 1
            stats["normative_terms_in_dropped_front"] += len(NORMATIVE.findall(line))
            continue
        m = HASH_HEAD.match(line)
        a = ANNEX_HEAD.match(line)
        if a and TRAILING_PAGE.search(line):  # contents-page annex entry
            a = None
            stats["toc_like_lines_skipped"] += 1
        cid = head = None
        if m:
            if is_spec_ref(m.group(1)):
                stats["spec_ref_headings_rejected"] += 1
            else:
                cid, head = m.group(1), m.group(2)
                last = _tuple(cid) or last
        elif a:
            cid = a.group(1) or a.group(3)
            head = (a.group(2) or a.group(4) or "").strip(" :-")
            last = (999,)  # annexes follow the main body
        elif ASN1_HEAD.match(line) and cur is not None:
            cid, head = parent, line.lstrip("# ").strip()
            stats["asn1_subsections"] += 1
        else:
            p = PLAIN_HEAD.match(line)
            if (p and not TRAILING_PAGE.search(line) and not line.rstrip().endswith((";", ",", ":"))
                    and not TABLE_LINE.match(line)):
                t = _tuple(p.group(1))
                if t and t > last and t[0] <= (last[0] if last else 0) + 1 and last != (999,):
                    cid, head = p.group(1), p.group(2)
                    last = t
                    stats["plain_headings_accepted"] += 1
                elif t:
                    stats["plain_headings_rejected_nonmonotonic"] += 1
            elif p and TRAILING_PAGE.search(line):
                stats["toc_like_lines_skipped"] += 1
        if cid:
            if not ASN1_HEAD.match(line):
                parent = cid
            cur = Section(cid, head, [line], n, [cid])
            sections.append(cur)
        elif cur is None:
            stats["dropped_front_matter_lines"] += 1
            stats["normative_terms_in_dropped_front"] += len(NORMATIVE.findall(line))
        else:
            cur.lines.append(line)
    return sections, stats


def _blocks(lines: list[str]) -> list[tuple[str, bool]]:
    """Split on blank lines; a block is (text, splittable). Tables / indented code are not splittable."""
    out, buf = [], []
    for l in lines + [""]:
        if l.strip():
            buf.append(l)
        elif buf:
            txt = "\n".join(buf)
            out.append((txt, not any(TABLE_LINE.match(x) or x.startswith("    ") for x in buf)))
            buf = []
    return out


def split_prose(text: str, cap: int, count: Counter_) -> list[str]:
    parts, cur = [], ""
    for s in re.split(r"(?<=[.!?])\s+(?=[A-Z0-9(])", text):
        cand = (cur + " " + s).strip()
        if cur and count(cand) > cap:
            parts.append(cur)
            cur = s
        else:
            cur = cand
    if cur:
        parts.append(cur)
    return parts


def split_unsplittable(text: str, cap: int, count: Counter_) -> list[tuple[str, list[str]]]:
    lines = text.split("\n")
    is_table = sum(1 for l in lines if TABLE_LINE.match(l)) >= max(3, len(lines) // 2)
    header: list[str] = []
    units: list[list[str]] = []
    if is_table:
        buf: list[str] = []
        for l in lines:
            buf.append(l)
            if l.lstrip().startswith("+"):
                units.append(buf)
                buf = []
        if buf:
            units.append(buf)
        for k, u in enumerate(units):
            if any(x.lstrip().startswith("+=") for x in u):
                header = [x for uu in units[: k + 1] for x in uu]
                units = units[k + 1:]
                break
        else:
            header, units = (units[0], units[1:]) if units else ([], [])
        if count("\n".join(header)) > cap // 2:
            units, header = ([header] if header else []) + units, []
    else:
        units = [[l] for l in lines]
    base_flag = "table_split" if is_table else "code_split"
    parts: list[tuple[str, list[str]]] = []
    cur: list[str] = []

    def emit():
        nonlocal cur
        if cur:
            body = "\n".join(header + cur)
            fl = [base_flag]
            if count(body) > cap:
                fl.append("oversize_unsplittable")
            parts.append((body, fl))
            cur = []

    for u in units:
        if cur and count("\n".join(header + cur + u)) > cap:
            emit()
        cur = cur + u
    emit()
    if len(parts) == 1 and "oversize_unsplittable" not in parts[0][1]:
        parts[0] = (parts[0][0], [])
    return parts or [(text, ["oversize_unsplittable"])]


def pack_section(sec: Section, cap: int, count: Counter_) -> list[tuple[str, list[str]]]:
    chunks: list[tuple[str, list[str]]] = []
    cur, flags = "", []

    def flush():
        nonlocal cur, flags
        if cur.strip():
            chunks.append((cur.strip(), flags))
        cur, flags = "", []

    for text, splittable in _blocks(sec.lines):
        n = count(text)
        pieces = [text]
        if n > cap and splittable:
            pieces = split_prose(text, cap, count)
        elif n > cap:
            flush()
            chunks.extend(split_unsplittable(text, cap, count))
            continue
        for piece in pieces:
            cand = (cur + "\n\n" + piece) if cur else piece
            if cur and count(cand) > cap:
                flush()
                cur = piece
            else:
                cur = cand
    flush()
    return chunks


def make_passages(lines: list[str], spec: str, release: str, source_file: str, count: Counter_,
                  cap: int = 500, min_body: int = 60) -> tuple[list[dict], dict]:
    version, vdate = parse_version(lines)
    sections, stats = split_sections(lines)
    merged: list[Section] = []
    carry: Section | None = None
    top = lambda c: c.split(".")[0]
    for i, s in enumerate(sections):
        if carry is not None:
            s = Section(s.clause_id, s.heading, carry.lines + s.lines, carry.start_line, carry.clause_ids + s.clause_ids)
            carry = None
        nxt = sections[i + 1] if i + 1 < len(sections) else None
        if nxt is not None and count("\n".join(s.lines)) < min_body and top(nxt.clause_id) == top(s.clause_id):
            carry = s
            continue
        merged.append(s)
    if carry is not None:
        merged.append(carry)
    passages: list[dict] = []
    for s in merged:
        for k, (text, flags) in enumerate(pack_section(s, cap, count)):
            key = f"{spec}|{version}|{s.clause_id}|{s.start_line}|{k}"
            pid = f"TS{spec}-{s.clause_id}-{hashlib.sha1(key.encode()).hexdigest()[:8]}"
            if "change history" in s.heading.lower():
                flags = flags + ["change_history"]
            passages.append({"passage_id": pid, "specification": f"TS {spec[:2]}.{spec[2:]}", "spec_id": spec,
                             "release": release, "version": version, "version_date": vdate,
                             "clause_id": s.clause_id, "clause_ids": list(dict.fromkeys(s.clause_ids)),
                             "heading": s.heading, "part": k, "text": text, "token_count": count(text),
                             "chunk_flags": flags, "source_file": source_file, "source_start_line": s.start_line + 1})
    stats.update({"sections": len(sections), "passages": len(passages), "version": version, "version_date": vdate})
    return passages, stats


def quality_checks(passages: list[dict], source_text: str | None = None) -> dict:
    ids = [p["passage_id"] for p in passages]
    toks = sorted(p["token_count"] for p in passages)
    q = lambda f: toks[int(f * (len(toks) - 1))] if toks else 0
    rep = {"n_passages": len(passages), "duplicate_ids": len(ids) - len(set(ids)),
           "empty_passages": sum(1 for p in passages if not p["text"].strip()),
           "missing_clause_id": sum(1 for p in passages if not p["clause_id"]),
           "spec_number_like_clause_ids": sum(1 for p in passages if is_spec_ref(p["clause_id"])),
           "lt_100_tokens": sum(1 for t in toks if t < 100), "in_300_500": sum(1 for t in toks if 300 <= t <= 500),
           "gt_500_tokens": sum(1 for t in toks if t > 500),
           "oversize_unsplittable": sum(1 for p in passages if "oversize_unsplittable" in p["chunk_flags"]),
           "token_p05": q(0.05), "token_p50": q(0.5), "token_p95": q(0.95),
           "normative_terms_in_passages": len(NORMATIVE.findall(" ".join(p["text"] for p in passages)))}
    if source_text is not None:
        rep["normative_terms_in_source"] = len(NORMATIVE.findall(source_text))
    return rep
