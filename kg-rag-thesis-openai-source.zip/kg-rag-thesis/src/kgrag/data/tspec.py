"""TSpec-LLM Release-17 acquisition, corpus manifest and official-3GPP-archive version check (Sec. 3.3, 4.4.1)."""
from __future__ import annotations

import re
from pathlib import Path

from ..core import Project, sha256_file, utc_now, write_json

VERSION_CHARS = "0123456789abcdefghijklmnopqrstuvwxyz"  # 3GPP: a=10, b=11 ... (TS 21.900)


def version_from_filename(name: str) -> str | None:
    """'23501-ha0.md' -> '17.10.0' (3GPP file-naming convention: major/technical/editorial digits)."""
    m = re.match(r"^\d{5}-([0-9a-z])([0-9a-z])([0-9a-z])", name.lower())
    if not m:
        return None
    return ".".join(str(VERSION_CHARS.index(c)) for c in m.groups())


def download(project: Project, specs: dict[str, str] | None = None, token: str | None = None) -> dict:
    from huggingface_hub import HfApi, hf_hub_download
    c = project.study["corpus"]
    specs = specs or c["specs"]
    api, out = HfApi(), {}
    for series in sorted(set(specs.values())):
        folder = f"{c['hf_folder']}/{series}"
        paths = [o.path for o in api.list_repo_tree(c["hf_repo"], path_in_repo=folder, repo_type="dataset",
                                                     recursive=False, token=token)
                 if getattr(o, "path", "").lower().endswith(".md")]
        for spec, s in specs.items():
            if s != series:
                continue
            choices = sorted(p for p in paths if re.match(fr"^{spec}-[^/]+\.md$", Path(p).name, re.I))
            if not choices:
                out[spec] = {"status": "MISSING_IN_DATASET"}
                continue
            pick = choices[-1]  # latest Rel-17 version in TSpec-LLM; verified against archive below
            hf_hub_download(c["hf_repo"], pick, repo_type="dataset", token=token, local_dir=str(project.path("raw_md")))
            out[spec] = {"status": "DOWNLOADED", "hf_path": pick, "alternatives": choices}
    return out


def verify_against_archive(spec: str, version: str, timeout: int = 30) -> dict:
    """Check that <spec>-<code>.zip exists in https://www.3gpp.org/ftp/Specs/archive/<series>/<xx.yyy>/."""
    import requests
    series = f"{spec[:2]}_series"
    dotted = f"{spec[:2]}.{spec[2:]}"
    url = f"https://www.3gpp.org/ftp/Specs/archive/{series}/{dotted}/"
    code = "".join(VERSION_CHARS[int(x)] for x in version.split("."))
    try:
        r = requests.get(url, timeout=timeout, headers={"User-Agent": "Academic-Research"})
        r.raise_for_status()
        listed = sorted(set(re.findall(fr"{spec}-([0-9a-z]{{3}})\.zip", r.text)))
        rel17 = [x for x in listed if x[0] == "h"]
        return {"archive_url": url, "file_expected": f"{spec}-{code}.zip", "present_in_archive": code in listed,
                "release17_versions_in_archive": rel17, "latest_release17_in_archive": rel17[-1] if rel17 else None,
                "checked_utc": utc_now()}
    except Exception as e:
        return {"archive_url": url, "present_in_archive": None, "error": f"{type(e).__name__}: {e}",
                "checked_utc": utc_now()}


def build_manifest(project: Project, specs: dict[str, str] | None = None, check_archive: bool = True) -> dict:
    c = project.study["corpus"]
    specs = specs or c["specs"]
    files = list(project.path("raw_md").rglob("*.md"))
    entries = []
    for spec, series in specs.items():
        matches = [p for p in files if re.match(fr"^{spec}-", p.name)]
        if len(matches) != 1:
            entries.append({"spec_id": spec, "specification": f"TS {spec[:2]}.{spec[2:]}",
                            "status": "MISSING" if not matches else "AMBIGUOUS", "files": [str(m) for m in matches]})
            continue
        p = matches[0]
        ver = version_from_filename(p.name)
        cover = None
        for line in p.read_text(encoding="utf-8", errors="replace").splitlines()[:600]:
            m = re.search(r"3GPP TS \d+\.\d+ V(\d+\.\d+\.\d+)", line)
            if m:
                cover = m.group(1)
                break
        e = {"spec_id": spec, "specification": f"TS {spec[:2]}.{spec[2:]}", "release": c["release"],
             "version_from_filename": ver, "version_on_cover": cover,
             "filename_cover_consistent": (ver == cover) if cover else None,
             "release_consistent": bool(ver and ver.split(".")[0] == c["release"]),
             "local_path": str(p.relative_to(project.root)), "file_bytes": p.stat().st_size, "sha256": sha256_file(p),
             "source_url": f"https://huggingface.co/datasets/{c['hf_repo']}/blob/main/{c['hf_folder']}/{series}/{p.name}",
             "licence": "CC-BY-NC-4.0 (TSpec-LLM); 3GPP terms of use", "access": "Hugging Face account + accepted dataset conditions",
             "registered_utc": utc_now()}
        if check_archive and ver:
            e["official_archive"] = verify_against_archive(spec, ver)
        e["status"] = ("VERIFIED" if e.get("official_archive", {}).get("present_in_archive") and e["release_consistent"]
                       else "PROVISIONAL")
        entries.append(e)
    man = {"created_utc": utc_now(), "release": c["release"], "documents": entries,
           "mixed_releases": len({e.get("version_from_filename", "x").split(".")[0] for e in entries if e.get("version_from_filename")}) > 1}
    write_json(project.path("manifests", "corpus_manifest.json"), man)
    write_json(project.root / "configs" / "corpus_manifest.json", man)
    return man
