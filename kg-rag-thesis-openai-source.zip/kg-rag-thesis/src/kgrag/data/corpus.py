"""Build passages.jsonl + corpus statistics + quality report from the manifest (Stage 4 outputs)."""
from __future__ import annotations

import re
from pathlib import Path

import pandas as pd

from ..core import Project, read_json, read_jsonl, sha256_file, utc_now, write_jsonl, atomic_write_text
from .chunker import make_passages, quality_checks, split_sections

XREF = re.compile(r"(?:clause|subclause|section)\s+(\d+(?:\.\d+){0,6})", re.I)


def tiktoken_counter(name: str = "cl100k_base"):
    import tiktoken
    enc = tiktoken.get_encoding(name)
    return lambda s: len(enc.encode(s, disallowed_special=()))


def build(project: Project, count=None) -> pd.DataFrame:
    count = count or tiktoken_counter(project.study["corpus"]["chunking"]["tokenizer_preliminary"])
    ch = project.study["corpus"]["chunking"]
    man = read_json(project.path("manifests", "corpus_manifest.json"))
    all_p, stats = [], []
    for d in man["documents"]:
        if not d.get("local_path"):
            continue
        p = project.root / d["local_path"]
        raw = p.read_text(encoding="utf-8", errors="replace")
        lines = raw.splitlines()
        passages, st = make_passages(lines, d["spec_id"], project.study["corpus"]["release"], p.name, count,
                                     cap=ch["cap_tokens"], min_body=ch["min_section_body_tokens"])
        q = quality_checks(passages, raw)
        clause_set = {c for x in passages for c in x["clause_ids"]}
        xrefs = [m.group(1) for x in passages for m in XREF.finditer(x["text"])]
        broken = sorted({r for r in xrefs if r not in clause_set and not any(c.startswith(r + ".") for c in clause_set)})
        ver_ok = st["version"] == d.get("version_on_cover") == d.get("version_from_filename")
        stats.append({"specification": d["specification"], "file": p.name, "sha256": sha256_file(p),
                      "version": st["version"], "version_date": st["version_date"], "version_consistent": ver_ok,
                      **{k: v for k, v in st.items() if k not in ("version", "version_date")}, **q,
                      "normative_lost": q["normative_terms_in_source"] - st["normative_terms_in_dropped_front"]
                      - q["normative_terms_in_passages"],
                      "internal_xrefs": len(xrefs), "unresolved_internal_xrefs": len(broken),
                      "unresolved_xref_examples": ";".join(broken[:10])})
        all_p += passages
    write_jsonl(project.path("interim", "passages.jsonl"), all_p)
    df = pd.DataFrame(stats)
    df.to_csv(project.root / "results" / "corpus_statistics.csv", index=False)
    _report(project, df, all_p)
    return df


def _report(project: Project, df: pd.DataFrame, passages: list[dict]) -> None:
    pdf = pd.DataFrame(passages)
    flags = pdf["chunk_flags"].astype(str).value_counts().to_dict()
    n_ret = int((~pdf["chunk_flags"].apply(lambda f: "change_history" in f)).sum())
    md = [f"# Corpus quality report\n\nGenerated {utc_now()} from `data/interim/passages.jsonl` (computed, not estimated).\n",
          f"* Total passages: **{len(pdf)}**; retrieval corpus (change-history annexes excluded): **{n_ret}**",
          f"* Duplicate passage IDs: **{int(pdf.passage_id.duplicated().sum())}**",
          f"* Empty passages: **{int((pdf.text.str.strip() == '').sum())}**",
          f"* Share 300-500 tokens (cl100k, preliminary): **{pdf.token_count.between(300, 500).mean():.3f}**; "
          f"share < 100: **{(pdf.token_count < 100).mean():.3f}**; > 500: **{(pdf.token_count > 500).mean():.3f}** "
          "(tables/code never split mid-row; see flags)",
          f"* Chunk flags: `{flags}`\n",
          "## Per specification\n", df.drop(columns=["unresolved_xref_examples"], errors="ignore").to_markdown(index=False),
          "\n\n`normative_lost` = source terms - terms in dropped front matter - terms in passages; values <= 0 mean no loss "
          "(negative values come from repeated table headers).\n",
          "Unresolved internal cross-references usually point to clauses of other specifications cited inline; they are "
          "reported, not repaired."]
    atomic_write_text(project.path("reports", "corpus_quality_report.md"), "\n".join(md))


def load_passages(project: Project, retrieval_only: bool = True) -> list[dict]:
    ps = read_jsonl(project.path("interim", "passages.jsonl"))
    if retrieval_only:
        ex = set(project.study["corpus"]["chunking"]["exclude_flags_from_retrieval"])
        ps = [p for p in ps if not ex.intersection(p["chunk_flags"])]
    return ps
