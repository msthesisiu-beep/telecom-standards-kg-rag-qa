"""Stage 7: experimental semantic retrieval — BAAI/bge-base-en-v1.5 + FAISS, top-30 (Sec. 3.4 Comp. 2, 4.7.1)."""
from __future__ import annotations

import time

import numpy as np

from ..core import Project, write_jsonl, write_json
from .encoders import IPIndex, cached_passage_embeddings


class Retriever:
    def __init__(self, encoder, passages: list[dict], vectors: np.ndarray, top_k: int = 30):
        self.encoder, self.passages, self.top_k = encoder, passages, top_k
        self.pids = [p["passage_id"] for p in passages]
        self.index = IPIndex(vectors)

    @classmethod
    def build(cls, project: Project, encoder, passages: list[dict]) -> "Retriever":
        V = cached_passage_embeddings(encoder, passages, project.path("interim", "bge_passage_embeddings.npy"),
                                      project.path("interim", "bge_passage_ids.json"))
        r = cls(encoder, passages, V, project.study["retrieval"]["top_k"])
        r.index.save(project.path("interim", "bge_index.npy"))
        write_json(project.path("manifests", "retrieval_index.json"), {
            "embedding_model": encoder.name, "n_passages": len(passages), "dim": int(V.shape[1]),
            "index_backend": r.index.backend, "top_k": r.top_k, "normalised": True})
        return r

    def retrieve(self, question: str) -> tuple[list[dict], float]:
        """Fresh (uncached) query encoding + search; returns ranked candidates and latency in seconds."""
        t0 = time.perf_counter()
        qv = self.encoder.encode_queries([question])
        scores, idx = self.index.search(qv, self.top_k)
        lat = time.perf_counter() - t0
        out = []
        for rank, (s, i) in enumerate(zip(scores[0], idx[0]), 1):
            p = self.passages[int(i)]
            out.append({"passage_id": p["passage_id"], "score": float(s), "rank": rank,
                        "specification": p["specification"], "clause_id": p["clause_id"]})
        return out, lat


def question_text(q: dict) -> str:
    """Query = question + options (identical for all retrieval configurations)."""
    return q["question"] + "\n" + "\n".join(f"option {k}: {v}" for k, v in sorted(q["options"].items()))


def run_and_label(project: Project, retriever: Retriever, questions: list[dict], gold: dict[str, dict]) -> dict:
    """Retrieve top-30 for every frozen question; record retriever-found vs independent-only (Sec. 3.3d)."""
    rows, groups = [], {}
    for q in questions:
        cands, lat = retriever.retrieve(question_text(q))
        ref = set(gold[q["question_id"]]["reference_passage_ids"])
        found = any(c["passage_id"] in ref for c in cands)
        groups[q["question_id"]] = "retriever-found" if found else "independent-only"
        rows.append({"question_id": q["question_id"], "candidates": cands, "retrieval_latency_s": lat,
                     "gold_in_top30": found})
    write_jsonl(project.path("interim", "bge_top30.jsonl"), rows)
    write_json(project.path("processed", "retriever_groups.json"), groups)  # diagnostic label; never filters questions
    return groups
