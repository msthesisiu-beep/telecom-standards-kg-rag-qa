"""Dense encoders and a FAISS (or exact NumPy fallback) inner-product index."""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Protocol

import numpy as np


class Encoder(Protocol):
    name: str

    def encode_queries(self, texts: list[str]) -> np.ndarray: ...

    def encode_passages(self, texts: list[str]) -> np.ndarray: ...


class STEncoder:
    """sentence-transformers encoder with model-specific prefixes (E5: 'query: '/'passage: '; BGE: query instruction)."""

    def __init__(self, name: str, query_prefix: str = "", passage_prefix: str = "", device: str | None = None,
                 batch_size: int = 64, max_seq_length: int = 512):
        import torch
        from sentence_transformers import SentenceTransformer
        self.name = name
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model = SentenceTransformer(name, device=self.device)
        self.model.max_seq_length = max_seq_length
        self.qp, self.pp, self.bs = query_prefix, passage_prefix, batch_size
        self.revision = getattr(getattr(self.model, "model_card_data", None), "base_model_revision", None)

    def encode_queries(self, texts):
        return np.asarray(self.model.encode([self.qp + t for t in texts], batch_size=self.bs,
                                            normalize_embeddings=True, show_progress_bar=False), dtype="float32")

    def encode_passages(self, texts, show_progress=True):
        return np.asarray(self.model.encode([self.pp + t for t in texts], batch_size=self.bs,
                                            normalize_embeddings=True, show_progress_bar=show_progress), dtype="float32")


def e5(device=None) -> STEncoder:
    return STEncoder("intfloat/e5-base-v2", "query: ", "passage: ", device)


def bge(instruction: str, device=None) -> STEncoder:
    return STEncoder("BAAI/bge-base-en-v1.5", instruction, "", device)


class IPIndex:
    """Exact inner-product search. Uses faiss.IndexFlatIP when available, NumPy otherwise (identical results)."""

    def __init__(self, vectors: np.ndarray):
        self.vectors = np.ascontiguousarray(vectors, dtype="float32")
        try:
            import faiss
            self.index = faiss.IndexFlatIP(self.vectors.shape[1])
            self.index.add(self.vectors)
            self.backend = f"faiss.IndexFlatIP (faiss {faiss.__version__})"
        except ImportError:
            self.index, self.backend = None, "numpy exact inner product"

    def search(self, q: np.ndarray, k: int) -> tuple[np.ndarray, np.ndarray]:
        q = np.ascontiguousarray(np.atleast_2d(q), dtype="float32")
        k = min(k, len(self.vectors))
        if self.index is not None:
            return self.index.search(q, k)
        s = q @ self.vectors.T
        idx = np.argsort(-s, axis=1, kind="stable")[:, :k]
        return np.take_along_axis(s, idx, 1), idx

    def save(self, path: str | Path) -> None:
        np.save(Path(path), self.vectors)
        if self.index is not None:
            import faiss
            faiss.write_index(self.index, str(Path(path).with_suffix(".faiss")))


def cached_passage_embeddings(encoder: Encoder, passages: list[dict], cache_npy: Path, ids_json: Path) -> np.ndarray:
    pids = [p["passage_id"] for p in passages]
    if cache_npy.exists() and ids_json.exists() and json.loads(ids_json.read_text()) == pids:
        return np.load(cache_npy)
    t0 = time.time()
    emb = encoder.encode_passages([p["text"] for p in passages])
    np.save(cache_npy, emb)
    ids_json.write_text(json.dumps(pids))
    (cache_npy.with_suffix(".timing.json")).write_text(json.dumps({"encode_seconds": time.time() - t0,
                                                                     "n": len(pids), "model": encoder.name}))
    return emb
