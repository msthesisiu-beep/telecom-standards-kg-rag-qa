"""Fast, explicitly exploratory end-to-end run for local validation.

This profile uses sampled questions and passages, skips human-audit gates, and
writes only below data/interim/smoke50_openai. Its results are not thesis
evidence and must not be mixed with the frozen benchmark or held-out results.
"""
from __future__ import annotations

import copy
import random
from pathlib import Path

import pandas as pd

from .core import Project, read_jsonl, write_json, write_jsonl


def _sample_questions(rows: list[dict], n: int, seed: int) -> list[dict]:
    release17 = [q for q in rows if q.get("source_tag") == "3GPP Release 17" and q.get("answer_parsed")]
    rng = random.Random(seed)
    chosen = []
    categories = sorted({q["category"] for q in release17})
    base, remainder = divmod(n, max(1, len(categories)))
    for i, category in enumerate(categories):
        group = [q for q in release17 if q["category"] == category]
        rng.shuffle(group)
        chosen.extend(group[:base + (i < remainder)])
    if len(chosen) < n:
        selected = {q["question_id"] for q in chosen}
        rest = [q for q in release17 if q["question_id"] not in selected]
        rng.shuffle(rest)
        chosen.extend(rest[:n - len(chosen)])
    if len(chosen) < n:
        raise ValueError(f"Only {len(chosen)} parsed Release 17 questions are available; need {n}.")
    return sorted(chosen[:n], key=lambda q: q["question_id"])


def _sample_passages(rows: list[dict], n: int, seed: int) -> list[dict]:
    rng = random.Random(seed)
    groups: dict[str, list[dict]] = {}
    for passage in rows:
        groups.setdefault(str(passage["spec_id"]), []).append(passage)
    if len(rows) <= n:
        return rows
    names = sorted(groups)
    base, remainder = divmod(n, len(names))
    sample = []
    for i, name in enumerate(names):
        group = groups[name]
        rng.shuffle(group)
        sample.extend(group[:base + (i < remainder)])
    if len(sample) < n:
        selected = {p["passage_id"] for p in sample}
        rest = [p for p in rows if p["passage_id"] not in selected]
        rng.shuffle(rest)
        sample.extend(rest[:n - len(sample)])
    return sorted(sample, key=lambda p: p["passage_id"])


def run(project: Project, n_questions: int = 50, n_passages: int = 600,
        n_kg_passages: int = 40, n_eval_questions: int = 5) -> dict:
    """Run sampled pooling, verification, KG construction, retrieval and answer generation."""
    import tiktoken

    from . import workflow
    from .data import corpus, teleqna
    from .evaluation import ragas_eval, triple_relevance
    from .knowledge_graph import extract, fidelity, graph
    from .llm import TokenCounter
    from .reranking.reranker import CrossEncoderReranker
    from .retrieval.dense import Retriever
    from .retrieval.encoders import bge, e5
    from .validation.pooling import build_pools
    from .validation.verifier import latest_records, run as verify_run
    from .experiments.runner import Condition, Pipeline, run as experiment_run

    if not project.path("raw_md").exists() or not list(project.path("raw_md").rglob("*.md")):
        raise FileNotFoundError("Release 17 TSpec Markdown is missing; run Stage 4.2 with an accepted HF_TOKEN.")
    teleqna_path = project.path("raw_q", "TeleQnA.json")
    if not teleqna_path.exists():
        teleqna.download(project)
    candidates = teleqna.parse(__import__("json").loads(teleqna_path.read_text(encoding="utf-8-sig")))
    questions = _sample_questions(candidates, n_questions, project.seed)

    # Rebuild from the complete local source files, then sample passages by specification.
    quality = corpus.build(project)
    if quality.duplicate_ids.sum() or quality.empty_passages.sum() or (quality.normative_lost > 0).any():
        raise RuntimeError("Corpus quality checks failed; see reports/corpus_quality_report.md.")
    all_passages = corpus.load_passages(project, retrieval_only=True)
    passages = _sample_passages(all_passages, n_passages, project.seed)

    smoke_root = project.root / "data" / "interim" / "smoke50_openai"
    smoke = Project(smoke_root, copy.deepcopy(project.study), copy.deepcopy(project.models),
                    copy.deepcopy(project.stats))
    smoke.study["benchmark"]["pooling"]["depth_per_method"] = 20
    smoke.study["benchmark"]["verification"]["window_size"] = 20
    smoke.study["benchmark"]["verification"]["max_windows"] = 2
    smoke.study["retrieval"]["top_k"] = 10
    smoke.study["retrieval"]["batch_size"] = 32
    smoke.study["reranking"]["max_passages"] = 3
    smoke.study["reranking"]["max_length"] = 256
    smoke.study["experiment"]["workers"] = 4
    smoke.study["knowledge_graph"]["triple_audit"]["n_triples"] = 200

    available = set(workflow.llm(project).list_models())
    extractor = smoke.models["roles"]["kg_extractor"]["model"]
    if extractor not in available:
        raise RuntimeError(f"Configured KG extractor model {extractor!r} is unavailable for this API key.")
    for role, config in smoke.models["roles"].items():
        if config["model"] not in available:
            raise RuntimeError(f"Configured {role} model {config['model']!r} is unavailable for this API key.")

    write_jsonl(smoke.path("interim", "teleqna_candidates.jsonl"), questions)
    write_jsonl(smoke.path("interim", "passages.jsonl"), passages)
    write_json(smoke.path("manifests", "smoke_profile.json"), {
        "profile": "smoke50", "exploratory_only": True, "thesis_validated": False,
        "n_questions": len(questions), "n_passages": len(passages),
        "passages_by_spec": pd.Series([p["spec_id"] for p in passages]).value_counts().to_dict(),
        "seed": project.seed, "limits": {"kg_passages": n_kg_passages,
                                          "evaluated_questions_per_arm": n_eval_questions},
        "omitted_thesis_gates": ["300-question minimum", "blind question audit", "blind triple audit",
                                 "development ablation and held-out lock"],
    })

    client = workflow.llm(smoke)
    pool_encoder = e5()
    build_pools(smoke, questions, passages, pool_encoder)
    pool_map = {r["question_id"]: r["pool"] for r in read_jsonl(smoke.path("interim", "candidate_pools.jsonl"))}
    passage_map = {p["passage_id"]: p for p in passages}
    verify_run(smoke, client, questions, pool_map, passage_map, workers=4)
    verified = latest_records(smoke)

    extraction_path = extract.run(smoke, client, passages, workers=4, limit=n_kg_passages)
    instances = []
    for record in read_jsonl(extraction_path):
        if record.get("status") != "ok":
            continue
        for triple in record.get("triples", []):
            if triple.get("schema_valid") and triple.get("quote_found"):
                instances.append({**triple, "instance_id": f"{record['passage_id']}#{triple['local_id']}",
                                  "passage_id": record["passage_id"]})
    fidelity.run(smoke, client, instances, passage_map, workers=4)
    _, validated, kg_stats = graph.assemble(smoke, passage_map)

    enc = bge(smoke.study["retrieval"]["query_instruction"])
    retriever = Retriever.build(smoke, enc, passages)
    reranker = CrossEncoderReranker(smoke.study["reranking"]["model"],
                                    smoke.study["reranking"]["max_length"])
    kg = graph.load(smoke, enc)
    tokenizer = tiktoken.get_encoding("cl100k_base")
    counter = TokenCounter(client, smoke.path("cache", "token_counts.jsonl"),
                           local_fn=lambda text: len(tokenizer.encode(text)),
                           method="local exploratory tokenizer (cl100k_base)")
    gold = {qid: {"reference_passage_ids": record.get("reference_passage_ids", [])}
            for qid, record in verified.items() if record.get("decision") == "include"}
    pipeline = Pipeline(smoke, passage_map, retriever, reranker, 0.0, kg, counter, client,
                        gold=gold, groups={}, env_id="exploratory-smoke50-openai")

    bc_path = experiment_run(pipeline, questions,
                             [Condition("B"), Condition("C", "matched", 10, 1, 0.20)],
                             "smoke50_bc", "exploratory", [1], "dev", workers=4)
    controls_path = experiment_run(pipeline, questions[:min(10, len(questions))],
                                   [Condition("0"), Condition("A"),
                                    Condition("D", "matched", 10, 1, 0.20)],
                                   "smoke50_controls", "exploratory", [1], "dev", workers=4)
    runs = [*read_jsonl(bc_path), *read_jsonl(controls_path)]
    ok_runs = [r for r in runs if r.get("status") == "ok"]
    if not ok_runs:
        raise RuntimeError("No generation records succeeded; see the smoke experiment JSONL logs.")
    summary = pd.DataFrame(ok_runs).groupby("condition", as_index=False).agg(
        n=("question_id", "nunique"), accuracy=("correct", "mean"),
        answer_validity=("answer_valid", "mean"),
        mean_latency_s=("total_latency_s", "mean"), mean_cost_usd=("cost_usd", "mean"))
    summary.to_csv(smoke.path("tables", "smoke50_summary.csv"), index=False)

    retrieval_rows = []
    for qid, evidence in gold.items():
        relevant = set(evidence["reference_passage_ids"])
        if not relevant:
            continue
        ranked = next((r["retrieved_passage_ids"] for r in ok_runs
                       if r["configuration"] == "B" and r["question_id"] == qid), [])
        hits = [i + 1 for i, pid in enumerate(ranked) if pid in relevant]
        retrieval_rows.append({
            "question_id": qid, "n_gold_passages": len(relevant), "n_retrieved": len(ranked),
            "recall_at_1": len(set(ranked[:1]) & relevant) / len(relevant),
            "recall_at_3": len(set(ranked[:3]) & relevant) / len(relevant),
            "recall_at_5": len(set(ranked[:5]) & relevant) / len(relevant),
            "recall_at_10": len(set(ranked[:10]) & relevant) / len(relevant),
            "mrr_at_10": 1 / hits[0] if hits else 0.0,
            "full_coverage_at_10": int(relevant.issubset(set(ranked[:10]))),
        })
    retrieval = pd.DataFrame(retrieval_rows)
    if not retrieval.empty:
        retrieval.to_csv(smoke.path("tables", "smoke50_retrieval_quality.csv"), index=False)
        retrieval.mean(numeric_only=True).to_frame("mean").to_csv(
            smoke.path("tables", "smoke50_retrieval_summary.csv"))
    else:
        retrieval.to_csv(smoke.path("tables", "smoke50_retrieval_quality.csv"), index=False)

    eval_qids = {q["question_id"] for q in questions[:min(n_eval_questions, len(questions))]}
    eval_runs = [r for r in ok_runs if r["configuration"] in ("B", "C") and r["question_id"] in eval_qids]
    eval_input = smoke.path("dev", "smoke50_eval_input.jsonl")
    write_jsonl(eval_input, eval_runs)
    question_map = {q["question_id"]: q for q in questions}
    ragas_eval.run(smoke, client, pool_encoder, str(eval_input), question_map, None, "ragas_smoke50.jsonl",
                   workers=4)
    triple_relevance.run(smoke, client, [str(eval_input)], question_map, kg.by_id, passage_map, workers=4)

    cost_path = smoke.path("reports", "openai_budget.json")
    budget = __import__("json").loads(cost_path.read_text(encoding="utf-8")) if cost_path.exists() else {}
    report = {
        "profile": "smoke50", "exploratory_only": True, "thesis_validated": False,
        "questions_sampled": len(questions), "questions_verified": len(verified),
        "questions_with_verified_support": sum(r.get("decision") == "include" for r in verified.values()),
        "passages_sampled": len(passages), "kg_passages_attempted": min(n_kg_passages, len(passages)),
        "kg_statistics": kg_stats, "generation_records": len(runs),
        "successful_generation_records": len(ok_runs),
        "answerable_questions_in_sample": len(gold),
        "evaluation_records": len(read_jsonl(smoke.path("dev", "ragas_smoke50.jsonl"))),
        "summary_csv": str(smoke.path("tables", "smoke50_summary.csv")),
        "retrieval_summary_csv": str(smoke.path("tables", "smoke50_retrieval_summary.csv")),
        "openai_budget": budget,
        "output_root": str(smoke.root),
        "note": ("Exploratory subset; OpenAI model is shared across roles; retrieval metrics are conditional on "
                 "questions judged answerable in this sampled corpus; not thesis held-out results."),
    }
    write_json(smoke.path("reports", "smoke50_report.json"), report)
    return {"report": report, "summary": summary}
