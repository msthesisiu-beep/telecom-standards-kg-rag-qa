"""Stage 6: freeze the gold benchmark and the stratified 20/80 development/test split (Sec. 3.3, 4.5)."""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..core import Project, read_json, sha256_file, utc_now, write_json, write_jsonl


def stratified_split(df: pd.DataFrame, strata: list[str], dev_fraction: float, seed: int) -> tuple[list[str], list[str]]:
    """Per stratum: shuffle with the fixed seed, round(dev_fraction*n) go to development (>=1 if n>=2)."""
    rng = np.random.default_rng(seed)
    dev, test = [], []
    for _, g in df.sort_values("question_id").groupby(strata, dropna=False, sort=True):
        ids = g.question_id.tolist()
        rng.shuffle(ids)
        k = int(round(dev_fraction * len(ids)))
        if len(ids) >= 2:
            k = max(1, min(k, len(ids) - 1))
        dev += ids[:k]
        test += ids[k:]
    return sorted(dev), sorted(test)


def freeze(project: Project, register: pd.DataFrame, candidates: dict, passages: dict, force: bool = False) -> dict:
    lock = project.path("processed", "FROZEN.json")
    if lock.exists() and not force:
        raise RuntimeError("Benchmark already frozen (data/processed/FROZEN.json). The test set must not change "
                           "after tuning begins (Sec. 3.3). Use force=True only before ANY experiment has run.")
    inc = register[register.decision == "include"].copy()
    cfg = project.study["benchmark"]
    dev, test = stratified_split(inc, cfg["split"]["strata"], cfg["split"]["dev_fraction"], project.seed)
    gq, ge = [], []
    for _, r in inc.sort_values("question_id").iterrows():
        q = candidates[r.question_id]
        gq.append({"question_id": r.question_id, "category": r.category, "question": q["question"],
                   "options": q["options"], "answer_option_id": q["answer_option_id"],
                   "hop_type": r.hop_type, "question_type": r.question_type,
                   "split": "development" if r.question_id in set(dev) else "test"})
        ge.append({"question_id": r.question_id, "reference_passage_ids": list(r.reference_passage_ids),
                   "reference_clauses": [f"{passages[p]['specification']} {passages[p]['clause_id']}"
                                         for p in r.reference_passage_ids if p in passages],
                   "n_required": len(r.reference_passage_ids)})
    P = lambda n: project.path("processed", n)
    write_jsonl(P("gold_questions.jsonl"), gq)
    write_jsonl(P("gold_evidence.jsonl"), ge)
    write_json(P("development_ids.json"), dev)
    write_json(P("test_ids.json"), test)
    man = {"frozen_utc": utc_now(), "seed": project.seed, "n_included": len(inc), "n_development": len(dev),
           "n_test": len(test), "strata": cfg["split"]["strata"],
           "by_stratum": inc.groupby(cfg["split"]["strata"]).size().reset_index(name="n").to_dict("records"),
           "below_minimum": len(inc) < cfg["min_questions"],
           "sha256": {n: sha256_file(P(n)) for n in ("gold_questions.jsonl", "gold_evidence.jsonl",
                                                     "development_ids.json", "test_ids.json")},
           "passages_sha256": sha256_file(project.path("interim", "passages.jsonl")),
           "corpus_manifest_sha256": sha256_file(project.path("manifests", "corpus_manifest.json"))}
    write_json(lock, man)
    return man


def verify_frozen(project: Project) -> bool:
    man = read_json(project.path("processed", "FROZEN.json"))
    return all(sha256_file(project.path("processed", n)) == h for n, h in man["sha256"].items())


def load(project: Project) -> tuple[list[dict], dict[str, dict], list[str], list[str]]:
    from ..core import read_jsonl
    if not verify_frozen(project):
        raise RuntimeError("Frozen benchmark files changed after freezing — hashes do not match FROZEN.json")
    gq = read_jsonl(project.path("processed", "gold_questions.jsonl"))
    ge = {r["question_id"]: r for r in read_jsonl(project.path("processed", "gold_evidence.jsonl"))}
    return gq, ge, read_json(project.path("processed", "development_ids.json")), read_json(project.path("processed", "test_ids.json"))
