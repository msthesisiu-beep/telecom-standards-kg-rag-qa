"""Stage 18: Chapter 5 figures and tables, computed ONLY from the saved logs, plus a results manifest."""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ..core import Project, utc_now, write_json

SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
# Categorical identity follows the configuration family (fixed order, never cycled).
FAMILY_COLOR = {"0": "#52514e", "A": "#2a78d6", "B": "#eb6834", "C": "#1baf7a", "D": "#6250d6",
                "RANDOM": "#eda100", "UNFILTERED": "#e87ba4"}
SEQ = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]


def _style(ax, title: str, xlabel: str = "", ylabel: str = ""):
    ax.set_facecolor(SURFACE)
    ax.figure.set_facecolor(SURFACE)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(GRID)
    ax.tick_params(colors=INK2, labelsize=9)
    ax.grid(axis="y", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.set_title(title, color=INK, fontsize=11, loc="left")
    ax.set_xlabel(xlabel, color=INK2, fontsize=9)
    ax.set_ylabel(ylabel, color=INK2, fontsize=9)


def _save(fig, project: Project, name: str, manifest: list, sources: list[str], script: str = "kgrag.reporting.figures"):
    path = project.path("figures", name)
    fig.tight_layout()
    fig.savefig(path, dpi=220, facecolor=SURFACE)
    fig.savefig(path.with_suffix(".svg"), facecolor=SURFACE)
    plt.close(fig)
    manifest.append({"artifact": str(path.relative_to(project.root)), "script": script, "source_logs": sources,
                     "created_utc": utc_now()})


def _table(df: pd.DataFrame, project: Project, name: str, manifest: list, sources: list[str]):
    path = project.path("tables", name)
    df.to_csv(path, index=False)
    manifest.append({"artifact": str(path.relative_to(project.root)), "script": "kgrag.reporting.figures",
                     "source_logs": sources, "created_utc": utc_now()})


def make_all(project: Project, desc: pd.DataFrame, tests: pd.DataFrame, qc: pd.DataFrame, pq: pd.DataFrame,
             dev_summary: pd.DataFrame | None, extra_tables: dict[str, pd.DataFrame], sources: list[str]) -> list:
    man: list = []
    order = sorted(desc.condition, key=lambda c: (list(FAMILY_COLOR).index(c.split("_")[0]), c))
    d = desc.set_index("condition").loc[order].reset_index()
    col = [FAMILY_COLOR[c.split("_")[0]] for c in d.condition]

    # accuracy_comparison.png — bars with bootstrap 95% CIs
    fig, ax = plt.subplots(figsize=(10, 4.6))
    x = np.arange(len(d))
    ax.bar(x, d.accuracy_pct, color=col, width=0.62, edgecolor=SURFACE, linewidth=2)
    ax.errorbar(x, d.accuracy_pct, yerr=[d.accuracy_pct - d.accuracy_ci95_low, d.accuracy_ci95_high - d.accuracy_pct],
                fmt="none", ecolor=INK, elinewidth=1, capsize=3)
    ax.set_xticks(x, d.condition, rotation=40, ha="right")
    for xi, v in zip(x, d.accuracy_pct):
        ax.text(xi, v + 1, f"{v:.1f}", ha="center", va="bottom", fontsize=8, color=INK2)
    _style(ax, "Answer accuracy by condition (held-out test set; 95% bootstrap CI)", "", "Accuracy (%)")
    ax.set_ylim(0, 105)
    _save(fig, project, "accuracy_comparison.png", man, sources)

    # retrieval_mrr.csv + figure
    rcols = ["condition", "recall_at_1", "recall_at_3", "recall_at_5", "mrr", "full_coverage"]
    _table(d[[c for c in rcols if c in d]], project, "retrieval_mrr.csv", man, sources)

    # faithfulness: full vs passages-only
    if "faithfulness_full" in d:
        f = d.dropna(subset=["faithfulness_full"])
        if len(f):
            fig, ax = plt.subplots(figsize=(9, 4.2))
            x = np.arange(len(f))
            ax.bar(x - 0.18, f.faithfulness_full, 0.34, color="#2a78d6", label="Full context (passages + graph)")
            ax.bar(x + 0.18, f.faithfulness_passages, 0.34, color="#eb6834", label="Passages only")
            ax.set_xticks(x, f.condition, rotation=40, ha="right")
            ax.legend(frameon=False, fontsize=8)
            _style(ax, "Faithfulness: full context vs passages only (RAGAs protocol)", "", "Mean faithfulness")
            ax.set_ylim(0, 1.05)
            _save(fig, project, "faithfulness_full_vs_passages.png", man, sources)

    # latency_comparison.png — median with p95 whisker per stage-sum
    if "latency_total_s_median" in d:
        fig, ax = plt.subplots(figsize=(10, 4.4))
        x = np.arange(len(d))
        ax.bar(x, 1000 * d.latency_total_s_median, color=col, width=0.62, edgecolor=SURFACE, linewidth=2)
        ax.scatter(x, 1000 * d.latency_total_s_p95, marker="_", s=180, color=INK, label="95th percentile")
        ax.set_xticks(x, d.condition, rotation=40, ha="right")
        ax.legend(frameon=False, fontsize=8)
        _style(ax, "End-to-end latency per question (median bar, p95 tick)", "", "Milliseconds")
        _save(fig, project, "latency_comparison.png", man, sources)

    # tokens
    if "input_tokens_median" in d:
        fig, ax = plt.subplots(figsize=(10, 4.2))
        x = np.arange(len(d))
        ax.bar(x, d.input_tokens_median, color=col, width=0.62)
        ax.set_xticks(x, d.condition, rotation=40, ha="right")
        _style(ax, "Median input tokens per question (generator tokenizer)", "", "Tokens")
        _save(fig, project, "input_tokens.png", man, sources)

    # quality_cost_pareto.png
    q = qc.dropna(subset=["input_tokens_median"])
    if len(q):
        fig, ax = plt.subplots(figsize=(8, 5))
        for _, r in q.iterrows():
            c = FAMILY_COLOR[r.condition.split("_")[0]]
            ax.scatter(r.input_tokens_median, r.accuracy_pct, s=60, color=c,
                       edgecolor=INK if r.pareto_efficient_tokens else SURFACE, linewidth=1.5, zorder=3)
            ax.annotate(r.condition, (r.input_tokens_median, r.accuracy_pct), fontsize=7, color=INK2,
                        xytext=(4, 3), textcoords="offset points")
        ef = q[q.pareto_efficient_tokens].sort_values("input_tokens_median")
        ax.plot(ef.input_tokens_median, ef.accuracy_pct, color=INK2, linewidth=1, linestyle="--", zorder=2,
                label="Pareto frontier (dark outline = efficient)")
        ax.legend(frameon=False, fontsize=8)
        _style(ax, "Quality-cost trade-off", "Median input tokens per question", "Accuracy (%)")
        _save(fig, project, "quality_cost_pareto.png", man, sources)

    # subgroup accuracy
    subs = []
    for name, mask in {"single-hop": pq.hop_type == "single-hop", "multi-hop": pq.hop_type == "multi-hop",
                       "retriever-found": pq.retriever_group == "retriever-found",
                       "independent-only": pq.retriever_group == "independent-only"}.items():
        for cond, g in pq[mask].groupby("condition"):
            subs.append({"subgroup": name, "condition": cond, "n": len(g), "accuracy_pct": 100 * g.correct.mean()})
    sdf = pd.DataFrame(subs)
    _table(sdf, project, "subgroup_accuracy.csv", man, sources)
    key = [c for c in ["B", next((c for c in order if c.startswith("C_") and c.endswith("matched")), None)] if c]
    s2 = sdf[sdf.condition.isin(key)] if len(sdf) else sdf
    if len(s2):
        fig, ax = plt.subplots(figsize=(8, 4))
        groups = list(dict.fromkeys(s2.subgroup))
        x = np.arange(len(groups))
        for k, cnd in enumerate(key):
            vals = [s2[(s2.subgroup == g) & (s2.condition == cnd)].accuracy_pct.mean() for g in groups]
            ax.bar(x + (k - 0.5) * 0.36, vals, 0.34, color=FAMILY_COLOR[cnd.split("_")[0]], label=cnd)
        ax.set_xticks(x, groups)
        ax.legend(frameon=False, fontsize=8)
        _style(ax, "Accuracy by subgroup: B vs C (default, matched)", "", "Accuracy (%)")
        _save(fig, project, "subgroup_accuracy.png", man, sources)

    # kg_ablation_heatmap.png (development only)
    if dev_summary is not None and len(dev_summary):
        fig, axes = plt.subplots(1, 2, figsize=(9, 3.8), sharey=True)
        vmin, vmax = 100 * dev_summary.accuracy.min(), 100 * dev_summary.accuracy.max()
        for ax, h in zip(axes, sorted(dev_summary.hops.unique())):
            g = dev_summary[dev_summary.hops == h].pivot_table(index="triples", columns="alloc", values="accuracy") * 100
            im = ax.imshow(g.values, cmap=matplotlib.colors.LinearSegmentedColormap.from_list("seq", SEQ),
                           vmin=vmin, vmax=vmax, aspect="auto")
            ax.set_xticks(range(len(g.columns)), [f"{int(a * 100)}%" for a in g.columns])
            ax.set_yticks(range(len(g.index)), g.index)
            for i in range(g.shape[0]):
                for j in range(g.shape[1]):
                    v = g.values[i, j]
                    ax.text(j, i, f"{v:.1f}", ha="center", va="center", fontsize=8,
                            color="#ffffff" if v > (vmin + vmax) / 2 else INK)
            ax.set_title(f"{h}-hop", fontsize=10, color=INK, loc="left")
            ax.set_xlabel("Graph-token allocation", color=INK2, fontsize=9)
        axes[0].set_ylabel("Triple budget", color=INK2, fontsize=9)
        fig.colorbar(im, ax=axes, label="Development accuracy (%)", shrink=0.85)
        fig.suptitle("KG ablation on the development split (18 variants; selection only, not tested)", fontsize=10,
                     color=INK, x=0.02, ha="left")
        fig.set_facecolor(SURFACE)
        path = project.path("figures", "kg_ablation_heatmap.png")
        fig.savefig(path, dpi=220, facecolor=SURFACE, bbox_inches="tight")
        plt.close(fig)
        man.append({"artifact": str(path.relative_to(project.root)), "script": "kgrag.reporting.figures",
                    "source_logs": [str(project.path("dev", "ablation_development_summary.csv"))], "created_utc": utc_now()})
        _table(dev_summary, project, "kg_ablation_development.csv", man, sources)

    # allocation sensitivity (test, selected variants) + matched vs overhead
    c = d[d.condition.str.startswith("C_")]
    if len(c):
        _table(c[["condition", "budget_mode", "accuracy_pct", "accuracy_ci95_low", "accuracy_ci95_high"] +
                 [x for x in ["graph_tokens_median", "input_tokens_median"] if x in c]], project,
               "matched_vs_overhead.csv", man, sources)

    _table(desc, project, "descriptive_by_condition.csv", man, sources)
    _table(tests, project, "statistical_tests.csv", man, sources)
    _table(qc, project, "quality_cost.csv", man, sources)
    for n, t in extra_tables.items():
        _table(t, project, n, man, sources)
    write_json(project.root / "results" / "results_manifest.json", {"created_utc": utc_now(), "artifacts": man})
    return man
