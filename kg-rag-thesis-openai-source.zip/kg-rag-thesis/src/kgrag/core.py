"""Shared infrastructure: configuration, paths, hashing, atomic/append-only IO, stage tracker."""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Iterator

import yaml

_LOCK = threading.Lock()


def utc_now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat()


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_text(s: str) -> str:
    return sha256_bytes(s.encode("utf-8"))


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def stable_hash(obj: Any, n: int = 12) -> str:
    """Deterministic short hash of any JSON-serialisable object."""
    return sha256_text(json.dumps(obj, sort_keys=True, ensure_ascii=False, default=str))[:n]


# ----------------------------------------------------------------------------- config
@dataclass
class Project:
    root: Path
    study: dict
    models: dict
    stats: dict

    @classmethod
    def load(cls, root: str | Path) -> "Project":
        root = Path(root).resolve()
        ld = lambda n: yaml.safe_load((root / "configs" / n).read_text(encoding="utf-8"))
        p = cls(root, ld("study.yaml"), ld("models.yaml"), ld("statistical_plan.yaml"))
        for d in p.dirs().values():
            d.mkdir(parents=True, exist_ok=True)
        return p

    def dirs(self) -> dict[str, Path]:
        r = self.root
        return {k: r / v for k, v in {
            "raw_q": "data/raw/teleqna", "raw_md": "data/raw/tspec", "interim": "data/interim",
            "processed": "data/processed", "manifests": "data/manifests", "logs": "logs",
            "dev": "results/development", "test": "results/heldout", "reports": "reports",
            "figures": "artifacts/figures", "tables": "artifacts/tables", "diagrams": "artifacts/diagrams",
            "audit": "reports/audit", "cache": "data/interim/cache",
        }.items()}

    def path(self, key: str, name: str = "") -> Path:
        d = self.dirs()[key]
        return d / name if name else d

    @property
    def seed(self) -> int:
        return int(self.study["seed"])

    def config_hash(self) -> str:
        return stable_hash({"study": self.study, "models": self.models, "stats": self.stats})


# ----------------------------------------------------------------------------- IO
def atomic_write_text(path: str | Path, text: str) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def write_json(path: str | Path, obj: Any) -> None:
    atomic_write_text(path, json.dumps(obj, indent=2, ensure_ascii=False, default=str))


def read_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_jsonl(path: str | Path, rows: Iterable[dict]) -> int:
    lines = [json.dumps(r, ensure_ascii=False, default=str) for r in rows]
    atomic_write_text(path, "\n".join(lines) + ("\n" if lines else ""))
    return len(lines)


def append_jsonl(path: str | Path, row: dict) -> None:
    """Thread-safe append of one record (raw immutable logs are append-only)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(row, ensure_ascii=False, default=str) + "\n"
    with _LOCK:
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)
            f.flush()
            os.fsync(f.fileno())


def iter_jsonl(path: str | Path) -> Iterator[dict]:
    path = Path(path)
    if not path.exists():
        return
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                continue  # a torn final line from an interrupted run is ignored, never repaired


def read_jsonl(path: str | Path) -> list[dict]:
    return list(iter_jsonl(path))


# ----------------------------------------------------------------------------- stage tracker / gates
STATUSES = ["NOT STARTED", "IN PROGRESS", "BLOCKED", "IMPLEMENTED", "TESTED", "VALIDATED"]
GATES = {
    1: "Environment and dependencies verified",
    2: "Dataset files obtained and versions confirmed",
    3: "Corpus preprocessing validated",
    4: "Independent answerability verification completed",
    5: "Manual audit meets criteria and gold benchmark frozen",
    6: "BGE retrieval and cross-encoder reranking validated",
    7: "Knowledge Graph extracted and fidelity audited",
    8: "Configurations 0-D implemented and invariance checks passed",
    9: "Development ablation completed and parameters frozen",
    10: "Held-out experimental runs completed",
    11: "Metrics and statistical tests validated",
    12: "Final artifacts, diagrams and reproducibility package verified",
}


class Tracker:
    """Gate tracker persisted at reports/stage_tracker.json (Master prompt Stage 22)."""

    def __init__(self, project: Project):
        self.path = project.path("reports", "stage_tracker.json")
        self.state = read_json(self.path) if self.path.exists() else {
            str(g): {"title": t, "status": "NOT STARTED", "evidence": [], "updated": None} for g, t in GATES.items()}

    def set(self, gate: int, status: str, evidence: list[str] | str | None = None, note: str = "") -> None:
        assert status in STATUSES, status
        rec = self.state[str(gate)]
        rec["status"] = status
        if evidence:
            rec["evidence"] = sorted(set(rec["evidence"] + ([evidence] if isinstance(evidence, str) else evidence)))
        if note:
            rec["note"] = note
        rec["updated"] = utc_now()
        write_json(self.path, self.state)

    def require(self, gate: int) -> None:
        st = self.state[str(gate)]["status"]
        if st != "VALIDATED":
            raise RuntimeError(f"Gate {gate} ({GATES[gate]}) is '{st}', not VALIDATED. "
                               "Do not advance (Master prompt Stage 22).")

    def table(self) -> str:
        rows = [f"| {g} | {r['title']} | {r['status']} | {r.get('note', '')} |" for g, r in self.state.items()]
        return "| Gate | Title | Status | Note |\n|---|---|---|---|\n" + "\n".join(rows)
