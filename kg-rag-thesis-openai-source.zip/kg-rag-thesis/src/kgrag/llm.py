"""Gemini API client with structured JSON output, retries, usage and cost accounting.

All LLM roles go through `LLMClient.generate_json`. A `FakeLLM` with the same interface is used in unit tests,
so no test ever calls a hosted model and no synthetic output can enter a results file.
"""
from __future__ import annotations

import json
import os
import random
import re
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Protocol

from .core import append_jsonl, iter_jsonl, sha256_text


@dataclass
class LLMResult:
    data: dict | None
    text: str
    model: str
    model_version: str | None
    input_tokens: int | None
    output_tokens: int | None          # candidates + thoughts (both billed as output)
    thought_tokens: int | None
    latency_s: float
    error: str | None = None
    attempts: int = 1
    cost_usd: float | None = None

    @property
    def ok(self) -> bool:
        return self.error is None and self.data is not None


class LLMClient(Protocol):
    def generate_json(self, role: str, prompt: str, schema: dict | None = None,
                      system: str | None = None, seed: int | None = None) -> LLMResult: ...

    def count_tokens(self, role: str, text: str) -> int: ...

    def model_of(self, role: str) -> str: ...


def parse_json_loose(text: str) -> dict | None:
    """Parse a JSON object from model text; tolerate ```json fences. Never invents content."""
    if not text:
        return None
    t = text.strip()
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", t)
    try:
        v = json.loads(t)
        return v if isinstance(v, dict) else {"_list": v}
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", t, re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                return None
    return None


class GeminiClient:
    """google-genai SDK wrapper. Requires `pip install google-genai`."""

    def __init__(self, models_cfg: dict, api_key: str | None = None, max_retries: int = 6):
        from google import genai  # lazy import
        from google.genai import types
        self._types = types
        key = api_key or os.environ.get(models_cfg.get("api_key_secret", "GEMINI_API_KEY"))
        if not key:
            raise RuntimeError("GEMINI_API_KEY not found (Colab: key icon -> add secret, enable notebook access)")
        self.client = genai.Client(api_key=key)
        self.cfg = models_cfg
        self.max_retries = max_retries

    def model_of(self, role: str) -> str:
        return self.cfg["roles"][role]["model"]

    def price(self, model: str) -> dict | None:
        return self.cfg.get("pricing_usd_per_million", {}).get(model)

    def _config(self, role: str, schema: dict | None, system: str | None, seed: int | None):
        r = self.cfg["roles"][role]
        kw: dict[str, Any] = dict(temperature=r.get("temperature", 0.0),
                                  max_output_tokens=r.get("max_output_tokens", 2048))
        if seed is not None:
            kw["seed"] = int(seed)
        if system:
            kw["system_instruction"] = system
        kw["response_mime_type"] = "application/json"
        if schema is not None:
            kw["response_json_schema"] = schema
        if r.get("thinking_level"):
            kw["thinking_config"] = self._types.ThinkingConfig(thinking_level=r["thinking_level"])
        try:
            return self._types.GenerateContentConfig(**kw)
        except Exception:  # older SDK without response_json_schema / thinking_level
            kw.pop("thinking_config", None)
            if "response_json_schema" in kw:
                kw["response_schema"] = kw.pop("response_json_schema")
            return self._types.GenerateContentConfig(**kw)

    def generate_json(self, role: str, prompt: str, schema: dict | None = None,
                      system: str | None = None, seed: int | None = None) -> LLMResult:
        model = self.model_of(role)
        cfg = self._config(role, schema, system, seed)
        last_err, t0 = None, time.perf_counter()
        for attempt in range(1, self.max_retries + 1):
            t0 = time.perf_counter()
            try:
                resp = self.client.models.generate_content(model=model, contents=prompt, config=cfg)
                lat = time.perf_counter() - t0
                text = resp.text or ""
                um = getattr(resp, "usage_metadata", None)
                inp = getattr(um, "prompt_token_count", None) if um else None
                cand = getattr(um, "candidates_token_count", None) if um else None
                th = getattr(um, "thoughts_token_count", None) if um else None
                out = (cand or 0) + (th or 0) if (cand is not None or th is not None) else None
                data = parse_json_loose(text)
                pr = self.price(model)
                cost = (inp * pr["input"] + out * pr["output"]) / 1e6 if (pr and inp is not None and out is not None) else None
                return LLMResult(data, text, model, getattr(resp, "model_version", None), inp, out, th, lat,
                                 None if data is not None else "unparseable_json", attempt, cost)
            except Exception as e:  # retry on rate limits / transient server errors
                last_err = f"{type(e).__name__}: {e}"
                transient = any(s in last_err for s in ("429", "RESOURCE_EXHAUSTED", "500", "502", "503", "504",
                                                        "UNAVAILABLE", "DEADLINE", "Timeout", "timed out", "Connection"))
                if not transient or attempt == self.max_retries:
                    break
                time.sleep(min(60, 2 ** attempt) + random.random())
        return LLMResult(None, "", model, None, None, None, None, time.perf_counter() - t0, last_err, self.max_retries)

    def count_tokens(self, role: str, text: str) -> int:
        for attempt in range(1, self.max_retries + 1):
            try:
                return int(self.client.models.count_tokens(model=self.model_of(role), contents=text).total_tokens)
            except Exception as e:
                if attempt == self.max_retries:
                    raise
                time.sleep(min(30, 2 ** attempt) + random.random())
        raise RuntimeError("unreachable")

    def list_models(self) -> list[str]:
        return [m.name.split("/")[-1] for m in self.client.models.list()]


class BudgetExceededError(RuntimeError):
    """Raised before an OpenAI request when its safety reservation exceeds the run cap."""


class OpenAIClient:
    """OpenAI Chat Completions client with JSON-schema output and a persistent USD run cap."""

    def __init__(self, models_cfg: dict, budget_path: str | Path | None = None,
                 api_key: str | None = None):
        from openai import OpenAI

        key_name = models_cfg.get("api_key_secret", "OPENAI_API_KEY")
        key = api_key or os.environ.get(key_name)
        if not key:
            raise RuntimeError(f"{key_name} is not set; add it to the ignored project .env file.")
        self.client = OpenAI(api_key=key, max_retries=0)
        self.cfg = models_cfg
        self.budget_cap = float(models_cfg.get("max_run_cost_usd", 5.0))
        self.budget_path = Path(budget_path) if budget_path else None
        self._lock = threading.Lock()
        state = {}
        if self.budget_path and self.budget_path.exists():
            state = json.loads(self.budget_path.read_text(encoding="utf-8"))
        self.spent_usd = float(state.get("spent_usd", 0.0))
        self.reserved_usd = float(state.get("reserved_usd", 0.0))
        self._encoding = None

    def model_of(self, role: str) -> str:
        return self.cfg["roles"][role]["model"]

    def price(self, model: str) -> dict:
        prices = self.cfg.get("pricing_usd_per_million", {}).get(model)
        if not prices:
            raise ValueError(f"No OpenAI token price configured for {model!r}; refusing an unmetered request.")
        return prices

    def _count(self, text: str) -> int:
        if self._encoding is None:
            import tiktoken
            try:
                self._encoding = tiktoken.encoding_for_model(self.model_of("generator"))
            except KeyError:
                self._encoding = tiktoken.get_encoding("cl100k_base")
        return len(self._encoding.encode(text))

    def count_tokens(self, role: str, text: str) -> int:
        return self._count(text)

    @staticmethod
    def _strict_schema(schema: dict) -> dict:
        """Normalize the project's JSON schemas to OpenAI strict structured-output rules."""
        result = json.loads(json.dumps(schema))
        def visit(node: dict) -> None:
            if node.get("type") == "object":
                props = node.get("properties", {})
                node["required"] = list(props)
                node["additionalProperties"] = False
                for child in props.values():
                    visit(child)
            if node.get("type") == "array" and isinstance(node.get("items"), dict):
                visit(node["items"])
        visit(result)
        return result

    def _persist_budget(self) -> None:
        if self.budget_path:
            from .core import write_json
            write_json(self.budget_path, {
                "provider": "openai", "budget_cap_usd": self.budget_cap,
                "spent_usd": round(self.spent_usd, 8),
                "reserved_usd": round(self.reserved_usd, 8),
                "remaining_usd": round(max(0.0, self.budget_cap - self.spent_usd - self.reserved_usd), 8),
            })

    def _reserve(self, role: str, prompt: str, system: str | None) -> tuple[float, int, int]:
        model = self.model_of(role)
        price = self.price(model)
        input_estimate = self._count((system or "") + "\n" + prompt) + 32
        output_limit = int(self.cfg["roles"][role].get("max_output_tokens", 1024))
        reserve = ((input_estimate * price["input"]) + (output_limit * price["output"])) / 1_000_000
        reserve *= float(self.cfg.get("budget_safety_multiplier", 1.25))
        with self._lock:
            if self.spent_usd + self.reserved_usd + reserve > self.budget_cap:
                self._persist_budget()
                raise BudgetExceededError(
                    f"OpenAI run budget cap ${self.budget_cap:.2f} would be exceeded; "
                    f"spent ${self.spent_usd:.4f}, reserved ${self.reserved_usd:.4f}, "
                    f"next-call safety estimate ${reserve:.4f}."
                )
            self.reserved_usd += reserve
            self._persist_budget()
        return reserve, input_estimate, output_limit

    def _settle(self, reserve: float, actual_cost: float) -> None:
        with self._lock:
            self.reserved_usd = max(0.0, self.reserved_usd - reserve)
            self.spent_usd += actual_cost
            self._persist_budget()

    def _release(self, reserve: float) -> None:
        with self._lock:
            self.reserved_usd = max(0.0, self.reserved_usd - reserve)
            self._persist_budget()

    def generate_json(self, role: str, prompt: str, schema: dict | None = None,
                      system: str | None = None, seed: int | None = None) -> LLMResult:
        model = self.model_of(role)
        reserve, input_estimate, output_limit = self._reserve(role, prompt, system)
        start = time.perf_counter()
        api_completed = False
        settled = False
        try:
            request = {
                "model": model,
                "messages": ([{"role": "system", "content": system}] if system else []) +
                            [{"role": "user", "content": prompt}],
                "temperature": float(self.cfg["roles"][role].get("temperature", 0.0)),
                "max_tokens": output_limit,
                "response_format": (
                    {"type": "json_schema", "json_schema": {
                        "name": re.sub(r"[^a-zA-Z0-9_-]", "_", role)[:64],
                        "strict": True,
                        "schema": self._strict_schema(schema),
                    }} if schema else {"type": "json_object"}
                ),
            }
            if seed is not None:
                request["seed"] = int(seed)
            response = self.client.chat.completions.create(**request)
            api_completed = True
            latency = time.perf_counter() - start
            choice = response.choices[0]
            text = choice.message.content or ""
            data = parse_json_loose(text)
            usage = response.usage
            inp = getattr(usage, "prompt_tokens", None) if usage else None
            out = getattr(usage, "completion_tokens", None) if usage else None
            price = self.price(model)
            actual_cost = ((inp if inp is not None else input_estimate) * price["input"] +
                           (out if out is not None else output_limit) * price["output"]) / 1_000_000
            self._settle(reserve, actual_cost)
            settled = True
            refusal = getattr(choice.message, "refusal", None)
            err = f"OpenAI refusal: {refusal}" if refusal else (None if data is not None else "unparseable_json")
            return LLMResult(data, text, model, getattr(response, "model", model), inp, out, None,
                             latency, err, 1, actual_cost)
        except Exception as exc:
            error_type = type(exc).__name__
            if not settled and (api_completed or error_type in {
                    "APIConnectionError", "APITimeoutError", "InternalServerError"}):
                self._settle(reserve, reserve)
                settled = True
            elif not settled:
                self._release(reserve)
            return LLMResult(None, "", model, None, None, None, None, time.perf_counter() - start,
                             f"{error_type}: {exc}", 1, reserve if settled else None)

    def list_models(self) -> list[str]:
        return [model.id for model in self.client.models.list()]


class FakeLLM:
    """Deterministic test double. `responder(role, prompt) -> dict`. Token count = whitespace words."""

    def __init__(self, responder: Callable[[str, str], dict], models: dict[str, str] | None = None):
        self.responder = responder
        self.models = models or {"generator": "fake-gen", "verifier": "fake-ver", "evaluator": "fake-eval",
                                 "kg_extractor": "fake-kg"}
        self.calls: list[tuple[str, str]] = []

    def model_of(self, role: str) -> str:
        return self.models[role]

    def generate_json(self, role, prompt, schema=None, system=None, seed=None) -> LLMResult:
        self.calls.append((role, prompt))
        d = self.responder(role, prompt)
        return LLMResult(d, json.dumps(d), self.models[role], "fake-1", len(prompt.split()), 10, 0, 0.001,
                         None if d is not None else "unparseable_json")

    def count_tokens(self, role, text):
        return len(text.split())


def local_gemini_tokenizer(model: str, fallbacks: tuple[str, ...] = ("gemini-3-flash", "gemini-2.5-flash")):
    """google-genai LocalTokenizer (offline SentencePiece). Returns (callable, tokenizer_name) or (None, reason)."""
    try:
        from google.genai.local_tokenizer import LocalTokenizer
    except Exception as e:
        return None, f"LocalTokenizer unavailable: {e}"
    for name in (model, *fallbacks):
        try:
            tok = LocalTokenizer(model_name=name)
            tok.count_tokens("probe")
            return (lambda s, _t=tok: int(_t.count_tokens(s).total_tokens)), name
        except Exception:
            continue
    return None, "no LocalTokenizer model name accepted"


def calibrate_local_tokenizer(llm: LLMClient, local_fn, texts: list[str], role: str = "generator") -> dict:
    """Compare local counts with the hosted count_tokens endpoint on real texts. Use local only if exact on >=99%."""
    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(16) as ex:
        api = list(ex.map(lambda t: llm.count_tokens(role, t), texts))
    loc = [local_fn(t) for t in texts]
    exact = sum(a == b for a, b in zip(api, loc)) / max(1, len(texts))
    rel = max((abs(a - b) / a for a, b in zip(api, loc) if a), default=0.0)
    return {"n": len(texts), "exact_match_rate": exact, "max_relative_error": rel, "use_local": exact >= 0.99}


class TokenCounter:
    """Generator-tokenizer token counts (Sec. 3.5: T_q counted with the generation model's tokenizer).

    Counts come from the Gemini count_tokens endpoint, or from the SDK's local tokenizer when calibration shows it is
    identical (>=99% exact on real corpus texts). Cached on disk by text hash.
    """

    def __init__(self, llm: LLMClient, cache_path: str | Path | None, role: str = "generator", local_fn=None,
                 method: str = "api"):
        self.llm, self.role, self.local_fn, self.method = llm, role, local_fn, method if local_fn else "api"
        self.cache_path = Path(cache_path) if cache_path else None
        self._c: dict[str, int] = {}
        self._lock = threading.Lock()
        if self.cache_path:
            for r in iter_jsonl(self.cache_path):
                self._c[r["h"]] = r["n"]
        self.model = llm.model_of(role)

    def __call__(self, text: str) -> int:
        if not text:
            return 0
        if self.local_fn is not None:
            return self.local_fn(text)
        h = sha256_text(self.model + "\x00" + text)[:24]
        with self._lock:
            if h in self._c:
                return self._c[h]
        n = self.llm.count_tokens(self.role, text)
        with self._lock:
            self._c[h] = n
        if self.cache_path:
            append_jsonl(self.cache_path, {"h": h, "n": n})
        return n

    def prefetch(self, texts: list[str], workers: int = 16) -> None:
        if self.local_fn is not None:
            return
        from concurrent.futures import ThreadPoolExecutor
        todo = list({t for t in texts if t})
        with ThreadPoolExecutor(workers) as ex:
            list(ex.map(self, todo))
