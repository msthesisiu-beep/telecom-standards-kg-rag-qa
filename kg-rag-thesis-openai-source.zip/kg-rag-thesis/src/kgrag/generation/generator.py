"""Stage 14: common generation interface (Sec. 3.4 Comp. 5, 4.9). Same model, prompt, decoding for every configuration.

Selected generator: models.yaml role `generator` (gemini-3.8-flash, temperature 0, thinking_level low) — selection
rationale recorded in reports/model_selection.md. Malformed / missing option => incorrect. Exceptions are logged.
"""
from __future__ import annotations

import re

from ..core import sha256_text
from ..llm import LLMClient

PROMPT_VERSION = "gen-v1.0"
SYSTEM = ("You are a 3GPP telecommunications standards expert answering multiple-choice questions. "
          "When evidence is supplied, base your answer on it and cite it; do not invent clause numbers.")
TEMPLATE = """EVIDENCE:
{evidence}

QUESTION: {question}
OPTIONS:
{options}

Instructions:
1. Select exactly one option by its number.
2. Give a concise technical justification (at most 120 words).
3. List the labels of the evidence items you relied on (e.g. "P1", "G2"). Use only labels that appear in EVIDENCE.
   If no evidence is supplied, return an empty list.
Return JSON with keys: answer_option, justification, citations."""
NO_EVIDENCE = "No evidence is supplied for this question. Answer from your own knowledge."


def schema(option_ids: list[str]) -> dict:
    return {"type": "object", "properties": {
        "answer_option": {"type": "string", "enum": option_ids},
        "justification": {"type": "string"},
        "citations": {"type": "array", "items": {"type": "string"}}},
        "required": ["answer_option", "justification", "citations"]}


def build_prompt(q: dict, evidence_text: str) -> str:
    opts = "\n".join(f"{k}: {v}" for k, v in sorted(q["options"].items(), key=lambda kv: int(kv[0])))
    return TEMPLATE.format(evidence=evidence_text or NO_EVIDENCE, question=q["question"], options=opts)


TEMPLATE_HASH = sha256_text(SYSTEM + TEMPLATE + NO_EVIDENCE)[:16]


def parse_option(data: dict | None, option_ids: list[str]) -> str | None:
    if not data:
        return None
    v = str(data.get("answer_option", "")).strip()
    m = re.search(r"(\d+)", v)
    v = m.group(1) if m else v
    return v if v in option_ids else None


def generate(llm: LLMClient, q: dict, evidence_text: str, seed: int) -> dict:
    ids = sorted(q["options"], key=int)
    prompt = build_prompt(q, evidence_text)
    r = llm.generate_json("generator", prompt, schema(ids), SYSTEM, seed=seed)
    opt = parse_option(r.data, ids)
    cits = [str(c).strip().strip("[]") for c in (r.data or {}).get("citations", []) or []] if r.data else []
    return {"parsed_option": opt, "answer_valid": opt is not None, "justification": (r.data or {}).get("justification", ""),
            "citations": cits, "raw_text": r.text, "generation_error": r.error, "generator_model": r.model,
            "generator_model_version": r.model_version, "input_tokens": r.input_tokens, "output_tokens": r.output_tokens,
            "thought_tokens": r.thought_tokens, "generation_latency_s": r.latency_s, "generation_cost_usd": r.cost_usd,
            "prompt_sha": sha256_text(prompt)[:16], "template_hash": TEMPLATE_HASH, "prompt_version": PROMPT_VERSION}
