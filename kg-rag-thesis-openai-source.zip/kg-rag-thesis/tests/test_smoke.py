from kgrag.smoke import _sample_passages, _sample_questions


def test_smoke_question_sample_is_release17_and_deterministic():
    rows = [
        {"question_id": "r1", "source_tag": "3GPP Release 17", "category": "spec", "answer_parsed": True},
        {"question_id": "r2", "source_tag": "3GPP Release 18", "category": "spec", "answer_parsed": True},
        {"question_id": "r3", "source_tag": "3GPP Release 17", "category": "overview", "answer_parsed": True},
        {"question_id": "r4", "source_tag": "3GPP Release 17", "category": "spec", "answer_parsed": False},
    ]

    a = _sample_questions(rows, 2, 42)
    b = _sample_questions(rows, 2, 42)

    assert [q["question_id"] for q in a] == [q["question_id"] for q in b]
    assert {q["source_tag"] for q in a} == {"3GPP Release 17"}
    assert len({q["category"] for q in a}) == 2


def test_smoke_passages_are_sampled_across_specs_deterministically():
    rows = [{"passage_id": f"{spec}-{i}", "spec_id": spec} for spec in ("23501", "24501") for i in range(5)]

    a = _sample_passages(rows, 4, 42)
    b = _sample_passages(rows, 4, 42)

    assert [p["passage_id"] for p in a] == [p["passage_id"] for p in b]
    assert {p["spec_id"] for p in a} == {"23501", "24501"}
    assert len(a) == 4
