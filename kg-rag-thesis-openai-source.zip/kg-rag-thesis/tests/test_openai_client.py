import json
import sys
from types import ModuleType, SimpleNamespace

import pytest

from kgrag.llm import BudgetExceededError, OpenAIClient


class FakeOpenAI:
    def __init__(self, **kwargs):
        self.api_key = kwargs["api_key"]
        self.calls = []
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))
        self.models = SimpleNamespace(list=lambda: [SimpleNamespace(id="gpt-4o-mini")])

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content='{"ok":true}', refusal=None))],
            usage=SimpleNamespace(prompt_tokens=1000, completion_tokens=1000),
            model="gpt-4o-mini",
        )


@pytest.fixture
def fake_openai(monkeypatch):
    module = ModuleType("openai")
    module.OpenAI = FakeOpenAI
    monkeypatch.setitem(sys.modules, "openai", module)


def _config(cap=0.001):
    return {
        "api_key_secret": "OPENAI_API_KEY",
        "max_run_cost_usd": cap,
        "budget_safety_multiplier": 1.25,
        "roles": {"verifier": {"model": "gpt-4o-mini", "temperature": 0.0, "max_output_tokens": 1024}},
        "pricing_usd_per_million": {"gpt-4o-mini": {"input": 0.15, "output": 0.60}},
    }


def test_openai_client_uses_strict_json_and_records_budget(tmp_path, monkeypatch, fake_openai):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key-not-real")
    ledger = tmp_path / "budget.json"
    client = OpenAIClient(_config(), ledger)

    result = client.generate_json("verifier", "Return the object", {
        "type": "object", "properties": {"ok": {"type": "boolean"}}, "required": ["ok"],
    })

    assert result.ok
    assert result.data == {"ok": True}
    assert result.cost_usd == pytest.approx(0.00075)
    state = json.loads(ledger.read_text())
    assert state["spent_usd"] == pytest.approx(0.00075)
    assert state["budget_cap_usd"] == 0.001


def test_openai_client_refuses_call_before_budget_would_be_exceeded(tmp_path, monkeypatch, fake_openai):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key-not-real")
    ledger = tmp_path / "budget.json"
    client = OpenAIClient(_config(), ledger)
    first = client.generate_json("verifier", "Return the object")
    assert first.ok

    with pytest.raises(BudgetExceededError):
        client.generate_json("verifier", "Return another object")

    assert len(client.client.calls) == 1
    state = json.loads(ledger.read_text())
    assert state["spent_usd"] < state["budget_cap_usd"]


def test_openai_client_keeps_reservation_after_ambiguous_timeout(tmp_path, monkeypatch, fake_openai):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key-not-real")
    ledger = tmp_path / "budget.json"
    client = OpenAIClient(_config(), ledger)

    class APITimeoutError(Exception):
        pass

    def timeout(**kwargs):
        raise APITimeoutError("request timed out")

    client.client.chat.completions.create = timeout
    result = client.generate_json("verifier", "Return the object")

    state = json.loads(ledger.read_text())
    assert not result.ok
    assert result.cost_usd is not None
    assert state["reserved_usd"] == 0
    assert state["spent_usd"] == pytest.approx(result.cost_usd)
