"""End-to-end smoke test of runner -> per-question table -> all statistical families -> figures (fake models only)."""
from pathlib import Path

import pandas as pd

from conftest import HashEncoder, LenReranker, make_passage, wcount
from kgrag.core import write_json
from kgrag.experiments import runner as R
from kgrag.experiments.selection import heldout_conditions
from kgrag.knowledge_graph.graph import KGIndex
from kgrag.llm import FakeLLM
from kgrag.reporting.figures import make_all
from kgrag.retrieval.dense import Retriever
from kgrag.statistics import analysis as A
from test_pipeline_and_stats import KG, WORDS


def test_full_analysis_path(project):
    ps = {f"p{i}": make_passage(f"p{i}", clause=f"5.{i}", text=(f"Clause {i}. " + WORDS + ". ") * (1 + i % 3))
          for i in range(10)}
    enc = HashEncoder()
    ret = Retriever(enc, list(ps.values()), enc.encode_passages([p["text"] for p in ps.values()]), top_k=8)
    qs = [{"question_id": f"q{i}", "question": f"Which message does the AMF send {i}?", "options": {"1": "Reject", "2": "Accept"},
           "answer_option_id": "2", "hop_type": "single-hop" if i % 2 else "multi-hop", "question_type": "factual_lookup"}
          for i in range(12)]
    gold = {q["question_id"]: {"reference_passage_ids": ["p0"]} for q in qs}
    groups = {q["question_id"]: ("retriever-found" if i % 3 else "independent-only") for i, q in enumerate(qs)}

    def resp(role, prompt):
        return {"answer_option": "2" if "Accept" in prompt and "EVIDENCE:\nNo evidence" not in prompt else "1",
                "justification": "Because of P1.", "citations": ["P1"]}
    pipe = R.Pipeline(project, ps, ret, LenReranker(), 0.0, KGIndex(KG, enc), wcount, FakeLLM(resp), gold, groups)
    write_json(project.path("reports", "rerank_threshold.json"), {"threshold": 0.0})
    write_json(project.path("reports", "frozen_parameters.json"),
               {"selected_variants": [{"triples": 10, "hops": 1, "alloc": 0.2}, {"triples": 5, "hops": 2, "alloc": 0.1}]})
    conds = heldout_conditions(project)
    assert any(c.name == "C_t10_h1_g20_matched" for c in conds) and any(c.config == "D" for c in conds)
    out = R.run(pipe, qs, conds, "heldout_main", "test", [1], "test", workers=2)
    runs = A.per_run_table([out], [], gold, set(ps), {})
    pq = A.per_question_table(runs)
    tests = A.run_families(project, pq)
    assert set(tests.family) >= {"1_confirmatory", "2_variants", "3_controls", "4_placement", "5_subgroups", "7_cost"}
    conf = tests[tests.family == "1_confirmatory"].iloc[0]
    assert conf.adjustment == "none" and conf.n == 12
    desc = A.descriptive(pq)
    qc = A.quality_cost(desc)
    comp = A.budget_compliance(runs)
    assert (comp[comp.condition.str.startswith("C_") & comp.condition.str.endswith("matched")].chk_passage_prefix_of_B == 1).all()
    dev = pd.DataFrame([{"condition": f"c{t}{h}{a}", "accuracy": 0.5 + 0.01 * t, "triples": t, "hops": h, "alloc": a}
                        for t in (5, 10, 20) for h in (1, 2) for a in (0.1, 0.2, 0.3)])
    man = make_all(project, desc, tests, qc, pq, dev, {"budget_compliance.csv": comp}, [out])
    names = {Path(m["artifact"]).name for m in man}
    assert {"accuracy_comparison.png", "quality_cost_pareto.png", "kg_ablation_heatmap.png", "statistical_tests.csv",
            "latency_comparison.png", "retrieval_mrr.csv"} <= names
