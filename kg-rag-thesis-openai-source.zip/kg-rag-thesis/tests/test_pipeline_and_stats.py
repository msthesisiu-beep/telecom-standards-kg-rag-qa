import json

import numpy as np
import pytest

from conftest import HashEncoder, LenReranker, make_passage, wcount
from kgrag.core import read_jsonl
from kgrag.evaluation.metrics import citation_metrics, retrieval_metrics, triple_metrics
from kgrag.experiments import runner as R
from kgrag.generation.generator import parse_option
from kgrag.knowledge_graph.graph import KGIndex
from kgrag.knowledge_graph.normalize import build_alias_table, canonical, deduplicate
from kgrag.llm import FakeLLM
from kgrag.reranking.reranker import choose_threshold, select
from kgrag.retrieval.dense import Retriever
from kgrag.statistics.tests import holm, mcnemar_exact, paired_bootstrap_ci, rank_biserial, wilcoxon_paired

# ------------------------------------------------------------------ KG
def test_alias_and_canonical():
    ab = make_passage("ab", clause="3.2", heading="Abbreviations",
                      text="AMF Access and Mobility Management Function\nSMF Session Management Function")
    al = build_alias_table([ab])
    assert al["access and mobility management function"] == "AMF"
    assert canonical("the Access and Mobility Management Function", al) == ("AMF", "AMF")
    assert canonical("Session Management Function (SMF)", al)[0] == "SMF"
    assert canonical("Registration procedure", al)[0] == "registration procedure"


def _inst(i, s, p, o, pid="p1"):
    return {"instance_id": f"{pid}#{i}", "passage_id": pid, "subject": s, "predicate": p, "object": o,
            "subject_type": "NetworkFunction", "object_type": "Message", "quote": "q", "specification": "TS 23.501",
            "clause_id": "5.1", "version": "17.10.0", "release": "17", "fidelity_verdict": "entailed"}


def test_dedup_preserves_provenance():
    tr = deduplicate([_inst(0, "AMF", "SENDS", "Registration Accept"), _inst(1, "the AMF", "SENDS", "registration accept", "p2")], {})
    assert len(tr) == 1 and tr[0]["n_sources"] == 2 and {p["passage_id"] for p in tr[0]["provenance"]} == {"p1", "p2"}


def triple(tid, s, p, o, pid):
    return {"triple_id": tid, "subject": s, "subject_key": s if s.isupper() else s.lower(), "subject_type": "NetworkFunction",
            "predicate": p, "object": o, "object_key": o if o.isupper() else o.lower(), "object_type": "Message",
            "provenance": [{"passage_id": pid, "specification": "TS 23.501", "clause_id": "5.1"}]}


KG = [triple("T1", "AMF", "SENDS", "Registration Accept", "p1"), triple("T2", "UE", "RECEIVES", "Registration Accept", "p1"),
      triple("T3", "SMF", "SELECTS", "UPF", "p3"), triple("T4", "UPF", "STORES", "usage report", "p4"),
      triple("T5", "PCF", "PROVIDES", "policy control", "p2")]


def test_kg_seeds_hops_and_budgets():
    kg = KGIndex(KG, HashEncoder())
    assert kg.seeds("The SMF and the AMF") == {"SMF", "AMF"}
    assert set(kg.expand({"SMF"}, 1)) == {"T3"}
    assert kg.expand({"SMF"}, 2) == {"T3": 1, "T4": 2}
    qv = HashEncoder().encode_queries(["registration accept"])[0]
    s = kg.select(qvec=qv, seed_text="AMF", hops=2, triple_budget=1, token_cap=1000, count=wcount)
    assert len(s["items"]) == 1 and s["stop_reason"] == "triple_budget"
    s = kg.select(qvec=qv, seed_text="AMF", hops=2, triple_budget=10, token_cap=5, count=wcount)
    assert s["items"] == [] and s["stop_reason"] == "token_cap"
    r1 = kg.select(qvec=qv, seed_text="AMF", hops=1, triple_budget=None, token_cap=1000, count=wcount, mode="random", rng_seed=3, n_random=2)
    r2 = kg.select(qvec=qv, seed_text="AMF", hops=1, triple_budget=None, token_cap=1000, count=wcount, mode="random", rng_seed=3, n_random=2)
    assert [i["triple_id"] for i in r1["items"]] == [i["triple_id"] for i in r2["items"]] and len(r1["items"]) == 2


# ------------------------------------------------------------------ reranker
def test_select_and_threshold():
    sc = [{"passage_id": f"p{i}", "rank": i, "rerank_score": s} for i, s in enumerate([0.9, 0.8, 0.2, 0.1, 0.05, 0.01, 0.6])]
    sel = select(sc, 0.5)
    assert [s["passage_id"] for s in sel] == ["p0", "p1", "p6"] and sel[0]["final_rank"] == 1
    assert len(select(sc, 0.99)) == 1  # min one passage
    thr = choose_threshold({"q": sc}, {"q": {"p0", "p1"}})
    assert 0.6 < thr["threshold"] <= 0.8


# ------------------------------------------------------------------ pipeline invariants
WORDS = "registration accept message sent by the AMF to the UE after successful authentication procedure"


@pytest.fixture
def pipe(project):
    ps = {}
    for i in range(12):
        txt = (f"Clause {i}. " + WORDS + ". ") * (1 + i % 3) if i < 6 else f"Clause {i}. The SMF selects a UPF for the PDU session. The PCF provides policy."
        ps[f"p{i}"] = make_passage(f"p{i}", clause=f"5.{i}", text=txt)
    plist = list(ps.values())
    enc = HashEncoder()
    ret = Retriever(enc, plist, enc.encode_passages([p["text"] for p in plist]), top_k=10)
    kg = KGIndex(KG, enc)
    llm = FakeLLM(lambda role, prompt: {"answer_option": "2", "justification": "Because P1.", "citations": ["P1", "G1", "X9"]})
    return R.Pipeline(project, ps, ret, LenReranker(), 0.0, kg, wcount, llm,
                      gold={"q1": {"reference_passage_ids": ["p0"]}}, groups={"q1": "retriever-found"})


QQ = {"question_id": "q1", "question": "Which message does the AMF send after registration?",
      "options": {"1": "Registration Reject", "2": "Registration Accept"}, "answer_option_id": "2",
      "hop_type": "single-hop", "question_type": "factual_lookup"}


def test_c_preserves_b_ranking_and_budget(pipe):
    st = pipe.b_state(QQ)
    b_ctx, _ = pipe.build(QQ, R.Condition("B"), st)
    b_ids = [i.ref for i in b_ctx.passage_items]
    for alloc in (0.1, 0.2, 0.3):
        c_ctx, _ = pipe.build(QQ, R.Condition("C", "matched", 10, 1, alloc), pipe.b_state(QQ))
        ids = [i.ref for i in c_ctx.passage_items]
        assert ids == b_ids[: len(ids)]                                    # in-order prefix, never reordered
        assert c_ctx.checks["passage_prefix_of_B"] and c_ctx.checks["graph_cap_ok"]
        assert c_ctx.evidence_tokens <= c_ctx.T_q * 1.05
        assert c_ctx.graph_tokens <= int(alloc * c_ctx.T_q)
    o_ctx, _ = pipe.build(QQ, R.Condition("C", "overhead", 10, 1, 0.3), pipe.b_state(QQ))
    assert [i.ref for i in o_ctx.passage_items] == b_ids                  # overhead keeps B's full context
    assert o_ctx.evidence_tokens == b_ctx.evidence_tokens + o_ctx.graph_tokens


def test_c_seeds_only_from_b_passages(pipe, monkeypatch):
    seen = {}
    orig = pipe.kg.select

    def spy(**kw):
        seen.setdefault("seed_text", kw["seed_text"])
        return orig(**kw)
    monkeypatch.setattr(pipe.kg, "select", spy)
    st = pipe.b_state(QQ)
    pipe.build(QQ, R.Condition("C", "matched", 10, 1, 0.2), st)
    assert seen["seed_text"] == "\n".join(pipe.passages[i]["text"] for i in st["b_cached_ids"])


def test_a_d_controls_and_closed_book(pipe):
    st = pipe.b_state(QQ)
    a, _ = pipe.build(QQ, R.Condition("A"), st)
    assert a.checks["not_over_budget"]
    d, _ = pipe.build(QQ, R.Condition("D", "matched", 10, 1, 0.2), st)
    assert d.evidence_tokens <= d.T_q and d.graph_tokens <= d.graph_cap and "passages_differ_from_B" in d.checks
    for cfg in ("RANDOM", "UNFILTERED"):
        c, _ = pipe.build(QQ, R.Condition(cfg, "matched", 10, 1, 0.2), st)
        assert c.graph_tokens <= c.graph_cap and c.checks["passage_prefix_of_B"]
    z, _ = pipe.build(QQ, R.Condition("0"), None)
    assert z.items == [] and z.text() == ""


def test_run_is_resumable_and_logs_invariants(pipe, project):
    conds = [R.Condition("0"), R.Condition("B"), R.Condition("C", "matched", 10, 1, 0.2)]
    out = R.run(pipe, [QQ], conds, "unit", "test", [1], "dev", workers=2)
    recs = read_jsonl(out)
    assert len(recs) == 3 and all(r["status"] == "ok" for r in recs)
    c = next(r for r in recs if r["configuration"] == "C")
    assert c["ranking_invariance_ok"] and c["correct"] == 1 and c["budget_checks"]["passage_prefix_of_B"]
    zero = next(r for r in recs if r["configuration"] == "0")
    assert zero["context_text"] == "" and zero["retrieved_passage_ids"] == []
    R.run(pipe, [QQ], conds, "unit", "test", [1], "dev", workers=2)
    assert len(read_jsonl(out)) == 3                                      # nothing recomputed


def test_malformed_answer_is_incorrect():
    assert parse_option({"answer_option": "option 2"}, ["1", "2"]) == "2"
    assert parse_option({"answer_option": "7"}, ["1", "2"]) is None
    assert parse_option(None, ["1", "2"]) is None


# ------------------------------------------------------------------ metrics
def test_metrics():
    m = retrieval_metrics(["a", "b", "c"], ["a", "b"], {"b", "c"})
    assert m["recall_at_1"] == 0 and m["recall_at_3"] == 1 and m["mrr"] == 0.5 and m["full_coverage"] == 0
    labels = {"P1": {"kind": "P", "ref": "a", "source_passage_ids": ["a"]},
              "G1": {"kind": "G", "ref": "T1", "source_passage_ids": ["b"]}}
    c = citation_metrics(["P1", "G1", "Z9"], labels, {"b"})
    assert c["citation_validity"] == 2 / 3 and c["citation_support"] == 1 / 3 and c["graph_citation_support"] == 1.0
    assert citation_metrics([], labels, {"b"})["citation_validity"] is None
    t = triple_metrics(labels, {"b"}, {"a", "b"}, {"T1": 1})
    assert t["provenance_validity"] == 1 and t["gold_linked_precision"] == 1 and t["judged_relevant_precision"] == 1


# ------------------------------------------------------------------ statistics (Appendix 6)
def test_mcnemar_exact_known_value():
    ref = [0] * 6 + [1] * 10
    alt = [1] * 6 + [1] * 10
    r = mcnemar_exact(ref, alt)
    assert (r["b"], r["c"]) == (0, 6) and abs(r["p_raw"] - 0.03125) < 1e-9 and abs(r["diff_pp"] - 37.5) < 1e-9
    assert mcnemar_exact([1, 0], [1, 0])["p_raw"] == 1.0


def test_wilcoxon_edge_cases_and_effect():
    assert wilcoxon_paired([1, 2, 3], [1, 2, 3])["note"] == "all differences zero"
    r = wilcoxon_paired([0.1, np.nan, 0.3, 0.2, 0.5, 0.4, 0.6, 0.2], [0.4, 0.9, 0.6, 0.5, 0.9, 0.8, 0.9, 0.7])
    assert r["n"] == 7 and r["n_excluded_pairs"] == 1 and r["rank_biserial_r"] == 1.0
    assert rank_biserial(np.array([1.0, -1.0])) == 0.0


def test_bootstrap_and_holm():
    ci1 = paired_bootstrap_ci([0, 1, 0, 1, 1], [1, 1, 1, 1, 0], scale=100)
    ci2 = paired_bootstrap_ci([0, 1, 0, 1, 1], [1, 1, 1, 1, 0], scale=100)
    assert ci1 == ci2 and ci1[0] <= 20 <= ci1[1]
    assert holm([0.01, 0.04, 0.03]) == pytest.approx([0.03, 0.06, 0.06])
