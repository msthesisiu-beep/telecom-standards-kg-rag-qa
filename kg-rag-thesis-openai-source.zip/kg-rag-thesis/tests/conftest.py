"""Synthetic fixtures for UNIT TESTS ONLY. Nothing here is ever written to results/ or used as empirical evidence."""
import shutil
import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from kgrag.core import Project  # noqa: E402


@pytest.fixture
def project(tmp_path):
    shutil.copytree(ROOT / "configs", tmp_path / "configs")
    return Project.load(tmp_path)


def wcount(s: str) -> int:
    return len(s.split())


def make_passage(pid, spec="23501", clause="5.1", text="The AMF shall send the message.", heading="General"):
    return {"passage_id": pid, "specification": f"TS {spec[:2]}.{spec[2:]}", "spec_id": spec, "release": "17",
            "version": "17.10.0", "clause_id": clause, "clause_ids": [clause], "heading": heading, "text": text,
            "token_count": wcount(text), "chunk_flags": []}


class HashEncoder:
    """Deterministic bag-of-words hashing encoder (unit tests only)."""
    name = "fake-hash-encoder"

    def _enc(self, texts):
        M = np.zeros((len(texts), 64), dtype="float32")
        for i, t in enumerate(texts):
            for w in t.lower().split():
                M[i, hash(w) % 64] += 1
        return M / (np.linalg.norm(M, axis=1, keepdims=True) + 1e-9)

    def encode_queries(self, texts):
        return self._enc(texts)

    def encode_passages(self, texts, show_progress=False):
        return self._enc(texts)


class LenReranker:
    """Scores by word overlap with the query (unit tests only)."""
    name = "fake-reranker"

    def score(self, query, texts):
        qw = set(query.lower().split())
        return [len(qw & set(t.lower().split())) / (1 + len(qw)) for t in texts], 0.001
