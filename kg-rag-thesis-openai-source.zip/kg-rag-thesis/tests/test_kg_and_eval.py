import numpy as np

from conftest import HashEncoder, make_passage
from kgrag.core import append_jsonl, read_jsonl, write_jsonl
from kgrag.evaluation import ragas_eval
from kgrag.evaluation.triple_relevance import judge_question
from kgrag.knowledge_graph import extract, fidelity, graph
from kgrag.llm import FakeLLM

P1 = make_passage("p1", text="After authentication the AMF sends the Registration Accept message to the UE over N1.")


def test_extract_verify_assemble(project):
    kg_cfg = project.study["knowledge_graph"]
    ext = FakeLLM(lambda r, pr: {"triples": [
        {"subject": "AMF", "subject_type": "NetworkFunction", "predicate": "SENDS", "object": "Registration Accept",
         "object_type": "Message", "quote": "the AMF sends the Registration Accept message to the UE"},
        {"subject": "SMF", "subject_type": "NetworkFunction", "predicate": "SENDS", "object": "PDU Session Accept",
         "object_type": "Message", "quote": "the SMF sends a PDU Session Accept to everyone"},      # quote not in passage
        {"subject": "AMF", "subject_type": "NetworkFunction", "predicate": "LIKES", "object": "UE",
         "object_type": "Other", "quote": "the AMF sends the Registration Accept message to the UE"}]})  # bad predicate
    rec = extract.extract_passage(ext, P1, kg_cfg)
    assert [t["quote_found"] for t in rec["triples"]] == [True, False, True]
    assert [t["schema_valid"] for t in rec["triples"]] == [True, True, False]
    append_jsonl(project.path("interim", "kg_extraction.jsonl"), rec)
    inst = [{**t, "instance_id": f"p1#{t['local_id']}", "passage_id": "p1"} for t in rec["triples"]
            if t["schema_valid"] and t["quote_found"]]
    ver = FakeLLM(lambda r, pr: {"judgements": [{"n": 1, "verdict": "entailed"}]})
    for row in fidelity.verify_passage(ver, P1, inst):
        append_jsonl(project.path("interim", "kg_fidelity.jsonl"), row)
    all_tr, validated, stats = graph.assemble(project, {"p1": P1})
    assert stats["validated_triples"] == 1 and validated[0]["subject"] == "AMF"
    assert stats["instances_quote_verified"] == 2 and stats["nodes"] == 2
    assert graph.load(project).by_id[validated[0]["triple_id"]]["provenance"][0]["passage_id"] == "p1"


def test_ragas_protocol_scores_and_no_imputation():
    def r(role, prompt):
        if prompt.startswith("Break the ANSWER"):
            return {"statements": ["The AMF sends Registration Accept.", "It uses N2."]}
        if "can be directly inferred" in prompt or "attributed to the CONTEXT" in prompt:
            return {"verdicts": [{"n": 1, "verdict": 1}, {"n": 2, "verdict": 0}]}
        if prompt.startswith("Generate"):
            return {"questions": ["Which message does the AMF send?"], "noncommittal": 0}
        return {"verdicts": [{"n": 1, "useful": 0}, {"n": 2, "useful": 1}]}
    q = {"question": "Which message does the AMF send?", "options": {"1": "Reject", "2": "Registration Accept"},
         "answer_option_id": "2", "explanation": "Clause 4.2.2."}
    rec = {"key": "k", "parsed_option": "2", "justification": "The AMF sends it.", "context_text": "[P1] x\n\n[G1] y",
           "context_text_passages_only": "[P1] x", "context_items": ["[P1] x", "[G1] y"]}
    out = ragas_eval.evaluate_record(FakeLLM(r), HashEncoder(), rec, q)
    assert out["faithfulness_full"] == 0.5 and out["faithfulness_passages"] == 0.5
    assert out["context_precision"] == 0.5 and out["context_recall"] == 0.5
    assert 0.99 < out["answer_relevance"] <= 1.0001
    closed = ragas_eval.evaluate_record(FakeLLM(r), HashEncoder(), {**rec, "context_text": "", "context_text_passages_only": "",
                                                                   "context_items": []}, q)
    assert closed["faithfulness_full"] is None and closed["context_precision"] is None  # undefined, never imputed


def test_triple_relevance_one_judgement_per_triple():
    t = {"triple_id": "T1", "subject": "AMF", "predicate": "SENDS", "object": "Registration Accept",
         "provenance": [{"passage_id": "p1"}]}
    q = {"question_id": "q", "question": "?", "options": {"1": "a", "2": "Registration Accept"}, "answer_option_id": "2"}
    rows = judge_question(FakeLLM(lambda r, p: {"judgements": [{"n": 1, "helpful": 1}]}), q, [t], {"p1": P1})
    assert rows[0]["helpful"] == 1 and rows[0]["status"] == "ok"
