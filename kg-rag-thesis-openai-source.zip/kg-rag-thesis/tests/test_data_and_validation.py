import pandas as pd

from conftest import make_passage, wcount
from kgrag.benchmark.freeze import stratified_split
from kgrag.data.chunker import make_passages, quality_checks, is_spec_ref
from kgrag.data.tspec import version_from_filename
from kgrag.data.teleqna import parse
from kgrag.llm import FakeLLM
from kgrag.validation import verifier as V
from kgrag.validation.audit import cohen_kappa, wilson_ci, stratified_sample
from kgrag.validation.pooling import assert_not_forbidden, pool_for_question
from kgrag.validation.register import near_duplicates

DOC = """3GPP TS 23.501 V17.10.0 (2023-09)
Contents
1 Scope 20
2 References 21
1 Scope
The present document defines the 5G System. The AMF shall support registration.
2 References
The following documents apply.
### 5.1 General
The SMF may select a UPF. See 38.214 \\[19\\] for details.
### 5.1.1 Detail
Tiny.
### 5.2 Registration
The UE shall send a Registration Request to the AMF when it powers on. The AMF should respond.
#### -- *BWP*
ASN.1 field description text.
"""


def test_chunker_structure_and_normative_preservation():
    lines = DOC.splitlines()
    ps, st = make_passages(lines, "23501", "17", "23501-ha0.md", wcount, cap=500, min_body=3)
    assert st["scope_anchor_found"] and st["version"] == "17.10.0"
    clauses = [p["clause_id"] for p in ps]
    assert clauses[0] == "1" and "5.2" in clauses
    assert not any(is_spec_ref(c) for c in clauses)              # 38.214 is a cross-reference, not a heading
    q = quality_checks(ps, DOC)
    assert q["duplicate_ids"] == 0 and q["empty_passages"] == 0
    front = sum(l.count("shall") for l in lines[:5])
    assert q["normative_terms_in_passages"] == q["normative_terms_in_source"] - front
    assert any("BWP" in p["text"] for p in ps)                   # ASN.1 kept inside its parent clause


def test_tiny_sections_merge_forward_within_top_clause():
    ps, _ = make_passages(DOC.splitlines(), "23501", "17", "f.md", wcount, cap=500, min_body=6)
    merged = [p for p in ps if "5.1.1" in p["clause_ids"]]
    assert merged and merged[0]["clause_id"] == "5.2"


def test_version_code_and_teleqna_parse():
    assert version_from_filename("23501-ha0.md") == "17.10.0"
    assert version_from_filename("24501-hc0.md") == "17.12.0"
    rows = parse({"question 1": {"question": "What? [3GPP Release 17]", "option 1": "a", "option 2": "b",
                                 "answer": "option 2: b", "category": "Standards specifications"}})
    assert rows[0]["answer_option_id"] == "2" and rows[0]["answer_parsed"] and rows[0]["source_tag"] == "3GPP Release 17"


def test_pooling_union_and_forbidden_model():
    import numpy as np
    pool = pool_for_question(np.array([3.0, 2, 1, 0]), np.array([0.0, 1, 2, 3]), ["a", "b", "c", "d"], depth=2)
    assert {r["passage_id"] for r in pool} == {"a", "b", "c", "d"}
    try:
        assert_not_forbidden("BAAI/bge-base-en-v1.5")
        raise AssertionError("BGE must be rejected")
    except ValueError:
        pass


def test_quote_check_normalises_layout_only():
    text = "The AMF \\*shall\\* send the | Registration Accept | message to the UE."
    assert V.quote_in_passage("The AMF shall send the Registration Accept message", text)
    assert not V.quote_in_passage("The SMF shall send the Registration Accept message", text)
    assert not V.quote_in_passage("AMF shall", text)  # too short to count as evidence


Q = {"question_id": "question 7", "question": "Which entity sends Registration Accept?", "category": "Standards specifications",
     "options": {"1": "SMF", "2": "AMF"}, "answer_option_id": "2", "explanation": ""}
PASS = {"p1": make_passage("p1", text="After authentication the AMF sends the Registration Accept message to the UE."),
        "p2": make_passage("p2", clause="6.1", text="Unrelated text about the PCF and policy control decisions here.")}
POOL = [{"passage_id": "p1", "sources": ["bm25"], "rrf": 0.1}, {"passage_id": "p2", "sources": ["e5"], "rrf": 0.05}]
CFG = {"window_size": 25, "max_windows": 4, "non_3gpp_tag_pattern": r"\[(IEEE|ITU)[^\]]*\]"}


def responder(quote, entail="entails", verdict="supports", **flags):
    def r(role, prompt):
        if "VERIFIED QUOTATIONS" in prompt:
            return {"entailment": entail, "reason": "x"}
        return {"verdict": verdict, "evidence": [{"passage_id": "p1", "quote": quote}], "ambiguous": False,
                "general_knowledge": False, "out_of_corpus": False, "question_type": "factual_lookup", "reason": "x", **flags}
    return r


def test_verifier_include_requires_quote_and_entailment():
    rec = V.verify_question(FakeLLM(responder("the AMF sends the Registration Accept message to the UE")), Q, POOL, PASS, CFG)
    assert rec["decision"] == "include" and rec["reference_passage_ids"] == ["p1"] and rec["hop_type"] == "single-hop"
    rec = V.verify_question(FakeLLM(responder("the SMF sends the Registration Accept message to the UE")), Q, POOL, PASS, CFG)
    assert rec["reason_code"] == "X7"                                   # hallucinated quotation
    rec = V.verify_question(FakeLLM(responder("the AMF sends the Registration Accept message to the UE", "partial")), Q, POOL, PASS, CFG)
    assert rec["reason_code"] == "X3"                                   # separate entailment check
    rec = V.verify_question(FakeLLM(responder("the AMF sends the Registration Accept message to the UE", ambiguous=True)), Q, POOL, PASS, CFG)
    assert rec["reason_code"] == "X4"
    rec = V.verify_question(FakeLLM(responder("x", verdict="no_support")), Q, POOL, PASS, CFG)
    assert rec["reason_code"] == "X1"


def test_verifier_non3gpp_tag_excluded_without_llm():
    llm = FakeLLM(responder("x"))
    rec = V.verify_question(llm, {**Q, "question": "What is GTS? [IEEE 802.15.4]"}, POOL, PASS, CFG)
    assert rec["reason_code"] == "X2" and not llm.calls


def test_multihop_classification_rule():
    ps = {"a": make_passage("a", clause="5.1"), "b": make_passage("b", clause="5.2"), "c": make_passage("c", spec="38331", clause="5.3")}
    assert V.classify(["a"], ps, "procedure_association") == ("single-hop", "procedure_association")
    assert V.classify(["a", "b"], ps, "factual_lookup") == ("multi-hop", "cross_section_dependency")
    assert V.classify(["a", "c"], ps, "factual_lookup") == ("multi-hop", "multi_hop_reasoning")


def test_near_duplicates_keep_earliest():
    df = pd.DataFrame({"question_id": ["question 10", "question 2", "question 5"],
                       "question": ["What does the AMF send to the UE?", "What does the AMF send to the UE ?", "Totally different item"],
                       "reference_passage_ids": [["p1"], ["p1"], ["p9"]], "answer_key_text": ["x", "x", "y"]})
    assert near_duplicates(df, 0.9) == {"question 10": "question 2"}


def test_split_deterministic_and_stratified():
    df = pd.DataFrame({"question_id": [f"q{i}" for i in range(100)], "question_type": ["a"] * 60 + ["b"] * 40,
                       "hop_type": ["single-hop"] * 100})
    d1, t1 = stratified_split(df, ["question_type", "hop_type"], 0.2, 42)
    d2, _ = stratified_split(df, ["question_type", "hop_type"], 0.2, 42)
    assert d1 == d2 and len(d1) == 20 and not set(d1) & set(t1)
    assert sum(x in d1 for x in df.question_id[:60]) == 12


def test_audit_statistics():
    assert abs(cohen_kappa([1, 1, 0, 0], [1, 1, 0, 0]) - 1) < 1e-12
    assert abs(cohen_kappa([1, 0, 1, 0], [1, 1, 0, 0]) - 0.0) < 1e-12
    lo, hi = wilson_ci(9, 10)
    assert 0.59 < lo < 0.60 and 0.98 < hi < 0.99
    df = pd.DataFrame({"category": ["s"] * 70 + ["o"] * 30, "x": range(100)})
    s = stratified_sample(df, 10, "category", 1)
    assert len(s) == 10 and (s.category == "s").sum() == 7
